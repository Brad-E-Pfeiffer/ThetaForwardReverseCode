function IRFS_PLOT_FIGURE_ONE_D_AND_E(Initial_Variables)

load Bimodal_Analysis_Windows
cd AllRatsCombined
load Combined_Theta_Sequences
cd _Figures_For_Paper
cd Figure1


A=mean(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third(:,:,3),3);
B=mean(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third(:,:,3),3);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc([A,A],[0 max([max(max(A)),max(max(B))])]);
colormap('hot');
set(gca,'YLim',[1 size(A,1)]);
set(gca,'XLim',[1 size([A,A],2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_1D_Up_Runs_Up_Fields(Map=0to%d).jpg'');',max([max(max(A)),max(max(B))])));
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc([B,B],[0 max([max(max(A)),max(max(B))])]);
colormap('hot');
set(gca,'YLim',[1 size(A,1)]);
set(gca,'XLim',[1 size([A,A],2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_1D_Up_Runs_Down_Fields(Map=0to%d).jpg'');',max([max(max(A)),max(max(B))])));
close;
close;

A=mean(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third(:,:,3),3);
B=mean(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third(:,:,3),3);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc([A,A],[0 max([max(max(A)),max(max(B))])]);
colormap('hot');
set(gca,'YLim',[1 size(A,1)]);
set(gca,'XLim',[1 size([A,A],2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_1D_Down_Runs_Up_Fields(Map=0to%d).jpg'');',max([max(max(A)),max(max(B))])));
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc([B,B],[0 max([max(max(A)),max(max(B))])]);
colormap('hot');
set(gca,'YLim',[1 size(A,1)]);
set(gca,'XLim',[1 size([A,A],2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_1D_Down_Runs_Down_Fields(Map=0to%d).jpg'');',max([max(max(A)),max(max(B))])));
close;
close;


Up_Up_Forward_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third,3),1); %Up Fields, Up Runs
Up_Up_Reverse_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third,3),1); %Up Fields, Up Runs
Up_Down_Forward_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third,3),1); %Up Fields, Down Runs
Up_Down_Reverse_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third,3),1); %Up Fields, Down Runs
Down_Up_Forward_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third,3),1); %Down Fields, Up Runs
Down_Up_Reverse_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third,3),1); %Down Fields, Up Runs
Down_Down_Forward_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third,3),1); %Down Fields, Down Runs
Down_Down_Reverse_Weighted_Correlations=zeros(size(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third,3),1); %Down Fields, Down Runs
for N=1:size(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third,3)
    Up_Up_Forward_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third(:,[round(Forward_Window(1)/Initial_Variables.Phase_Bin):size(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third,2),1:round(Forward_Window(2)/Initial_Variables.Phase_Bin)],N));
    Up_Up_Reverse_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third(:,round(Reverse_Window(1)/Initial_Variables.Phase_Bin):round(Reverse_Window(2)/Initial_Variables.Phase_Bin),N));
    Up_Down_Forward_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third(:,[round(Forward_Window(1)/Initial_Variables.Phase_Bin):size(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third,2),1:round(Forward_Window(2)/Initial_Variables.Phase_Bin)],N));
    Up_Down_Reverse_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third(:,round(Reverse_Window(1)/Initial_Variables.Phase_Bin):round(Reverse_Window(2)/Initial_Variables.Phase_Bin),N));
    Down_Up_Forward_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third(:,[round(Forward_Window(1)/Initial_Variables.Phase_Bin):size(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third,2),1:round(Forward_Window(2)/Initial_Variables.Phase_Bin)],N));
    Down_Up_Reverse_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third(:,round(Reverse_Window(1)/Initial_Variables.Phase_Bin):round(Reverse_Window(2)/Initial_Variables.Phase_Bin),N));
    Down_Down_Forward_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third(:,[round(Forward_Window(1)/Initial_Variables.Phase_Bin):size(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third,2),1:round(Forward_Window(2)/Initial_Variables.Phase_Bin)],N));
    Down_Down_Reverse_Weighted_Correlations(N,1)=IRFS_WEIGHTED_CORRELATION(All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third(:,round(Reverse_Window(1)/Initial_Variables.Phase_Bin):round(Reverse_Window(2)/Initial_Variables.Phase_Bin),N));
end

figure;
hold on;
P_Value=ranksum(Up_Up_Forward_Weighted_Correlations,Down_Up_Forward_Weighted_Correlations);
B1=boxplot([Up_Up_Forward_Weighted_Correlations,-1000*ones(length(Down_Up_Forward_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Up_Forward_Weighted_Correlations),1),Down_Up_Forward_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Up_Forward_Weighted_Correlations) mean(Up_Up_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Up_Forward_Weighted_Correlations) mean(Down_Up_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Up_Forward_Weighted_Correlations) median(Up_Up_Forward_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Up_Forward_Weighted_Correlations) median(Down_Up_Forward_Weighted_Correlations)],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Up_Runs_Forward_Window_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
close
figure;
hold on;
B1=boxplot([Up_Up_Forward_Weighted_Correlations,-1000*ones(length(Down_Up_Forward_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Up_Forward_Weighted_Correlations),1),Down_Up_Forward_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Up_Forward_Weighted_Correlations) mean(Up_Up_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Up_Forward_Weighted_Correlations) mean(Down_Up_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Up_Forward_Weighted_Correlations) median(Up_Up_Forward_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Up_Forward_Weighted_Correlations) median(Down_Up_Forward_Weighted_Correlations)],'k--','LineWidth',3)
for N=1:length(Up_Up_Forward_Weighted_Correlations)
    plot([1 2],[Up_Up_Forward_Weighted_Correlations(N),Down_Up_Forward_Weighted_Correlations(N)])
end
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData),min([Up_Up_Forward_Weighted_Correlations;Down_Up_Forward_Weighted_Correlations])]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData),max([Up_Up_Forward_Weighted_Correlations;Down_Up_Forward_Weighted_Correlations])]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Up_Runs_Forward_Window_With_Lines(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum(Up_Down_Forward_Weighted_Correlations,Down_Down_Forward_Weighted_Correlations);
B1=boxplot([Up_Down_Forward_Weighted_Correlations,-1000*ones(length(Down_Down_Forward_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Down_Forward_Weighted_Correlations),1),Down_Down_Forward_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Down_Forward_Weighted_Correlations) mean(Up_Down_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Down_Forward_Weighted_Correlations) mean(Down_Down_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Down_Forward_Weighted_Correlations) median(Up_Down_Forward_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Down_Forward_Weighted_Correlations) median(Down_Down_Forward_Weighted_Correlations)],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Down_Runs_Forward_Window_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
close
figure;
hold on;
B1=boxplot([Up_Down_Forward_Weighted_Correlations,-1000*ones(length(Down_Down_Forward_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Down_Forward_Weighted_Correlations),1),Down_Down_Forward_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Down_Forward_Weighted_Correlations) mean(Up_Down_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Down_Forward_Weighted_Correlations) mean(Down_Down_Forward_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Down_Forward_Weighted_Correlations) median(Up_Down_Forward_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Down_Forward_Weighted_Correlations) median(Down_Down_Forward_Weighted_Correlations)],'k--','LineWidth',3)
for N=1:length(Down_Down_Forward_Weighted_Correlations)
    plot([1 2],[Up_Down_Forward_Weighted_Correlations(N),Down_Down_Forward_Weighted_Correlations(N)])
end
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData),min([Up_Down_Forward_Weighted_Correlations;Down_Down_Forward_Weighted_Correlations])]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData),max([Up_Down_Forward_Weighted_Correlations;Down_Down_Forward_Weighted_Correlations])]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Down_Runs_Forward_Window_With_Lines(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum(Up_Up_Reverse_Weighted_Correlations,Down_Up_Reverse_Weighted_Correlations);
B1=boxplot([Up_Up_Reverse_Weighted_Correlations,-1000*ones(length(Down_Up_Reverse_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Up_Reverse_Weighted_Correlations),1),Down_Up_Reverse_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Up_Reverse_Weighted_Correlations) mean(Up_Up_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Up_Reverse_Weighted_Correlations) mean(Down_Up_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Up_Reverse_Weighted_Correlations) median(Up_Up_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Up_Reverse_Weighted_Correlations) median(Down_Up_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Up_Runs_Reverse_Window_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
close
figure;
hold on;
B1=boxplot([Up_Up_Reverse_Weighted_Correlations,-1000*ones(length(Down_Up_Reverse_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Up_Reverse_Weighted_Correlations),1),Down_Up_Reverse_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Up_Reverse_Weighted_Correlations) mean(Up_Up_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Up_Reverse_Weighted_Correlations) mean(Down_Up_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Up_Reverse_Weighted_Correlations) median(Up_Up_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Up_Reverse_Weighted_Correlations) median(Down_Up_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
for N=1:length(Up_Up_Reverse_Weighted_Correlations)
    plot([1 2],[Up_Up_Reverse_Weighted_Correlations(N),Down_Up_Reverse_Weighted_Correlations(N)])
end
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData),min([Up_Up_Reverse_Weighted_Correlations;Down_Up_Reverse_Weighted_Correlations])]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData),max([Up_Up_Reverse_Weighted_Correlations;Down_Up_Reverse_Weighted_Correlations])]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Up_Runs_Reverse_Window_With_Lines(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum(Up_Down_Reverse_Weighted_Correlations,Down_Down_Reverse_Weighted_Correlations);
B1=boxplot([Up_Down_Reverse_Weighted_Correlations,-1000*ones(length(Down_Down_Reverse_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Down_Reverse_Weighted_Correlations),1),Down_Down_Reverse_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Down_Reverse_Weighted_Correlations) mean(Up_Down_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Down_Reverse_Weighted_Correlations) mean(Down_Down_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Down_Reverse_Weighted_Correlations) median(Up_Down_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Down_Reverse_Weighted_Correlations) median(Down_Down_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Down_Runs_Reverse_Window_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
close
figure;
hold on;
B1=boxplot([Up_Down_Reverse_Weighted_Correlations,-1000*ones(length(Down_Down_Reverse_Weighted_Correlations),1)]);
B2=boxplot([-1000*ones(length(Up_Down_Reverse_Weighted_Correlations),1),Down_Down_Reverse_Weighted_Correlations]);
plot([0.75 1.25],[mean(Up_Down_Reverse_Weighted_Correlations) mean(Up_Down_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([1.75 2.25],[mean(Down_Down_Reverse_Weighted_Correlations) mean(Down_Down_Reverse_Weighted_Correlations)],'k','LineWidth',3)
plot([0.75 1.25],[median(Up_Down_Reverse_Weighted_Correlations) median(Up_Down_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
plot([1.75 2.25],[median(Down_Down_Reverse_Weighted_Correlations) median(Down_Down_Reverse_Weighted_Correlations)],'k--','LineWidth',3)
for N=1:length(Up_Down_Reverse_Weighted_Correlations)
    plot([1 2],[Up_Down_Reverse_Weighted_Correlations(N),Down_Down_Reverse_Weighted_Correlations(N)])
end
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData),min([Up_Down_Reverse_Weighted_Correlations;Down_Down_Reverse_Weighted_Correlations])]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData),max([Up_Down_Reverse_Weighted_Correlations;Down_Down_Reverse_Weighted_Correlations])]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1E_Down_Runs_Reverse_Window_With_Lines(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

cd ..
cd ..
cd ..

end