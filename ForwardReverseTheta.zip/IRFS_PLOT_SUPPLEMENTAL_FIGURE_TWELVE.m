% This makes all the figures for the unimodal/bimodal cell properties

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Spike_Properties
        load Modality
        load Spike_Data
        All_Modality(:,3)=1;
        for N=1:length(Inhibitory_Neurons)
            All_Modality(All_Modality(:,2)==Inhibitory_Neurons(N),3)=0;
        end
        
        if exist('Unimodal_Spike_Properties','var')
            Unimodal_Spike_Properties=[Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
            Bimodal_Spike_Properties=[Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
            Inhibitory_Spike_Properties=[Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
        else
            Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
            Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
            Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
        end
        
        if strcmp(Directory_Name(1),'L')
            if exist('Linear_Unimodal_Spike_Properties','var')
                Linear_Unimodal_Spike_Properties=[Linear_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                Linear_Bimodal_Spike_Properties=[Linear_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                Linear_Inhibitory_Spike_Properties=[Linear_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                Linear_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                Linear_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                Linear_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        else
            if exist('OpenField_Unimodal_Spike_Properties','var')
                OpenField_Unimodal_Spike_Properties=[OpenField_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Bimodal_Spike_Properties=[OpenField_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Inhibitory_Spike_Properties=[OpenField_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                OpenField_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                OpenField_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                OpenField_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

cd AllRatsCombined
load Cell_Modality_Information
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end

if exist('SupplementalFigure12','dir')==7
    cd SupplementalFigure12
else
    mkdir('SupplementalFigure12')
    cd SupplementalFigure12
end

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)],[Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)]) mean([Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)]) mean([Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)]) median([Linear_Unimodal_Place_Field_Properties(:,1);Open_Unimodal_Place_Field_Properties(:,1)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)]) median([Linear_Bimodal_Place_Field_Properties(:,1);Open_Bimodal_Place_Field_Properties(:,1)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Place_Field_Size_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)],[Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)]) mean([Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)]) mean([Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)]) median([Linear_Unimodal_Place_Field_Properties(:,2);Open_Unimodal_Place_Field_Properties(:,2)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)]) median([Linear_Bimodal_Place_Field_Properties(:,2);Open_Bimodal_Place_Field_Properties(:,2)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Number_Of_Place_Fields_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)],[Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)]) mean([Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)]) mean([Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)]) median([Linear_Unimodal_Place_Field_Properties(:,3);Open_Unimodal_Place_Field_Properties(:,3)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)]) median([Linear_Bimodal_Place_Field_Properties(:,3);Open_Bimodal_Place_Field_Properties(:,3)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Peak_Firing_Rate_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)],[Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)]) mean([Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)]) mean([Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)]) median([Linear_Unimodal_Place_Field_Properties(:,5);Open_Unimodal_Place_Field_Properties(:,5)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)]) median([Linear_Bimodal_Place_Field_Properties(:,5);Open_Bimodal_Place_Field_Properties(:,5)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Information_Per_Spike_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)],[Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)]) mean([Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)]) mean([Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)]) median([Linear_Unimodal_Place_Field_Properties(:,6);Open_Unimodal_Place_Field_Properties(:,6)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)]) median([Linear_Bimodal_Place_Field_Properties(:,6);Open_Bimodal_Place_Field_Properties(:,6)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_L_Ratios_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum([Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)],[Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)]);
B1=boxplot([[Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)],-1000*ones(size([Linear_Unimodal_Place_Field_Properties;Open_Unimodal_Place_Field_Properties],1),1)]);
B2=boxplot([-1000*ones(size([Linear_Bimodal_Place_Field_Properties;Open_Bimodal_Place_Field_Properties],1),1),[Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)]]);
plot([0.75 1.25],[mean([Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)]) mean([Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)])],'k','LineWidth',3)
plot([1.75 2.25],[mean([Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)]) mean([Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)])],'k','LineWidth',3)
plot([0.75 1.25],[median([Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)]) median([Linear_Unimodal_Place_Field_Properties(:,7);Open_Unimodal_Place_Field_Properties(:,7)])],'k--','LineWidth',3)
plot([1.75 2.25],[median([Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)]) median([Linear_Bimodal_Place_Field_Properties(:,7);Open_Bimodal_Place_Field_Properties(:,7)])],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Mean_In_Field_Firing_Rate_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
P_Value=ranksum(Unimodal_Spike_Properties(:,3),Bimodal_Spike_Properties(:,3));
B1=boxplot([Unimodal_Spike_Properties(:,3,1),-1000*ones(size(Unimodal_Spike_Properties(:,3,1),1),1)]);
B2=boxplot([-1000*ones(size(Bimodal_Spike_Properties(:,3,1),1),1),Bimodal_Spike_Properties(:,3,1)]);
plot([0.75 1.25],[mean(Unimodal_Spike_Properties(:,3,1)) mean(Unimodal_Spike_Properties(:,3,1))],'k','LineWidth',3)
plot([1.75 2.25],[mean(Bimodal_Spike_Properties(:,3,1)) mean(Bimodal_Spike_Properties(:,3,1))],'k','LineWidth',3)
plot([0.75 1.25],[median(Unimodal_Spike_Properties(:,3,1)) median(Unimodal_Spike_Properties(:,3,1))],'k--','LineWidth',3)
plot([1.75 2.25],[median(Bimodal_Spike_Properties(:,3,1)) median(Bimodal_Spike_Properties(:,3,1))],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Normalized_Afterhyperpolarization_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

figure;
hold on;
Uni_Vs_Bi_P_Value=ranksum(Unimodal_Spike_Properties(:,4),Bimodal_Spike_Properties(:,4));
Uni_Vs_Inh_P_Value=ranksum(Unimodal_Spike_Properties(:,4),Inhibitory_Spike_Properties(:,4));
Bi_Vs_Inh_P_Value=ranksum(Inhibitory_Spike_Properties(:,4),Bimodal_Spike_Properties(:,4));
B1=boxplot([Unimodal_Spike_Properties(:,4,1),-1000*ones(size(Unimodal_Spike_Properties(:,4,1),1),1),-1000*ones(size(Unimodal_Spike_Properties(:,4,1),1),1)]);
B2=boxplot([-1000*ones(size(Bimodal_Spike_Properties(:,4,1),1),1),Bimodal_Spike_Properties(:,4,1),-1000*ones(size(Bimodal_Spike_Properties(:,4,1),1),1)]);
B3=boxplot([-1000*ones(size(Inhibitory_Spike_Properties(:,4,1),1),1),-1000*ones(size(Inhibitory_Spike_Properties(:,4,1),1),1),Inhibitory_Spike_Properties(:,4,1)]);
plot([0.75 1.25],[mean(Unimodal_Spike_Properties(:,4,1)) mean(Unimodal_Spike_Properties(:,4,1))],'k','LineWidth',3)
plot([0.75 1.25],[median(Unimodal_Spike_Properties(:,4,1)) median(Unimodal_Spike_Properties(:,4,1))],'k--','LineWidth',3)
plot([1.75 2.25],[mean(Bimodal_Spike_Properties(:,4,1)) mean(Bimodal_Spike_Properties(:,4,1))],'k','LineWidth',3)
plot([1.75 2.25],[median(Bimodal_Spike_Properties(:,4,1)) median(Bimodal_Spike_Properties(:,4,1))],'k--','LineWidth',3)
plot([2.75 3.25],[mean(Inhibitory_Spike_Properties(:,4,1)) mean(Inhibitory_Spike_Properties(:,4,1))],'k','LineWidth',3)
plot([2.75 3.25],[median(Inhibitory_Spike_Properties(:,4,1)) median(Inhibitory_Spike_Properties(:,4,1))],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData),min(handle(B3(2,3)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData),max(handle(B3(1,3)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Spike_Halfheight_Width_(Y=%dto%d)(UniVsBip=%d)(UniVsInhp=%d)(BiVsInhp=%d).jpg'');',Y_Lim(1),Y_Lim(2),Uni_Vs_Bi_P_Value,Uni_Vs_Inh_P_Value,Bi_Vs_Inh_P_Value));
clear B1;
clear B2;
clear B3;
clear Y_Min;
clear Y_Max;
clear Uni_Vs_Bi_P_Value;
clear Uni_Vs_Inh_P_Value;
clear Bi_Vs_Inh_P_Value;
close

figure;
hold on;
P_Value=ranksum(Unimodal_Spike_Properties(:,5),Bimodal_Spike_Properties(:,5));
B1=boxplot([Unimodal_Spike_Properties(:,5,1),-1000*ones(size(Unimodal_Spike_Properties(:,5,1),1),1)]);
B2=boxplot([-1000*ones(size(Bimodal_Spike_Properties(:,5,1),1),1),Bimodal_Spike_Properties(:,5,1)]);
plot([0.75 1.25],[mean(Unimodal_Spike_Properties(:,5,1)) mean(Unimodal_Spike_Properties(:,5,1))],'k','LineWidth',3)
plot([1.75 2.25],[mean(Bimodal_Spike_Properties(:,5,1)) mean(Bimodal_Spike_Properties(:,5,1))],'k','LineWidth',3)
plot([0.75 1.25],[median(Unimodal_Spike_Properties(:,5,1)) median(Unimodal_Spike_Properties(:,5,1))],'k--','LineWidth',3)
plot([1.75 2.25],[median(Bimodal_Spike_Properties(:,5,1)) median(Bimodal_Spike_Properties(:,5,1))],'k--','LineWidth',3)
Y_Min=min([min(handle(B1(2,1)).YData),min(handle(B2(2,2)).YData)]);
Y_Max=max([max(handle(B1(1,1)).YData),max(handle(B2(1,2)).YData)]);
figure;plot([1,1],[Y_Min,Y_Max]);Y_Lim=ylim;close
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS12_Burst_Index_(Y=%dto%d)(p=%d).jpg'');',Y_Lim(1),Y_Lim(2),P_Value));
clear B1;
clear B2;
clear Y_Min;
clear Y_Max;
clear P_Value;
close

cd ..
cd ..
cd ..

