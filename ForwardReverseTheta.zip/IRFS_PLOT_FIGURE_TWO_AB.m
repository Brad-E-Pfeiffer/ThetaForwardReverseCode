% This makes all the panels for Figure 2A and 2B

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Spike_Properties
        load Modality
        load Spike_Data
        All_Modality(:,3)=1;
        for N=1:length(Inhibitory_Neurons)
            All_Modality(All_Modality(:,2)==Inhibitory_Neurons(N),3)=0;
        end
        
        if exist('Unimodal_Spike_Properties','var')
            Unimodal_Spike_Properties=[Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
            Bimodal_Spike_Properties=[Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
            Inhibitory_Spike_Properties=[Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
        else
            Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
            Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
            Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
        end
        
        if strcmp(Directory_Name(1),'L')
            if exist('Linear_Unimodal_Spike_Properties','var')
                Linear_Unimodal_Spike_Properties=[Linear_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                Linear_Bimodal_Spike_Properties=[Linear_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                Linear_Inhibitory_Spike_Properties=[Linear_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                Linear_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                Linear_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                Linear_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        else
            if exist('OpenField_Unimodal_Spike_Properties','var')
                OpenField_Unimodal_Spike_Properties=[OpenField_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Bimodal_Spike_Properties=[OpenField_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Inhibitory_Spike_Properties=[OpenField_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                OpenField_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                OpenField_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                OpenField_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

cd AllRatsCombined
load Cell_Modality_Information
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end

if exist('Figure2','dir')==7
    cd Figure2
else
    mkdir('Figure2')
    cd Figure2
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(All_Unimodal_Firing_Rate_Per_Phase,2)*2),[mean(All_Unimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Unimodal_Firing_Rate_Per_Phase(:,:,3),1)],[std(All_Unimodal_Firing_Rate_Per_Phase(:,:,3))/sqrt(size(All_Unimodal_Firing_Rate_Per_Phase,1)),std(All_Unimodal_Firing_Rate_Per_Phase(:,:,3))/sqrt(size(All_Unimodal_Firing_Rate_Per_Phase,1))],'r','LineWidth',3)
errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(All_Bimodal_Firing_Rate_Per_Phase,2)*2),[mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1)],[std(All_Bimodal_Firing_Rate_Per_Phase(:,:,3))/sqrt(size(All_Bimodal_Firing_Rate_Per_Phase,1)),std(All_Bimodal_Firing_Rate_Per_Phase(:,:,3))/sqrt(size(All_Bimodal_Firing_Rate_Per_Phase,1))],'b','LineWidth',3)
plot(Phase_Bin:Phase_Bin:Phase_Bin*(size(All_Unimodal_Firing_Rate_Per_Phase,2)*2),[mean(All_Unimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Unimodal_Firing_Rate_Per_Phase(:,:,3),1)],'r','LineWidth',6)
plot(Phase_Bin:Phase_Bin:Phase_Bin*(size(All_Bimodal_Firing_Rate_Per_Phase,2)*2),[mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1)],'b','LineWidth',6)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(All_Bimodal_Firing_Rate_Per_Phase,2)*2)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
eval(sprintf('print(''-djpeg'',''Figure2B_(Red=Unimodal(N=%d);Blue=Bimodal(N=%d))(X=0to720)(Y=%dto%d).jpg'');',size(All_Unimodal_Firing_Rate_Per_Phase,1),size(All_Bimodal_Firing_Rate_Per_Phase,1),Y_Lim(1),Y_Lim(2)));
close;

%The cell number in the file name is the correct cell number -- the number used to pull the data is sometimes off because that is the Excitatory Neuron index, but the Cell Number is based on all cells. 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(49,:,4),Janni_Open1_Firing_Rate_Per_Phase(49,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(49,:,5),Janni_Open1_Firing_Rate_Per_Phase(49,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_UpperLeft_Janni_Open1_Cell50_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(60,:,4),Janni_Open1_Firing_Rate_Per_Phase(60,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(60,:,5),Janni_Open1_Firing_Rate_Per_Phase(60,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_UpperMiddle_Janni_Open1_Cell61_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(98,:,4),Janni_Open1_Firing_Rate_Per_Phase(98,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(98,:,5),Janni_Open1_Firing_Rate_Per_Phase(98,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_UpperRight_Janni_Open1_Cell99_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(19,:,4),Janni_Open1_Firing_Rate_Per_Phase(19,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(19,:,5),Janni_Open1_Firing_Rate_Per_Phase(19,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_LowerLeft_Janni_Open1_Cell19_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(11,:,4),Janni_Open1_Firing_Rate_Per_Phase(11,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(11,:,5),Janni_Open1_Firing_Rate_Per_Phase(11,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_LowerMiddle_Janni_Open1_Cell11_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open1_Firing_Rate_Per_Phase(199,:,4),Janni_Open1_Firing_Rate_Per_Phase(199,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open1_Firing_Rate_Per_Phase(199,:,5),Janni_Open1_Firing_Rate_Per_Phase(199,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2A_LowerRight_Janni_Open1_Cell208_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

cd ..
cd ..
cd ..

