function [Weighted_Position_Correlation]=IRFS_WEIGHTED_CORRELATION(Matrix)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This takes a two-dimensional matrix of position probabilities across time
% and calculates the weighted correlation.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Weighted_Correlation_Matrix=zeros(size(Matrix,1)*size(Matrix,2),3);
Location=1;
for N=1:size(Matrix,1)
    for M=1:size(Matrix,2)
        Weighted_Correlation_Matrix(Location,1)=N;
        Weighted_Correlation_Matrix(Location,2)=M;
        Weighted_Correlation_Matrix(Location,3)=Matrix(N,M);
        Location=Location+1;
    end
end
clear Location;
Weighted_Time_Mean=sum(Weighted_Correlation_Matrix(:,1).*Weighted_Correlation_Matrix(:,3))/sum(Weighted_Correlation_Matrix(:,3));
Weighted_Position_Mean=sum(Weighted_Correlation_Matrix(:,2).*Weighted_Correlation_Matrix(:,3))/sum(Weighted_Correlation_Matrix(:,3));
Weighted_Covariance_TimePosition=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean).*(Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
Weighted_Covariance_TimeTime=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean).*(Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
Weighted_Covariance_PositionPosition=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean).*(Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
Weighted_Position_Correlation=Weighted_Covariance_TimePosition/(sqrt(Weighted_Covariance_TimeTime*Weighted_Covariance_PositionPosition));
clear Weighted_Time_Mean;
clear Weighted_Position_Mean;
clear Weighted_Covariance_TimePosition;
clear Weighted_Covariance_TimeTime;
clear Weighted_Covariance_PositionPosition;