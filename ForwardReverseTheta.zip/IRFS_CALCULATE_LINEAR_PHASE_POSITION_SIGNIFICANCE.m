function IRFS_CALCULATE_LINEAR_PHASE_POSITION_SIGNIFICANCE(Modality,Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function first calculates the significance of the relationship
% between firing phase and location within the place field for each cell.
% It treats IN and OUT runs independently.
%
% This function only runs for linear track sessions.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Spike_Data_With_Linear_Position','Restricted_Spike_Data','Restricted_Spike_Information')
Restricted_Spike_Data(Restricted_Spike_Data(:,3)==0,3)=360;
% Restricted_Spike_Data (restricted because it excludes the ends of the track)
%|     1    |     2   |       3     |                           4                             |                      5                       |                            6                        |          7         ||
%| Time (s) | Cell ID | Theta Phase | Duration of LFP Oscillation (seconds, trough-to-trough) | Monotonically Increasing Cycle? (1=yes;0=no) | Time of LFP Trace That The Phase Was Taken From (s) | Movement Direction ||

Index=Restricted_Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & ~isnan(Restricted_Spike_Data(:,8));
Spike_Data=Restricted_Spike_Data(Index,:);

Out_Phase_Position_Significances=-ones(max(Spike_Data(:,2)),7); %Major R, Major P, Minor R, Minor P, Modality, # Spikes in Major, # Spikes in Minor
In_Phase_Position_Significances=-ones(max(Spike_Data(:,2)),7); %Major R, Major P, Minor R, Minor P, Modality, # Spikes in Major, # Spikes in Minor
Out_Phase_Position_Significances_Restricted_Positions=-ones(max(Spike_Data(:,2)),7); %Major R, Major P, Minor R, Minor P, Modality, # Spikes in Major, # Spikes in Minor
In_Phase_Position_Significances_Restricted_Positions=-ones(max(Spike_Data(:,2)),7); %Major R, Major P, Minor R, Minor P, Modality, # Spikes in Major, # Spikes in Minor
%The restricted positions is a way to get around the 'bleed-through' from the previous cycle 

for Current_Cell=1:max(Spike_Data(:,2))
    Cell_Modality=Modality(Current_Cell,1);
    if Cell_Modality==1 || Cell_Modality==2
        Out_Current_Cell_Spikes=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Data(:,7)==1,:);
        In_Current_Cell_Spikes=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Data(:,7)==-1,:);
        if size(Out_Current_Cell_Spikes,1)>=100
            Major_Spikes=Out_Current_Cell_Spikes(Out_Current_Cell_Spikes(:,3)>=Major_Peak_Window(1) | Out_Current_Cell_Spikes(:,3)<=Major_Peak_Window(2),:);
            Major_Spikes(Major_Spikes(:,3)<=Major_Peak_Window(2),3)=Major_Spikes(Major_Spikes(:,3)<=Major_Peak_Window(2),3)+360;
            Minor_Spikes=Out_Current_Cell_Spikes(Out_Current_Cell_Spikes(:,3)>=Minor_Peak_Window(1) & Out_Current_Cell_Spikes(:,3)<=Minor_Peak_Window(2),:);
            [Major_R,Major_P]=corr(Major_Spikes(:,3),Major_Spikes(:,8));
            [Minor_R,Minor_P]=corr(Minor_Spikes(:,3),Minor_Spikes(:,8));
            [Major_R_Restricted_Positions,Major_P_Restricted_Positions]=corr(Major_Spikes(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10),3),Major_Spikes(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10),8));
            [Minor_R_Restricted_Positions,Minor_P_Restricted_Positions]=corr(Minor_Spikes(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10),3),Minor_Spikes(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10),8));
            Out_Phase_Position_Significances(Current_Cell,:)=[Major_R,Major_P,Minor_R,Minor_P,Cell_Modality,size(Major_Spikes,1),size(Minor_Spikes,1)];
            Out_Phase_Position_Significances_Restricted_Positions(Current_Cell,:)=[Major_R_Restricted_Positions,Major_P_Restricted_Positions,Minor_R_Restricted_Positions,Minor_P_Restricted_Positions,Cell_Modality,sum(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10)),sum(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10))];
        end
        if size(In_Current_Cell_Spikes,1)>=100
            Major_Spikes=In_Current_Cell_Spikes(In_Current_Cell_Spikes(:,3)>=Major_Peak_Window(1) | In_Current_Cell_Spikes(:,3)<=Major_Peak_Window(2),:);
            Major_Spikes(Major_Spikes(:,3)<=Major_Peak_Window(2),3)=Major_Spikes(Major_Spikes(:,3)<=Major_Peak_Window(2),3)+360;
            Minor_Spikes=In_Current_Cell_Spikes(In_Current_Cell_Spikes(:,3)>=Minor_Peak_Window(1) & In_Current_Cell_Spikes(:,3)<=Minor_Peak_Window(2),:);
            [Major_R,Major_P]=corr(Major_Spikes(:,3),Major_Spikes(:,8));
            [Minor_R,Minor_P]=corr(Minor_Spikes(:,3),Minor_Spikes(:,8));
            [Major_R_Restricted_Positions,Major_P_Restricted_Positions]=corr(Major_Spikes(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10),3),Major_Spikes(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10),8));
            [Minor_R_Restricted_Positions,Minor_P_Restricted_Positions]=corr(Minor_Spikes(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10),3),Minor_Spikes(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10),8));
            In_Phase_Position_Significances(Current_Cell,:)=[Major_R,Major_P,Minor_R,Minor_P,Cell_Modality,size(Major_Spikes,1),size(Minor_Spikes,1)];
            In_Phase_Position_Significances_Restricted_Positions(Current_Cell,:)=[Major_R_Restricted_Positions,Major_P_Restricted_Positions,Minor_R_Restricted_Positions,Minor_P_Restricted_Positions,Cell_Modality,sum(Major_Spikes(:,8)<=0.5 & Major_Spikes(:,3)>=(Major_Peak_Window(1)+10) & Major_Spikes(:,3)<=(Major_Peak_Window(2)+360-10)),sum(Minor_Spikes(:,8)>=-0.5 & Minor_Spikes(:,3)>=(Minor_Peak_Window(1)+10) & Minor_Spikes(:,3)<=(Minor_Peak_Window(2)-10))];
        end
    end
end
        
save('Phase_Position_Significances_Per_Cell','Out_Phase_Position_Significances','In_Phase_Position_Significances','Out_Phase_Position_Significances_Restricted_Positions','In_Phase_Position_Significances_Restricted_Positions');

end

