
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script calculates the z-scored power of beta, low-gamma, and
% high-gamma during theta oscillations containing significant or
% non-significant forward and reverse sequences.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------




save('Beta_And_Gamma_Power_In_Signficant_Sequences','-v7.3');
    
