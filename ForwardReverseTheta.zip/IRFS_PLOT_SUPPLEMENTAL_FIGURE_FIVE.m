function IRFS_PLOT_SUPPLEMENTAL_FIGURE_FIVE

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Individual_Theta_Sequence_P_Values
        eval(sprintf('%s%s_Number=Qualifying_Oscillation_Count;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Significant=(sum((Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05) | (Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05))/Qualifying_Oscillation_Count)*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Forward=Significant_Forward_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Reverse=Significant_Reverse_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Forward_Positive=Significant_Positive_Forward_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Forward_Negative=Significant_Negative_Forward_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Reverse_Positive=Significant_Positive_Reverse_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Reverse_Negative=Significant_Negative_Reverse_Sequence_Percent*100;',Rat_Name,Directory_Name));
        eval(sprintf('%s%s_Forward_And_Reverse=Significant_Positive_Forward_Negative_Reverse_Sequence_Percent*100;',Rat_Name,Directory_Name));
        
        cd ..
    end
    clear Directory
    cd ..
end
clear Rat
clear Experiment
clear Rats
cd AllRatsCombined
cd _Figures_For_Paper
if exist('SupplementalFigure5','dir')==7
    cd SupplementalFigure5
else
    mkdir SupplementalFigure5
    cd SupplementalFigure5
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar(1:16,[JanniLinear1_Significant,JanniLinear2_Significant,JanniLinear3_Significant,JanniLinear4_Significant,JanniLinear5_Significant,JanniLinear6_Significant,HarpyLinear1_Significant,HarpyLinear2_Significant,ImpLinear1_Significant,ImpLinear2_Significant,JanniOpen1_Significant,JanniOpen2_Significant,HarpyOpen1_Significant,HarpyOpen2_Significant,ImpOpen1_Significant,ImpOpen2_Significant],'k');
set(gca,'YLim',[0 100]);
set(gca,'XLim',[0 17]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Supplemental_Figure_5_Percent_Of_Oscillations_With_A_Significant_Sequence(Y=0to100).jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar(1:47,[JanniLinear1_Forward/(JanniLinear1_Significant),JanniLinear1_Reverse/(JanniLinear1_Significant),0,JanniLinear2_Forward/(JanniLinear2_Significant),JanniLinear2_Reverse/(JanniLinear2_Significant),0,JanniLinear3_Forward/(JanniLinear3_Significant),JanniLinear3_Reverse/(JanniLinear3_Significant),0,JanniLinear4_Forward/(JanniLinear4_Significant),JanniLinear4_Reverse/(JanniLinear4_Significant),0,JanniLinear5_Forward/(JanniLinear5_Significant),JanniLinear5_Reverse/(JanniLinear5_Significant),0,JanniLinear6_Forward/(JanniLinear6_Significant),JanniLinear6_Reverse/(JanniLinear6_Significant),0,HarpyLinear1_Forward/(HarpyLinear1_Significant),HarpyLinear1_Reverse/(HarpyLinear1_Significant),0,HarpyLinear2_Forward/(HarpyLinear2_Significant),HarpyLinear2_Reverse/(HarpyLinear2_Significant),0,ImpLinear1_Forward/(ImpLinear1_Significant),ImpLinear1_Reverse/(ImpLinear1_Significant),0,ImpLinear2_Forward/(ImpLinear2_Significant),ImpLinear2_Reverse/(ImpLinear2_Significant),0,JanniOpen1_Forward/(JanniOpen1_Significant),JanniOpen1_Reverse/(JanniOpen1_Significant),0,JanniOpen2_Forward/(JanniOpen2_Significant),JanniOpen2_Reverse/(JanniOpen2_Significant),0,HarpyOpen1_Forward/(HarpyOpen1_Significant),HarpyOpen1_Reverse/(HarpyOpen1_Significant),0,HarpyOpen2_Forward/(HarpyOpen2_Significant),HarpyOpen2_Reverse/(HarpyOpen2_Significant),0,ImpOpen1_Forward/(ImpOpen1_Significant),ImpOpen1_Reverse/(ImpOpen1_Significant),0,ImpOpen2_Forward/(ImpOpen2_Significant),ImpOpen2_Reverse/(ImpOpen2_Significant)],'k');
set(gca,'YLim',[0 1]);
set(gca,'XLim',[0 48]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Supplemental_Figure_5_Relative_Percent_Of_Sequences_In_Forward_Or_Reverse_Window(Y=0to100).jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar(1:16,[JanniLinear1_Forward_And_Reverse,JanniLinear2_Forward_And_Reverse,JanniLinear3_Forward_And_Reverse,JanniLinear4_Forward_And_Reverse,JanniLinear5_Forward_And_Reverse,JanniLinear6_Forward_And_Reverse,HarpyLinear1_Forward_And_Reverse,HarpyLinear2_Forward_And_Reverse,ImpLinear1_Forward_And_Reverse,ImpLinear2_Forward_And_Reverse,JanniOpen1_Forward_And_Reverse,JanniOpen2_Forward_And_Reverse,HarpyOpen1_Forward_And_Reverse,HarpyOpen2_Forward_And_Reverse,ImpOpen1_Forward_And_Reverse,ImpOpen2_Forward_And_Reverse],'k');
plot([0.5 1.5],ones(1,2).*((JanniLinear1_Forward_Positive*JanniLinear1_Reverse_Negative)/100),'r--');
plot([1.5 2.5],ones(1,2).*((JanniLinear2_Forward_Positive*JanniLinear2_Reverse_Negative)/100),'r--');
plot([2.5 3.5],ones(1,2).*((JanniLinear3_Forward_Positive*JanniLinear3_Reverse_Negative)/100),'r--');
plot([3.5 4.5],ones(1,2).*((JanniLinear4_Forward_Positive*JanniLinear4_Reverse_Negative)/100),'r--');
plot([4.5 5.5],ones(1,2).*((JanniLinear5_Forward_Positive*JanniLinear5_Reverse_Negative)/100),'r--');
plot([5.5 6.5],ones(1,2).*((JanniLinear6_Forward_Positive*JanniLinear6_Reverse_Negative)/100),'r--');
plot([6.5 7.5],ones(1,2).*((HarpyLinear1_Forward_Positive*HarpyLinear1_Reverse_Negative)/100),'r--');
plot([7.5 8.5],ones(1,2).*((HarpyLinear2_Forward_Positive*HarpyLinear2_Reverse_Negative)/100),'r--');
plot([8.5 9.5],ones(1,2).*((ImpLinear1_Forward_Positive*ImpLinear1_Reverse_Negative)/100),'r--');
plot([9.5 10.5],ones(1,2).*((ImpLinear2_Forward_Positive*ImpLinear2_Reverse_Negative)/100),'r--');
plot([10.5 11.5],ones(1,2).*((JanniOpen1_Forward_Positive*JanniOpen1_Reverse_Negative)/100),'r--');
plot([11.5 12.5],ones(1,2).*((JanniOpen2_Forward_Positive*JanniOpen2_Reverse_Negative)/100),'r--');
plot([12.5 13.5],ones(1,2).*((HarpyOpen1_Forward_Positive*HarpyOpen1_Reverse_Negative)/100),'r--');
plot([13.5 14.5],ones(1,2).*((HarpyOpen2_Forward_Positive*HarpyOpen2_Reverse_Negative)/100),'r--');
plot([14.5 15.5],ones(1,2).*((ImpOpen1_Forward_Positive*ImpOpen1_Reverse_Negative)/100),'r--');
plot([15.5 16.5],ones(1,2).*((ImpOpen2_Forward_Positive*ImpOpen2_Reverse_Negative)/100),'r--');
for N=1:16
    if N==1
        String='JanniLinear1';
    elseif N==2
        String='JanniLinear2';
    elseif N==3
        String='JanniLinear3';
    elseif N==4
        String='JanniLinear4';
    elseif N==5
        String='JanniLinear5';
    elseif N==6
        String='JanniLinear6';
    elseif N==7
        String='HarpyLinear1';
    elseif N==8
        String='HarpyLinear2';
    elseif N==9
        String='ImpLinear1';
    elseif N==10
        String='ImpLinear2';
    elseif N==11
        String='JanniOpen1';
    elseif N==12
        String='JanniOpen2';
    elseif N==13
        String='HarpyOpen1';
    elseif N==14
        String='HarpyOpen2';
    elseif N==15
        String='ImpOpen1';
    elseif N==16
        String='ImpOpen2';
    end
    P_Value=eval(sprintf('1-binocdf((%s_Forward_And_Reverse/100)*%s_Number,%s_Number,(%s_Forward_Positive/100)*(%s_Reverse_Negative/100))',String,String,String,String,String));
    if P_Value<=0.00001
        plot(N,19,'*r')
        plot(N,18.5,'*r')
        plot(N,18,'*r')
    elseif P_Value<=0.0001
        plot(N,19,'*r')
        plot(N,18.5,'*r')
    elseif P_Value<=0.001
        plot(N,19,'*r')
    elseif P_Value<=0.01
        plot(N,19,'+r')
    elseif P_Value<=0.05
        plot(N,19,'or')
    end
end
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XLim',[0 17]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_5_Percent_Of_Combined_Positive_And_Negative_Sequences_In_Forward_And_Reverse_Windows(Y=0-%d).jpg'');',Y_Lim(2)));
close

cd ..
cd ..
cd ..

end

