function IRFS_PROCESS_RAW_DATA(Initial_Variables,Timepoints_To_Remove)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function processes the raw data (raw spikes, raw position, raw LFP)
% and calculates several analysis-critical variables, like place fields,
% theta-filtered LFP, etc.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if exist('Completed_Process_Raw_Data.mat','file')~=2
            
            Spike_Position_Integration_Minimum_Time_Difference=Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference;
            Bin_Size=Initial_Variables.Bin_Size;
            Place_Field_Velocity_Cutoff=Initial_Variables.Place_Field_Velocity_Cutoff;
            Place_Field_Firing_Rate_Cutoff=Initial_Variables.Place_Field_Firing_Rate_Cutoff;
            Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
            Limit_Analysis_By_Theta_Length=Initial_Variables.Limit_Analysis_By_Theta_Length;
            Theta_Length_Min_Max=Initial_Variables.Theta_Length_Min_Max;
            Number_Of_Shuffles=Initial_Variables.Number_Of_Shuffles;
            Phase_Bin=Initial_Variables.Phase_Bin;
            Gaussian_Smoothing_Sigma=Initial_Variables.Gaussian_Smoothing_Sigma;
            Rayleigh_Test_P_Value_Cutoff=Initial_Variables.Rayleigh_Test_P_Value_Cutoff;
            Minimum_Place_Field_Firing_Rate_Fraction=Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Minimum_Contiguous_Place_Field_Bins=Initial_Variables.Minimum_Contiguous_Place_Field_Bins;
            Velocity_Cutoff=Initial_Variables.Velocity_Cutoff;
            Minimum_Spike_Count=Initial_Variables.Minimum_Spike_Count;
            Decoding_Time_Window=Initial_Variables.Decoding_Time_Window;
            Decoding_Time_Advance=Initial_Variables.Decoding_Time_Advance;
            Use_Maximum_Posterior_Probability=Initial_Variables.Use_Maximum_Posterior_Probability;
            
            Janni_Open2_To_Remove=Timepoints_To_Remove.Janni_Open2_To_Remove;
            Janni_Linear2_To_Remove=Timepoints_To_Remove.Janni_Linear2_To_Remove;
            Janni_Linear3_To_Remove=Timepoints_To_Remove.Janni_Linear3_To_Remove;
            Harpy_Linear1_To_Remove=Timepoints_To_Remove.Harpy_Linear1_To_Remove;
            Harpy_Linear2_To_Remove=Timepoints_To_Remove.Harpy_Linear2_To_Remove;
            Harpy_Linear3_To_Remove=Timepoints_To_Remove.Harpy_Linear3_To_Remove;
            Harpy_Open1_To_Remove=Timepoints_To_Remove.Harpy_Open1_To_Remove;
            Harpy_Open2_To_Remove=Timepoints_To_Remove.Harpy_Open2_To_Remove;
            Imp_Linear1_To_Remove=Timepoints_To_Remove.Imp_Linear1_To_Remove;
            Imp_Open1_To_Remove=Timepoints_To_Remove.Imp_Open1_To_Remove;
            Imp_Open2_To_Remove=Timepoints_To_Remove.Imp_Open2_To_Remove;
            
            disp('==========================================================================');
            disp(sprintf('Starting Analysis for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            
            disp('Loading Raw Spike and Position Data.');
            IRFS_LOAD_AND_PROCESS_RAW_SPIKE_AND_POSITION_DATA
            % Position_Data
            %|    1     |          2      |         3       |            4         |     5    |            6             |            7            ||
            %| Time (s) | X-Position (cm) | Y-Position (cm) | Head Direction (deg) | Velocity | Movement Direction (deg) | Time Between Frames (s) ||
            
            % Spike_Data
            %|     1    |     2   ||
            %| Time (s) | Cell ID ||
            
            disp('Loading Global Theta-Filtered LFP.');
            if exist('LFP_Left_Theta.mat','file')==2
                load LFP_Left_Theta
                LFP_Theta=LFP_Left_Theta;
                clear LFP_Left_Theta;
                LFP_Theta(LFP_Theta(:,4)==0,4)=360;
            else
                LFP_Left_Theta=IRFS_LOAD_GLOBAL_THETA_FILTERED_LFP(Raw_LFP_Root_Directory,Rat,Experiment);
                LFP_Theta=LFP_Left_Theta;
                clear LFP_Left_Theta;
                LFP_Theta(LFP_Theta(:,4)==0,4)=360;
            end
            
            % Integrate the spike data and position data to find where the rat was when
            % each spike was fired.
            if exist('Spike_Information.mat','file')==2
                load Spike_Information;
            else
                disp('Integrating Spike and Position Data.');
                Spike_Information=IRFS_SPIKE_POSITION_INTEGRATION(Position_Data,Spike_Data,Excitatory_Neurons,Inhibitory_Neurons,Left_Cells,Right_Cells,Sleep_Spike_Data,Tetrode_Cell_IDs,Spike_Position_Integration_Minimum_Time_Difference);
            end
            clear Left_Cells;
            clear Right_Cells;
            clear Sleep_Spike_Data;
            
            %Make place fields
            if exist('Field_Data.mat','file')==2
                load Field_Data
            else
                disp('Calculating Place Fields.');
                IRFS_CALCULATE_PLACE_FIELDS(Bin_Size,Place_Field_Velocity_Cutoff,Place_Field_Firing_Rate_Cutoff);
                load Field_Data;
            end
            
            disp('Removing Identified Noisy Segments From Analysis.');
            % This removes noisy sections of the experiment and calculates the total duration of this experiment
            IRFS_REMOVE_NOISE_AND_CLEAN_DATA_FOR_ANALYSIS;
            
            disp('Limiting Analysis to Periods of Movement.');
            % This restricts the analysis to periods of movement
            Spike_Data=Spike_Data(Spike_Information(:,4)>=Velocity_Cutoff,:);
            Spike_Information=Spike_Information(Spike_Information(:,4)>=Velocity_Cutoff,:);
            LFP_Theta=LFP_Theta(LFP_Theta(:,1)>=min(Spike_Data(:,1)) & LFP_Theta(:,1)<=max(Spike_Data(:,1)),:);
            
            disp('Calculating Mean Decoding Error During Behavior.')
            if exist('Position_Decoding_Error.mat','file')==2
                load Position_Decoding_Error
            else
                IRFS_CALCULATE_DECODING_ERROR(Position_Data,Spike_Data,Inhibitory_Neurons,Field_Data,Bin_Size,Velocity_Cutoff,[min(Spike_Data(:,1)) max(Spike_Data(:,1))],0.25,0.25,Rat_Name);
                load Position_Decoding_Error
            end
            
            Completed_Process_Raw_Data=1;
            save('Completed_Process_Raw_Data','Completed_Process_Raw_Data');
            
            clearvars -except Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name
            
        end
            
        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables Timepoints_To_Remove

end

