function IRFS_PROCESS_THETA_SEQUENCE_DECODED_CONTENT(Initial_Variables,Timepoints_To_Remove)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function uses the previously processed data to decode the spatial
% information content of theta sequences and analyze the encoded paths.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if 1%exist('Completed_Theta_Sequence_Content.mat','file')~=2
            
            disp('--------------------------------------------------------------------------');
            disp(sprintf('Starting Bayesian Decoding and Analysis of Theta Sequence Content for Rat: %s, Session: %s.',Rat_Name,Directory_Name));

            Spike_Position_Integration_Minimum_Time_Difference=Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference;
            Bin_Size=Initial_Variables.Bin_Size;
            Place_Field_Velocity_Cutoff=Initial_Variables.Place_Field_Velocity_Cutoff;
            Place_Field_Firing_Rate_Cutoff=Initial_Variables.Place_Field_Firing_Rate_Cutoff;
            Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
            Limit_Analysis_By_Theta_Length=Initial_Variables.Limit_Analysis_By_Theta_Length;
            Theta_Length_Min_Max=Initial_Variables.Theta_Length_Min_Max;
            Number_Of_Shuffles=Initial_Variables.Number_Of_Shuffles;
            Phase_Bin=Initial_Variables.Phase_Bin;
            Gaussian_Smoothing_Sigma=Initial_Variables.Gaussian_Smoothing_Sigma;
            Rayleigh_Test_P_Value_Cutoff=Initial_Variables.Rayleigh_Test_P_Value_Cutoff;
            Minimum_Place_Field_Firing_Rate_Fraction=Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Minimum_Contiguous_Place_Field_Bins=Initial_Variables.Minimum_Contiguous_Place_Field_Bins;
            Velocity_Cutoff=Initial_Variables.Velocity_Cutoff;
            Minimum_Spike_Count=Initial_Variables.Minimum_Spike_Count;
            Decoding_Time_Window=Initial_Variables.Decoding_Time_Window;
            Decoding_Time_Advance=Initial_Variables.Decoding_Time_Advance;
            Use_Maximum_Posterior_Probability=Initial_Variables.Use_Maximum_Posterior_Probability;
            
            Janni_Open2_To_Remove=Timepoints_To_Remove.Janni_Open2_To_Remove;
            Janni_Linear2_To_Remove=Timepoints_To_Remove.Janni_Linear2_To_Remove;
            Janni_Linear3_To_Remove=Timepoints_To_Remove.Janni_Linear3_To_Remove;
            Harpy_Linear1_To_Remove=Timepoints_To_Remove.Harpy_Linear1_To_Remove;
            Harpy_Linear2_To_Remove=Timepoints_To_Remove.Harpy_Linear2_To_Remove;
            Harpy_Linear3_To_Remove=Timepoints_To_Remove.Harpy_Linear3_To_Remove;
            Harpy_Open1_To_Remove=Timepoints_To_Remove.Harpy_Open1_To_Remove;
            Harpy_Open2_To_Remove=Timepoints_To_Remove.Harpy_Open2_To_Remove;
            Imp_Linear1_To_Remove=Timepoints_To_Remove.Imp_Linear1_To_Remove;
            Imp_Open1_To_Remove=Timepoints_To_Remove.Imp_Open1_To_Remove;
            Imp_Open2_To_Remove=Timepoints_To_Remove.Imp_Open2_To_Remove;
            
            disp('Loading Data.')
            IRFS_LOAD_DATA_FOR_THETA_SEQUENCE_DECODING;
            
            disp('Removing Identified Noisy Segments From Analysis.');
            % This removes noisy sections of the experiment and calculates the total duration of this experiment
            IRFS_REMOVE_NOISE_AND_CLEAN_DATA_FOR_ANALYSIS;

            disp('Calculating Properties of Theta Oscillations.')
            if exist('Decoding_Time_Info.mat','file')==2 && exist('Decoding_Spike_Index.mat','file')==2
                load('Decoding_Time_Info','Decoding_Times','Decoding_Window_Index','Ending_Time','Starting_Time','Decoding_Time_Info')
                load Decoding_Spike_Index
            else
                IRFS_CALCULATE_THETA_OSCILLATION_PROPERTIES;
            end
            % Decoding_Time_Info
            % |       1         |         2       |          3          |        4      |            5            |      6      |           7        |        8          |                             9                           |                                      10                                    |      11     |               12             |              13              |               14            ||
            % | Real X Pos (cm) | Real Y Pos (cm) | Real Head Direction | Real Velocity | Real Movement Direction | Theta Phase | Spikes In This Bin | Cells In This Bin | Velocity Above Threshold for Both Flanking Oscillation? | Current Theta Oscillaton Meets Duration and Monotonic Increasing Criteria? | Theta Power | Total Spikes In Major Window | Total Spikes in Minor Window | Theta Oscillation ID Number ||
            %
            % Decoding_Times is the mid-point of each decoding window
            %
            % Decoding_Window_Index is an index of which decoding window from Decoding_Times and Decoding_Time_Info was used (i.e., if the rat was running and if it had spikes)
            %
            % Decoding_Spike_Index is a list of the cell IDs for all spikes that fire in each decoding window for faster decoding in the future
            
            warning('off','all');
            disp('Decoding Spatial Representation')
            if exist('Decoded_Data_And_Sequences.mat','file')==2
                load Decoded_Data_And_Sequences
            else
                IRFS_DECODE_THETA_SEQUENCES;
            end
            
            disp('Decoding Linear Spatial Representation')
            if exist('Decoded_Linear_Data_And_Sequences.mat','file')==2
                load Decoded_Linear_Data_And_Sequences
            elseif strcmp(Directory_Name(1),'L')
                IRFS_DECODE_LINEAR_THETA_SEQUENCES;
            end
            
            disp('Decoding Spatial Representation Using Only Unimodal Neurons')
            if exist('Decoded_Data_And_Sequences_With_Unimodal_Cells.mat','file')==2
                load Decoded_Data_And_Sequences_With_Unimodal_Cells
                if strcmp(Directory_Name(1),'L')
                    load Decoded_Linear_Data_And_Sequences_With_Unimodal_Cells
                end
            else
                IRFS_DECODE_THETA_SEQUENCES_USING_ONLY_UNIMODAL_CELLS;
            end
            
            disp('Decoding Spatial Representation Using Only Bimodal Neurons')
            if exist('Decoded_Data_And_Sequences_With_Bimodal_Cells.mat','file')==2
                load Decoded_Data_And_Sequences_With_Bimodal_Cells
                if strcmp(Directory_Name(1),'L')
                    load Decoded_Linear_Data_And_Sequences_With_Bimodal_Cells
                end
            else
                IRFS_DECODE_THETA_SEQUENCES_USING_ONLY_BIMODAL_CELLS;
            end
            warning('on','all');
            
            disp('Comparing Decoding With Only Unimodal Cells Versus Decoding With Only Bimodal Cells')
            if exist('Comparison_Between_Unimodal_And_Bimodal_Decoding.mat','file')==2
                load Comparison_Between_Unimodal_And_Bimodal_Decoding
            else
                IRFS_COMPARE_UNIMODAL_ONLY_TO_BIMODAL_ONLY_THETA_SEQUENCES;
            end
            warning('on','all');
            
            disp('Calculating Average Theta Sequence And Posterior Probability Distributions Per Phase')
            IRFS_CALCULATE_AVERAGE_AND_POSTERIOR_DISTRIBUTIONS;
            IRFS_CALCULATE_AVERAGE_AND_POSTERIOR_DISTRIBUTIONS_UNI_VS_BI;

            if 1
                disp('Creating Shuffled Data')
                warning('off','all');
                IRFS_THETA_SEQUENCE_SHUFFLE_GENERATION;
                warning('on','all');
            end
            
            disp('Quantifying significance of each individual forward and reverse theta sequence.')
            IRFS_QUANTIFY_INDIVIDUAL_THETA_SEQUENCE_SIGNIFICANCE(Decoded_Data,Decoding_Time_Info,Decoding_Window_Index,Decoding_Times,Unimodal_Decoded_Data,Unimodal_Decoding_Window_Index,Bimodal_Decoded_Data,Bimodal_Decoding_Window_Index,Number_Of_Shuffles,Forward_Window,Reverse_Window,Initial_Variables);
            
            Completed_Theta_Sequence_Content=1;
            save('Completed_Theta_Sequence_Content','Completed_Theta_Sequence_Content');
            
            clearvars -except Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name Forward_Window Reverse_Window
            
            disp(sprintf('Finished Bayesian Decoding and Analysis of Theta Sequence Content for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            disp('--------------------------------------------------------------------------');
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

clear Rat
clear Experiment
clear Rats

disp('Combining and Saving Decoded Theta Sequence Content Across Rats and Sessions.')
IRFS_COMBINE_AND_SAVE_DECODED_CONTENT_ACROSS_SESSIONS(Initial_Variables);

disp('Combining and Saving Raw and Shuffle Posterior Probability Peak Histograms Across Rats and Sessions.')
IRFS_COMBINE_AND_SAVE_PEAK_POSTERIOR_PROBABILITY_HISTOGRAMS(Initial_Variables);

disp('Quantifying Analysis Windows for Forward/Reverse and Major/Minor Peak Windows.')
IRFS_IDENTIFY_THETA_SEQUENCE_ANALYSIS_WINDOWS(Initial_Variables);  %Simply used to confirm the values laid out at the start of the first function

disp('Combining and Saving Unimodal Vs. Bimodal Decoding Contribution');
IRFS_COMBINE_AND_SAVE_UNIMODAL_VS_BIMODAL_DECODING_CONTRIBUTION(Initial_Variables);

if 1
    IRFS_PLOT_FIGURE_ONE_EXAMPLES;
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_TEN;
end

if 1
    IRFS_PLOT_FIGURE_ONE_B(Initial_Variables);
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_THREE(Initial_Variables);
end

if 1
    IRFS_PLOT_FIGURE_ONE_C(Initial_Variables,Forward_Window,Reverse_Window);
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_FOUR(Initial_Variables,Forward_Window,Reverse_Window);
end

if 1
    IRFS_PLOT_FIGURE_ONE_D_AND_E(Initial_Variables);
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_FIVE;
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_SIX(Initial_Variables);
end

clearvars -except Initial_Variables Timepoints_To_Remove

end

