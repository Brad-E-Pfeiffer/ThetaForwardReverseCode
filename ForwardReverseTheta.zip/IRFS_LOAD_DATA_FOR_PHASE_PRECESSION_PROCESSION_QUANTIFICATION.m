% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script loads the necessary files (many produced by the
% PROCESS_RAW_DATA function) for the quantification of Unimodal and Bimodal
% cells.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Spike_Data','Tetrode_Cell_IDs')
load Spike_Data_With_Theta_Phase
load Spike_Information
load Field_Data
load Modality
load LFP_Left_Theta
LFP_Theta=LFP_Left_Theta;
clear LFP_Left_Theta;
load Position_Data_Processed

