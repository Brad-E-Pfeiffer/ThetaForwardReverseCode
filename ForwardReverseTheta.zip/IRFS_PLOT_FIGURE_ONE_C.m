function IRFS_PLOT_FIGURE_ONE_C(Initial_Variables,Forward_Window,Reverse_Window)

Forward_Window=round(Forward_Window/Initial_Variables.Phase_Bin);
Reverse_Window=round(Reverse_Window/Initial_Variables.Phase_Bin);

cd AllRatsCombined

load Combined_Peak_Posterior_Distributions_Minor_Peak_Third

cd _Figures_For_Paper

if exist('Figure1','dir')==7
    cd('Figure1')
else
    mkdir('Figure1')
    cd('Figure1')
end

clear All_Raw_Data
clear All_Phase_Shuffles
clear All_Cell_Shuffles
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Raw_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Phase_Shuffles=%s_%s_Raw_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Cell_Shuffles=%s_%s_Raw_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        if exist('All_Raw_Data','var')
            All_Raw_Data=All_Raw_Data+Raw_Data;
            All_Phase_Shuffles=All_Phase_Shuffles+Phase_Shuffles;
            All_Cell_Shuffles=All_Cell_Shuffles+Cell_Shuffles;
        else
            All_Raw_Data=Raw_Data;
            All_Phase_Shuffles=Phase_Shuffles;
            All_Cell_Shuffles=Cell_Shuffles;
        end
        
    end
    clear Directory
    
end
Norm_All_Raw_Data=zeros(size(All_Raw_Data,1),size(All_Raw_Data,2));
for N=1:size(All_Raw_Data,2)
    Norm_All_Raw_Data(:,N)=All_Raw_Data(:,N)/sum(All_Raw_Data(:,N));
end
Norm_All_Phase_Shuffles=zeros(size(All_Phase_Shuffles,1),size(All_Phase_Shuffles,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Phase_Shuffles,2)
        Norm_All_Phase_Shuffles(:,N,Shuffle)=All_Phase_Shuffles(:,N,Shuffle)/sum(All_Phase_Shuffles(:,N,Shuffle));
    end
end
Norm_All_Cell_Shuffles=zeros(size(All_Cell_Shuffles,1),size(All_Cell_Shuffles,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Cell_Shuffles,2)
        Norm_All_Cell_Shuffles(:,N,Shuffle)=All_Cell_Shuffles(:,N,Shuffle)/sum(All_Cell_Shuffles(:,N,Shuffle));
    end
end

Forward_Window_Raw_Correlation=WEIGHTED_CORRELATION(Norm_All_Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
Reverse_Window_Raw_Correlation=WEIGHTED_CORRELATION(Norm_All_Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
Phase_Shuffle_Forward_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Phase_Shuffle_Reverse_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Cell_Shuffle_Forward_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Cell_Shuffle_Reverse_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    Phase_Shuffle_Forward_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Phase_Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
    Phase_Shuffle_Reverse_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Phase_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
    Cell_Shuffle_Forward_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Cell_Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
    Cell_Shuffle_Reverse_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Cell_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
end


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-1:0.001:1,hist(Phase_Shuffle_Forward_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Forward_Window_Correlations),'r','LineWidth',4);
plot(-1:0.001:1,hist(Cell_Shuffle_Forward_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Forward_Window_Correlations),'b','LineWidth',4);
Y_Lim=ylim;
if ((sum(abs(Phase_Shuffle_Forward_Window_Correlations)>=abs(Forward_Window_Raw_Correlation))+1)/length(Phase_Shuffle_Forward_Window_Correlations))<=0.05 && ((sum(abs(Cell_Shuffle_Forward_Window_Correlations)>=abs(Forward_Window_Raw_Correlation))+1)/length(Cell_Shuffle_Forward_Window_Correlations))<=0.05 
    plot([Forward_Window_Raw_Correlation,Forward_Window_Raw_Correlation],[0 Y_Lim(2)],'k','LineWidth',10);
else
    plot([Forward_Window_Raw_Correlation,Forward_Window_Raw_Correlation],[0 Y_Lim(2)],'k--','LineWidth',10);
end
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'YTick',[]);
set(gca,'XLim',[-0.1 0.25]);
set(gca,'XTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1C_LinearTrack_FowardWindow(X=-0.1to0.25)(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-1:0.001:1,hist(Phase_Shuffle_Reverse_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Reverse_Window_Correlations),'r','LineWidth',4);
plot(-1:0.001:1,hist(Cell_Shuffle_Reverse_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Reverse_Window_Correlations),'b','LineWidth',4);
Y_Lim=ylim;
if ((sum(abs(Phase_Shuffle_Reverse_Window_Correlations)>=abs(Reverse_Window_Raw_Correlation))+1)/length(Phase_Shuffle_Reverse_Window_Correlations))<=0.05 && ((sum(abs(Cell_Shuffle_Reverse_Window_Correlations)>=abs(Reverse_Window_Raw_Correlation))+1)/length(Cell_Shuffle_Reverse_Window_Correlations))<=0.05 
    plot([Reverse_Window_Raw_Correlation,Reverse_Window_Raw_Correlation],[0 Y_Lim(2)],'k','LineWidth',10);
else
    plot([Reverse_Window_Raw_Correlation,Reverse_Window_Raw_Correlation],[0 Y_Lim(2)],'k--','LineWidth',10);
end
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'YTick',[]);
set(gca,'XLim',[-0.25 0.1]);
set(gca,'XTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1C_LinearTrack_ReverseWindow(X=-0.25to0.1)(Y=0to%d).jpg'');',Y_Lim(2)));
close






clear All_Raw_Data
clear All_Phase_Shuffles
clear All_Cell_Shuffles
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Raw_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Phase_Shuffles=%s_%s_Raw_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Cell_Shuffles=%s_%s_Raw_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        if exist('All_Raw_Data','var')
            All_Raw_Data=All_Raw_Data+Raw_Data;
            All_Phase_Shuffles=All_Phase_Shuffles+Phase_Shuffles;
            All_Cell_Shuffles=All_Cell_Shuffles+Cell_Shuffles;
        else
            All_Raw_Data=Raw_Data;
            All_Phase_Shuffles=Phase_Shuffles;
            All_Cell_Shuffles=Cell_Shuffles;
        end
        
    end
    clear Directory
    
end
Norm_All_Raw_Data=zeros(size(All_Raw_Data,1),size(All_Raw_Data,2));
for N=1:size(All_Raw_Data,2)
    Norm_All_Raw_Data(:,N)=All_Raw_Data(:,N)/sum(All_Raw_Data(:,N));
end
Norm_All_Phase_Shuffles=zeros(size(All_Phase_Shuffles,1),size(All_Phase_Shuffles,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Phase_Shuffles,2)
        Norm_All_Phase_Shuffles(:,N,Shuffle)=All_Phase_Shuffles(:,N,Shuffle)/sum(All_Phase_Shuffles(:,N,Shuffle));
    end
end
Norm_All_Cell_Shuffles=zeros(size(All_Cell_Shuffles,1),size(All_Cell_Shuffles,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Cell_Shuffles,2)
        Norm_All_Cell_Shuffles(:,N,Shuffle)=All_Cell_Shuffles(:,N,Shuffle)/sum(All_Cell_Shuffles(:,N,Shuffle));
    end
end

Forward_Window_Raw_Correlation=WEIGHTED_CORRELATION(Norm_All_Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
Reverse_Window_Raw_Correlation=WEIGHTED_CORRELATION(Norm_All_Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
Phase_Shuffle_Forward_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Phase_Shuffle_Reverse_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Cell_Shuffle_Forward_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
Cell_Shuffle_Reverse_Window_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    Phase_Shuffle_Forward_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Phase_Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
    Phase_Shuffle_Reverse_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Phase_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
    Cell_Shuffle_Forward_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Cell_Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
    Cell_Shuffle_Reverse_Window_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Norm_All_Cell_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
end


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-1:0.001:1,hist(Phase_Shuffle_Forward_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Forward_Window_Correlations),'r','LineWidth',4);
plot(-1:0.001:1,hist(Cell_Shuffle_Forward_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Forward_Window_Correlations),'b','LineWidth',4);
Y_Lim=ylim;
if ((sum(abs(Phase_Shuffle_Forward_Window_Correlations)>=abs(Forward_Window_Raw_Correlation))+1)/length(Phase_Shuffle_Forward_Window_Correlations))<=0.05 && ((sum(abs(Cell_Shuffle_Forward_Window_Correlations)>=abs(Forward_Window_Raw_Correlation))+1)/length(Cell_Shuffle_Forward_Window_Correlations))<=0.05 
    plot([Forward_Window_Raw_Correlation,Forward_Window_Raw_Correlation],[0 Y_Lim(2)],'k','LineWidth',10);
else
    plot([Forward_Window_Raw_Correlation,Forward_Window_Raw_Correlation],[0 Y_Lim(2)],'k--','LineWidth',10);
end
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'YTick',[]);
set(gca,'XLim',[-0.1 0.2]);
set(gca,'XTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1C_OpenField_FowardWindow(X=-0.1to0.2)(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-1:0.001:1,hist(Phase_Shuffle_Reverse_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Reverse_Window_Correlations),'r','LineWidth',4);
plot(-1:0.001:1,hist(Cell_Shuffle_Reverse_Window_Correlations,-1:0.001:1)/length(Phase_Shuffle_Reverse_Window_Correlations),'b','LineWidth',4);
Y_Lim=ylim;
if ((sum(abs(Phase_Shuffle_Reverse_Window_Correlations)>=abs(Reverse_Window_Raw_Correlation))+1)/length(Phase_Shuffle_Reverse_Window_Correlations))<=0.05 && ((sum(abs(Cell_Shuffle_Reverse_Window_Correlations)>=abs(Reverse_Window_Raw_Correlation))+1)/length(Cell_Shuffle_Reverse_Window_Correlations))<=0.05 
    plot([Reverse_Window_Raw_Correlation,Reverse_Window_Raw_Correlation],[0 Y_Lim(2)],'k','LineWidth',10);
else
    plot([Reverse_Window_Raw_Correlation,Reverse_Window_Raw_Correlation],[0 Y_Lim(2)],'k--','LineWidth',10);
end
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'YTick',[]);
set(gca,'XLim',[-0.15 0.1]);
set(gca,'XTick',[]);
eval(sprintf('print(''-djpeg'',''Figure1C_OpenField_ReverseWindow(X=-0.15to0.1)(Y=0to%d).jpg'');',Y_Lim(2)));
close




cd ..
cd ..
cd ..

end
