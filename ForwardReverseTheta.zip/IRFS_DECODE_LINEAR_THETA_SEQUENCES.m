
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function decodes every theta oscillation.  To speed up this process,
% it only decodes theta oscillations where the rat's movement is above the
% Velocity_Threshold for the entire theta oscillaton before and after each
% timepoint. 
% 
% For each decoding window, the data is centered by the rat's current
% location and rotated according to the rat's current movement direction.
% 
% The data is then saved in Decoded_Linear_Data_And_Sequences.mat
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data_Linear2=Field_Data_Linear;
Field_Data_Linear_In2=Field_Data_Linear_In;
Field_Data_Linear_Out2=Field_Data_Linear_Out;
for N=1:size(Field_Data_Linear,2)
    Field=Field_Data_Linear2(:,N);
    Field_In=Field_Data_Linear_In2(:,N);
    Field_Out=Field_Data_Linear_Out2(:,N);
    Minimum=min(Field(Field>0));
    Minimum_In=min(Field_In(Field_In>0));
    Minimum_Out=min(Field_Out(Field_Out>0));
    if ~isempty(Minimum)
        Field(Field<=0)=Minimum/10;
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_In)
        Field_In(Field_In<=0)=Minimum_In/10;
    else
        Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_Out)
        Field_Out(Field_Out<=0)=Minimum_Out/10;
    else
        Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data_Linear2(:,N)=Field;
    Field_Data_Linear_In2(:,N)=Field_In;
    Field_Data_Linear_Out2(:,N)=Field_Out;
    clear Minimum;
    clear Minimum_In;
    clear Minimum_Out;
    clear Field;
    clear Field_In;
    clear Field_Out;
end
clear N;

%This finds the long axis of the linear track and uses the appropriate position and movement direction data
if max(Position_Data(:,2))-min(Position_Data(:,2))>max(Position_Data(:,3))-min(Position_Data(:,3))
    Position_Column=1;
else
    Position_Column=2;
end
Movement_Direction=diff(Decoding_Time_Info(:,Position_Column));
Movement_Direction(end+1,1)=Movement_Direction(end,1);
if Movement_Direction(1,1)==0
    Movement_Direction(1,1)=Movement_Direction(find(Movement_Direction>0,1,'first'));
end
for N=2:length(Movement_Direction)
    if Movement_Direction(N,1)==0
        Movement_Direction(N,1)=Movement_Direction(N-1,1);
    end
end
Movement_Direction(Movement_Direction>=0)=1;
Movement_Direction(Movement_Direction<0)=-1;

Mid_Point=round(size(Field_Data_Linear2,1)/2);   %This defines the size of the canvas for translation analysis

Decoded_Data_Linear_Raw=zeros(size(Field_Data_Linear,1),length(Decoding_Window_Index),3);  %Page 1 is bi-directional fields, Page 2 is In fields, Page 3 is Out fields
Decoded_Data_Linear=zeros(size(Field_Data_Linear,1),length(Decoding_Window_Index));
Decoded_Data_Linear_In=zeros(size(Field_Data_Linear,1),length(Decoding_Window_Index));
Decoded_Data_Linear_Out=zeros(size(Field_Data_Linear,1),length(Decoding_Window_Index));

parfor Current_Decoding_Window=1:length(Decoding_Window_Index)
    
    %Pulls up relevant spikes for this decoding window
    Subset_Spike_Data=Decoding_Spike_Index(:,Current_Decoding_Window);
    Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
        
    %This does the actual decoding for this window
    Decoded_Matrix=prod(Field_Data_Linear2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear,2));
    if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
        Divider=1;
        while isinf(max(max(Decoded_Matrix)))
            Decoded_Matrix=prod((Field_Data_Linear2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
            Divider=Divider+1;
        end
    end
    Decoded_Matrix(Decoded_Matrix<0)=0;
    if max(max(Decoded_Matrix))>0
        Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
    end
    
    Decoded_Matrix_In=prod(Field_Data_Linear_In2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_In,2));
    Decoded_Matrix_Out=prod(Field_Data_Linear_Out2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_Out,2));
    if isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
        Divider=1;
        while isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out)))
            Decoded_Matrix_In=prod((Field_Data_Linear_In2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_In/(2^Divider)),2));
            Decoded_Matrix_Out=prod((Field_Data_Linear_Out2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_Out/(2^Divider)),2));
            Divider=Divider+1;
        end
    end
    Decoded_Matrix_In(Decoded_Matrix_In<0)=0;
    Decoded_Matrix_Out(Decoded_Matrix_Out<0)=0;
    if max(max(Decoded_Matrix_In))>0 && max(max(Decoded_Matrix_Out))>0
        Sum=sum(Decoded_Matrix_In+Decoded_Matrix_Out);
        Decoded_Matrix_In=Decoded_Matrix_In/Sum;
        Decoded_Matrix_Out=Decoded_Matrix_Out/Sum;
    end
    
    %Here is where the decoded data gets relocated to rat's current location
    Location=min([size(Field_Data_Linear,1),max([1,round(Decoding_Time_Info(Decoding_Window_Index(Current_Decoding_Window),Position_Column)/Bin_Size)])]);
    Direction=Movement_Direction(Decoding_Window_Index(Current_Decoding_Window),1);
    Translated_Image=imtranslate(Decoded_Matrix,[0,Mid_Point-Location],'FillValues',0);
    Translated_Image_In=imtranslate(Decoded_Matrix_In,[0,Mid_Point-Location],'FillValues',0);
    Translated_Image_Out=imtranslate(Decoded_Matrix_Out,[0,Mid_Point-Location],'FillValues',0);
    if Direction==-1
        Translated_Image=Translated_Image(end:-1:1,:);
        Translated_Image_In=Translated_Image_In(end:-1:1,:);
        Translated_Image_Out=Translated_Image_Out(end:-1:1,:);
    end        
    
    %Add to the rest of the decoded frames
    Decoded_Data_Linear(:,Current_Decoding_Window)=Translated_Image;
    Decoded_Data_Linear_In(:,Current_Decoding_Window)=Translated_Image_In;
    Decoded_Data_Linear_Out(:,Current_Decoding_Window)=Translated_Image_Out;
    Decoded_Data_Linear_Raw(:,Current_Decoding_Window,:)=permute([Decoded_Matrix,Decoded_Matrix_In,Decoded_Matrix_Out],[1,3,2]);
        
end

Decoded_Data_Linear_In_Moving_Up=Decoded_Data_Linear_In(:,Movement_Direction(Decoding_Window_Index,1)==1);
Decoded_Data_Linear_In_Moving_Down=Decoded_Data_Linear_In(:,Movement_Direction(Decoding_Window_Index,1)==-1);
Decoded_Data_Linear_Out_Moving_Up=Decoded_Data_Linear_Out(:,Movement_Direction(Decoding_Window_Index,1)==1);
Decoded_Data_Linear_Out_Moving_Down=Decoded_Data_Linear_Out(:,Movement_Direction(Decoding_Window_Index,1)==-1);

clear Current_Decoding_Window;
clear Subset_Spike_Data;
clear Divider;
clear Location;
clear Direction;
clear Translated_Image;
clear Translated_Image_In;
clear Translated_Image_Out;
clear Decoded_Matrix;
clear In_Decoded_Matrix;
clear Out_Decoded_Matrix;
clear Mid_Point;
clear Field_Data_Linear2;
clear Field_Data_Linear_In2;
clear Field_Data_Linear_Out2;
clear Position_Column;
clear Decoded_Matrix;
clear Decoded_Matrix_In;
clear Decoded_Matrix_Out;
clear Sum;
save('Decoded_Linear_Data_And_Sequences','Movement_Direction','Decoded_Data_Lin*','Use_Maximum_Posterior_Probability','Decoding_Time_Window','Decoding_Time_Advance','Decoding_Window_Index','-v7.3');
clear Movement_Direction;


