% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script identifies many aspects of the theta sequences,
% including the central times of each decoding window, the rat's position,
% head/movement direction, and velocity at each decoding window, the phase
% of theta at each decoding window, the number of spikes and cells in each
% decoding window, and whether the rat's velocity was above the
% Velocity_Cutoff for a full theta oscillation before and after the
% decoding window.
% 
% It also makes an index of which cells and spikes occur in each decoding
% window to make future decoding much faster.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%tic;

cd ..
cd ..
load('Bimodal_Analysis_Windows','Major_Peak_Window','Minor_Peak_Window');
eval(sprintf('cd %s',Rat_Name));
eval(sprintf('cd %s',Directory_Name));

Theta_Length_Min_Max=Initial_Variables.Theta_Length_Min_Max;

%This is the phase of theta that the theta sequence actually appears to
%start at.  We actually quantify this value later, but we need it defined
%now to facilitate additional analysis.  
Theta_Sequence_Starting_Phase=70;

% First, limit the decoding to excitatory neurons
Excitatory_Spike_Data=Spike_Data;
for N=1:length(Inhibitory_Neurons)
    Excitatory_Spike_Data=Excitatory_Spike_Data(Excitatory_Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;

Theta=LFP_Theta(:,[1,4,3]);
Starting_Time=min(Spike_Data(:,1));
Ending_Time=max(Spike_Data(:,1));
Decoding_Times=(Starting_Time+(Decoding_Time_Window/2):Decoding_Time_Advance:Ending_Time-(Decoding_Time_Window/2))';

%This removes noisy sections or periods of no recording (such as inter-trial sleep sessions) from the analysis to speed things up) 
if eval(sprintf('exist(''%s_%s_To_Remove'',''var'')',Rat_Name,Directory_Name))
    eval(sprintf('Sections_To_Remove=%s_%s_To_Remove;',Rat_Name,Directory_Name));
    for Section=1:size(Sections_To_Remove,1)
        Decoding_Times=Decoding_Times(Decoding_Times(:,1)<Sections_To_Remove(Section,1) | Decoding_Times(:,1)>Sections_To_Remove(Section,2),:);
    end
    clear Section
end
clear Sections_To_Remove

Decoding_Time_Info=zeros(size(Decoding_Times,1),14);
Decoding_Time_Info_With_Inhibitory_Neurons=zeros(size(Decoding_Times,1),14);
% Decoding_Time_Info
% |       1         |         2       |          3          |        4      |            5            |      6      |           7        |        8          |                             9                           |                                      10                                    |      11     |               12             |              13              |               14            ||
% | Real X Pos (cm) | Real Y Pos (cm) | Real Head Direction | Real Velocity | Real Movement Direction | Theta Phase | Spikes In This Bin | Cells In This Bin | Velocity Above Threshold for Both Flanking Oscillation? | Current Theta Oscillaton Meets Duration and Monotonic Increasing Criteria? | Theta Power | Total Spikes In Major Window | Total Spikes in Minor Window | Theta Oscillation ID Number ||

Max_Number_Of_Spikes_Per_Decoding_Window=200;        %Make sure this is larger than you will ever get -- if you're wrong, you'll get an error and the program will crash.
Decoding_Spike_Index=zeros(Max_Number_Of_Spikes_Per_Decoding_Window,length(Decoding_Times));
% Decoding_Spike_Index is a list of the cell IDs for all spikes that fire in each decoding window for faster decoding in the future 

parfor N=1:size(Decoding_Times,1)
    Participating_Spikes=Excitatory_Spike_Data(Excitatory_Spike_Data(:,1)>=(Decoding_Times(N)-(Decoding_Time_Window/2)) & Excitatory_Spike_Data(:,1)<=(Decoding_Times(N)+(Decoding_Time_Window/2)),2);
    Participating_Spikes_With_Inhibitory_Neurons=Spike_Data(Spike_Data(:,1)>=(Decoding_Times(N)-(Decoding_Time_Window/2)) & Spike_Data(:,1)<=(Decoding_Times(N)+(Decoding_Time_Window/2)),2);
    Position_Information=Position_Data(find(abs(Position_Data(:,1)-Decoding_Times(N))==min(abs(Position_Data(:,1)-Decoding_Times(N))),1,'first'),2:6);
    Decoding_Time_Info(N,:)=[Position_Information,0,size(Participating_Spikes,1),length(unique(Participating_Spikes)),0,0,0,0,0,0];
    Decoding_Time_Info_With_Inhibitory_Neurons(N,:)=[Position_Information,0,size(Participating_Spikes_With_Inhibitory_Neurons,1),length(unique(Participating_Spikes_With_Inhibitory_Neurons)),0,0,0,0,0,0];
    if size(Participating_Spikes,1)<Max_Number_Of_Spikes_Per_Decoding_Window
        Participating_Spikes(end+1:Max_Number_Of_Spikes_Per_Decoding_Window,:)=0;
    elseif size(Participating_Spikes,1)>Max_Number_Of_Spikes_Per_Decoding_Window
        error('Too many spikes detected.  Change Max_Number_Of_Spikes_Per_Decoding_Window in IRFS_CALCULATE_THETA_OSCILLATION_PROPERTIES to a larger value!')
    end
    Decoding_Spike_Index(:,N)=Participating_Spikes;
end
clear Position_Information;
clear Participating_Spikes;
clear Participating_Spikes_With_Inhibitory_Neurons;
clear N;
clear Max_Number_Of_Spikes_Per_Decoding_Window

%Trim the Decoding_Spike_Index to make future searching faster
Current_Line=1;
while max(Decoding_Spike_Index(Current_Line,:))>0
    Current_Line=Current_Line+1;
end
Decoding_Spike_Index=Decoding_Spike_Index(1:(Current_Line-1),:);
clear Current_Line;

% Finds the theta phase for each decoding window
if 0
    All_Data_To_Add=zeros(size(Decoding_Times,1),2);
    parfor N=1:size(Decoding_Times,1)  %This is the much slower method
        Data_To_Add=Theta(find(abs(Theta(:,1)-Decoding_Times(N,1))==min(abs(Theta(:,1)-Decoding_Times(N,1))),1,'first'),2:3);
        All_Data_To_Add(N,:)=Data_To_Add;
    end
    Decoding_Time_Info(:,[6,11])=All_Data_To_Add;
    Decoding_Time_Info_With_Inhibitory_Neurons(:,[6,11])=All_Data_To_Add;
    clear N;
    clear Data_To_Add;
    clear All_Data_To_Add;
else
    All_Data_To_Add=zeros(size(Decoding_Times,1),2);
    Histogram=hist(LFP_Theta(:,1),Decoding_Times)';
    First_Index=cumsum(Histogram);
    Second_Index=[1;First_Index(1:end-1)];
    parfor N=1:size(Decoding_Times,1)
        Temp=Theta(max([1,Second_Index(N)-100]):min([First_Index(N)+100,size(Theta,1)]),:);
        Data_To_Add=Temp(find(abs(Temp(:,1)-Decoding_Times(N,1))==min(abs(Temp(:,1)-Decoding_Times(N,1))),1,'first'),2:3);
        All_Data_To_Add(N,:)=Data_To_Add;
    end
    Decoding_Time_Info(:,[6,11])=All_Data_To_Add;
    Decoding_Time_Info_With_Inhibitory_Neurons(:,[6,11])=All_Data_To_Add;    
    clear All_Data_To_Add;
    clear Histogram;
    clear Data_To_Add;
    clear First_Index;
    clear Second_Index;
    clear Temp;
    clear N;
end

Current_Oscillation_ID_Number=0;
for N=2:size(Decoding_Time_Info,1)
    if Decoding_Time_Info(N-1,6)<Theta_Sequence_Starting_Phase && Decoding_Time_Info(N,6)>=Theta_Sequence_Starting_Phase
        Current_Oscillation_ID_Number=Current_Oscillation_ID_Number+1;
    end
    Decoding_Time_Info(N,14)=Current_Oscillation_ID_Number;
end
clear N;
clear Current_Oscillation_ID_Number;

% Finds out if the rat was running for each entire theta oscillation
for N=1:max(Decoding_Time_Info(:,14))
    Index=find(Decoding_Time_Info(:,14)==N);
    if ~isempty(Index)
        Current_Decoding_Time_Info=Decoding_Time_Info(Index,:);
        Unimodal_Window_Spike_Count=sum(Current_Decoding_Time_Info(Current_Decoding_Time_Info(:,6)<Major_Peak_Window(2) | Current_Decoding_Time_Info(:,6)>=Major_Peak_Window(1),7));
        Bimodal_Window_Spike_Count=sum(Current_Decoding_Time_Info(Current_Decoding_Time_Info(:,6)<Minor_Peak_Window(2) & Current_Decoding_Time_Info(:,6)>=Minor_Peak_Window(1),7));
        Decoding_Time_Info(Index,12)=Unimodal_Window_Spike_Count;
        Decoding_Time_Info(Index,13)=Bimodal_Window_Spike_Count;
    end
    clear Index;
    clear Current_Decoding_Time_Info;
    clear Unimodal_Window_Spike_Count;
    clear Bimodal_Window_Spike_Count;
end
clear N;

% Finds out if each oscillation met the criteria for duration and monotonic increasing phase 
% Finds out if the rat was running for each entire theta oscillation
% Calculates number of spikes in Bimodal and Unimodal window for each oscillatioon 
for N=1:max(Decoding_Time_Info(:,14))
    Index=find(Decoding_Time_Info(:,14)==N);
    if ~isempty(Index)
        Current_Decoding_Time_Info=Decoding_Time_Info(Index,:);
        if isempty(find(Current_Decoding_Time_Info(:,4)<Velocity_Cutoff,1))
            Decoding_Time_Info(Index,9)=1;
        end
        Oscillation_Duration=size(Current_Decoding_Time_Info,1)*Initial_Variables.Decoding_Time_Advance;
        Current_Oscillation_Theta_Phases=Current_Decoding_Time_Info(:,6);
        Current_Oscillation_Theta_Phases(Current_Oscillation_Theta_Phases<=Theta_Sequence_Starting_Phase)=Current_Oscillation_Theta_Phases(Current_Oscillation_Theta_Phases<=Theta_Sequence_Starting_Phase)+360;
        if isempty(find(diff(Current_Oscillation_Theta_Phases)<0,1)) && Oscillation_Duration>=Theta_Length_Min_Max(1) && Oscillation_Duration<=Theta_Length_Min_Max(2)
            Decoding_Time_Info(Index,10)=1;
        end
        Unimodal_Window_Spike_Count=sum(Current_Decoding_Time_Info(Current_Decoding_Time_Info(:,6)<Major_Peak_Window(2) | Current_Decoding_Time_Info(:,6)>=Major_Peak_Window(1),7));
        Bimodal_Window_Spike_Count=sum(Current_Decoding_Time_Info(Current_Decoding_Time_Info(:,6)<Minor_Peak_Window(2) & Current_Decoding_Time_Info(:,6)>=Minor_Peak_Window(1),7));
        Decoding_Time_Info(Index,12)=Unimodal_Window_Spike_Count;
        Decoding_Time_Info(Index,13)=Bimodal_Window_Spike_Count;
    end
    clear Index;
    clear Oscillation_Duration;
    clear Current_Oscillation_Theta_Phases;
    clear Current_Decoding_Time_Info;
    clear Unimodal_Window_Spike_Count;
    clear Bimodal_Window_Spike_Count;
end
clear N;

Decoding_Window_Index=find(Decoding_Time_Info(:,7)>0 & Decoding_Time_Info(:,9)==1 & Decoding_Time_Info(:,10)==1);
Decoding_Window_Index_With_Inhibitory_Neurons=find(Decoding_Time_Info_With_Inhibitory_Neurons(:,7)>0 & Decoding_Time_Info_With_Inhibitory_Neurons(:,9)==1 & Decoding_Time_Info_With_Inhibitory_Neurons(:,10)==1);

save('Decoding_Time_Info','Decoding_Times','Decoding_Time_Info','Decoding_Time_Info_With_Inhibitory_Neurons','Starting_Time','Ending_Time','Decoding_Window_Index','Decoding_Window_Index_With_Inhibitory_Neurons','-v7.3');
save('Decoding_Spike_Index_All_Decoding_Windows','Decoding_Spike_Index','-v7.3')

%This trims the decoding spike index to only windows that will be used for theta sequence analysis (those with spikes and where the rat is running)
%This also makes a variable for future shuffle analysis 
Decoding_Spike_Index=Decoding_Spike_Index(:,Decoding_Window_Index);
Position_Data_For_Shuffles=Decoding_Time_Info(Decoding_Window_Index,[1,2,5]);
save('Decoding_Spike_Index','Decoding_Spike_Index','Position_Data_For_Shuffles','-v7.3')

%T=toc;
%eval(sprintf('disp(''Took %d minutes.'');',T/60));
%clear T;

