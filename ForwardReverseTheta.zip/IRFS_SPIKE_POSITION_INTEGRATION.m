function Spike_Information=IRFS_SPIKE_POSITION_INTEGRATION(Position_Data,Spike_Data,Excitatory_Neurons,Inhibitory_Neurons,Left_Cells,Right_Cells,Sleep_Spike_Data,Tetrode_Cell_IDs,Minimum_Time_Difference)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function loads up the spike data and the position data from previous
% functions (Load_Raw_Position_Information and Load_Clustered_Spike_Data).
% It then integrates these two by finding the nearest position data for
% every single spike. 
%
% Minimum_Time_Difference is the minimum time (in seconds) that a spike can
% be from the closest frame of the position data to be kept.  This can be
% used to eliminate spikes that occur when there is no position data
% available (such as if the video acquisition system suddently stops
% working).  If this value is not entered, the value is assumed to be
% infinity, so all spikes are kept.  A typical value is 0.1 (100
% milliseconds).  At a camera frame rate of 30 Hz, Neuralynx would have to
% miss 3 consecutive frames to lose any spikes.
% 
% These data are stored in a file called Spike_Information, which is a
% two-dimensional matrix in which the first dimension (rows) lists each
% individual spike, and the second dimension (columns) has the following
% form:
%
%        1               2             3            4
% |              |              |    Head     |            |
% |  X Position  |  Y Position  |  Direction  |  Velocity  |
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% If the user did not fully define the input variables, the most likely
% values are either searched for or automatically provided.
if ~exist('Minimum_Time_Difference','var')
    Minimum_Time_Difference=Inf;
end

Velocity=IRFS_CALCULATE_VELOCITY(Position_Data);

% This section finds the position information for each spike.
if 1  %This is the slower, but more accurate method
    Matched_Spike_Data=zeros(size(Spike_Data,1),5);
    parfor N=1:size(Spike_Data,1)
        Index=abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1)));
        if sum(Index)>1
            Index=find(abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1))),1,'first');
        end
        Matched_Spike_Data(N,:)=Position_Data(Index,1:5);
    end
    clear Index;
else
    Histogram=histc(Position_Data(:,1),Spike_Data(:,1));
    Temp_Spike_Times_In_Position_Time=cumsum(Histogram(1:end),1);
    Temp_Spike_Times_In_Position_Time(find(Temp_Spike_Times_In_Position_Time==0))=1;
    First_Index=Temp_Spike_Times_In_Position_Time;
    First_Matched_Spike_Data=[Position_Data(First_Index,1:4),Velocity(First_Index,1)];
    Second_Index=min([Temp_Spike_Times_In_Position_Time(1:end)+1,(ones(length(Temp_Spike_Times_In_Position_Time),1)*Temp_Spike_Times_In_Position_Time(end))]');
    Second_Matched_Spike_Data=[Position_Data(Second_Index,1:4),Velocity(Second_Index,1)];
    Third_Index=max([ones(length(Temp_Spike_Times_In_Position_Time),1),(Temp_Spike_Times_In_Position_Time(1:end)-1)]');
    Third_Matched_Spike_Data=[Position_Data(Third_Index,1:4),Velocity(Third_Index,1)];
    Matched_Spike_Data=zeros(size(First_Matched_Spike_Data,1),5);
    for M=1:size(First_Matched_Spike_Data,1)
        if (abs(First_Matched_Spike_Data(M,1)-Spike_Data(M,1))<=abs(Second_Matched_Spike_Data(M,1)-Spike_Data(M,1))) && (abs(First_Matched_Spike_Data(M,1)-Spike_Data(M,1))<=abs(Third_Matched_Spike_Data(M,1)-Spike_Data(M,1)))
            Matched_Spike_Data(M,:)=First_Matched_Spike_Data(M,:);
        elseif (abs(Second_Matched_Spike_Data(M,1)-Spike_Data(M,1))<=abs(First_Matched_Spike_Data(M,1)-Spike_Data(M,1))) && (abs(Second_Matched_Spike_Data(M,1)-Spike_Data(M,1))<=abs(Third_Matched_Spike_Data(M,1)-Spike_Data(M,1)))
            Matched_Spike_Data(M,:)=Second_Matched_Spike_Data(M,:);
        else
            Matched_Spike_Data(M,:)=Third_Matched_Spike_Data(M,:);
        end
    end
end
Spike_Information=Matched_Spike_Data(:,2:5);
Time_Difference=abs(Spike_Data(:,1)-Matched_Spike_Data(:,1));
Index=find(Time_Difference<=Minimum_Time_Difference);
fprintf('%d out of %d spikes were within %d seconds of the closest position timepoint. Max time difference was %d\n',length(Index),size(Spike_Data,1),Minimum_Time_Difference,max(Time_Difference)),
Spike_Data=Spike_Data(Time_Difference<=Minimum_Time_Difference,:);
Spike_Information=Spike_Information(Time_Difference<=Minimum_Time_Difference,:);
save('Spike_Information','Spike_Information')
save('Spike_Data','Spike_Data','Excitatory_Neurons','Inhibitory_Neurons','Left_Cells','Right_Cells','Sleep_Spike_Data','Tetrode_Cell_IDs')

