function IRFS_CALCULATE_LINEAR_PHASE_POSITION_RELATIONSHIP(Spike_Data,Spike_Information,Position_Data,Field_Data_Linear_In,Field_Data_Linear_Out,Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function calculates the relationship between location and phase of
% firing for each cell in the linear track.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%This resets the random number generator
Current_Time=clock;
eval(sprintf('rng(round(sqrt(%d%d%d%d%d%d)));',round(Current_Time(6)*1000),Current_Time(5),Current_Time(4),Current_Time(3),Current_Time(2),Current_Time(1)-2000));
clear Current_Time;

if exist('Spike_Data_With_Linear_Position.mat','file')~=2
    
    Filter=fspecial('gaussian',[10 5],2); %This is the filter used to smooth the position-phase histograms
    
    %This finds the orientation of the linear track
    if (max(Position_Data(:,2))-min(Position_Data(:,2)))>=(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is horizontal
        Position_Index=2;
    elseif (max(Position_Data(:,2))-min(Position_Data(:,2)))<(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is vertical
        Position_Index=3;
    end
    %Finds the movement direction for each position bin; Positive movement uses OUT place fields, Negative movement uses IN place fields 
    Position_Movement=sign(diff(Position_Data(:,Position_Index)));
    Position_Movement(end+1)=Position_Movement(end);
    
    Fraction_Of_Track_To_Exclude=0.1;  %This fraction will be eliminated from analysis of linear track data to exclude the ends of the track; set to 0.25 to require the peak to be in the middle half of the track (excluding a quarter on either side)
    Fraction_Of_Track_To_Exclude_For_Peak=0.25;  %The peak of the place field needs to be in the center (excluding this much on either end).
    Track_Length=max(Position_Data(:,Position_Index))-min(Position_Data(:,Position_Index));
    Cutoff_Locations=[Track_Length*Fraction_Of_Track_To_Exclude,Track_Length-(Track_Length*Fraction_Of_Track_To_Exclude)];
    Cutoff_Location_Bins=ceil(Cutoff_Locations/Initial_Variables.Bin_Size);
    Peak_Cutoff_Locations=[Track_Length*Fraction_Of_Track_To_Exclude_For_Peak,Track_Length-(Track_Length*Fraction_Of_Track_To_Exclude_For_Peak)];
    Peak_Cutoff_Location_Bins=ceil(Peak_Cutoff_Locations/Initial_Variables.Bin_Size);
    Restricted_Spike_Data=Spike_Data(Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & Spike_Information(:,Position_Index-1)>=Cutoff_Locations(1) & Spike_Information(:,Position_Index-1)<=Cutoff_Locations(2),:);
    Restricted_Spike_Information=Spike_Information(Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & Spike_Information(:,Position_Index-1)>=Cutoff_Locations(1) & Spike_Information(:,Position_Index-1)<=Cutoff_Locations(2),:);
    
    %Finds the movement direction at each spike
    % Restricted_Spike_Data (restricted because it excludes the ends of the track) 
    %|     1    |     2   |       3     |                           4                             |                      5                       |                            6                        |          7         |          8          |
    %| Time (s) | Cell ID | Theta Phase | Duration of LFP Oscillation (seconds, trough-to-trough) | Monotonically Increasing Cycle? (1=yes;0=no) | Time of LFP Trace That The Phase Was Taken From (s) | Movement Direction | Normalized Position |
    Restricted_Spike_Data(:,7)=0;
    Restricted_Spike_Data(:,8)=NaN;
    for N=1:size(Restricted_Spike_Data,1)
        Index=abs(Position_Data(:,1)-Restricted_Spike_Data(N,1))==min(abs(Position_Data(:,1)-Restricted_Spike_Data(N,1)));
        if sum(Index)==1
            Restricted_Spike_Data(N,7)=Position_Movement(Index);
        else
            Restricted_Spike_Data(N,7)=Position_Movement(find(abs(Position_Data(:,1)-Restricted_Spike_Data(N,1))==min(abs(Position_Data(:,1)-Restricted_Spike_Data(N,1))),1,'first'));
        end
    end
    
    %Positive movement uses OUT place fields; negative movement uses IN
    Position_Phase_Histograms_Phase_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    Position_Phase_Histograms_Position_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    Out_Position_Phase_Histograms_Phase_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    In_Position_Phase_Histograms_Phase_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    Out_Position_Phase_Histograms_Position_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    In_Position_Phase_Histograms_Position_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    
    Position_Phase_Histograms=zeros(round(360/Initial_Variables.Phase_Bin)*2,20,max(Spike_Data(:,2)));
    Smoothed_Position_Phase_Histograms=zeros(720,200,max(Spike_Data(:,2)));
    Out_Position_Phase_Histograms=zeros(round(360/Initial_Variables.Phase_Bin)*2,20,max(Spike_Data(:,2)));
    In_Position_Phase_Histograms=zeros(round(360/Initial_Variables.Phase_Bin)*2,20,max(Spike_Data(:,2)));
    Out_Smoothed_Position_Phase_Histograms=zeros(720,200,max(Spike_Data(:,2)));
    In_Smoothed_Position_Phase_Histograms=zeros(720,200,max(Spike_Data(:,2)));
    
    Linear_Correlations=zeros(max(Spike_Data(:,2)),6); %Major Window R, Major Window P, Number of Spikes in Major Window, Number of Spikes in Minor Window
    
    for Current_Cell=1:max(Spike_Data(:,2))
        Cell_Spike_Index=(Restricted_Spike_Data(:,2)==Current_Cell);
        Cell_Spike_Data=Restricted_Spike_Data(Cell_Spike_Index,:);
        Cell_Spike_Information=Restricted_Spike_Information(Cell_Spike_Index,:);
        
        %Finds if current fields are in center of the track
        Out_Field=Field_Data_Linear_Out(:,Current_Cell);
        [Peak_Out,Peak_Out_Location]=max(Out_Field);
        if Peak_Out>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_Out_Location>=Peak_Cutoff_Location_Bins(1) && Peak_Out_Location<=Peak_Cutoff_Location_Bins(2)
            Binary_Out_Field=Out_Field>=Peak_Out*Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Connected_Out_Field=grayconnected(double(Binary_Out_Field),Peak_Out_Location,1);
            Place_Field_Bins=find(Connected_Out_Field==1);
            Place_Field_Bins=Place_Field_Bins(Place_Field_Bins>=Cutoff_Location_Bins(1) & Place_Field_Bins<=Cutoff_Location_Bins(2));
            Out_Spike_Index=(Cell_Spike_Data(:,7)==1 & ceil(Cell_Spike_Information(:,Position_Index-1)/Initial_Variables.Bin_Size)>=min(Place_Field_Bins) & ceil(Cell_Spike_Information(:,Position_Index-1)/Initial_Variables.Bin_Size)<=max(Place_Field_Bins));
            Out_Spike_Data=Cell_Spike_Data(Out_Spike_Index,:);
            Out_Spike_Information=Cell_Spike_Information(Out_Spike_Index,:);
            Out_Spike_Phases=Out_Spike_Data(:,3);
            Out_Spike_Positions=Out_Spike_Information(:,Position_Index-1);
            Normalized_Out_Spike_Positions=(Out_Spike_Positions-min(Out_Spike_Positions))+0.00001;
            Normalized_Out_Spike_Positions=Normalized_Out_Spike_Positions/max(Normalized_Out_Spike_Positions);
            if size(Out_Spike_Data,1)>=100 %Need to have at least 100 spikes to analyze
                %Position_Bins is normalized (-1 to 1) location in the place field 
                Out_Spike_Data(:,8)=Normalized_Out_Spike_Positions;
                Cell_Spike_Data(Out_Spike_Index,8)=Out_Spike_Data(:,8);
                Position_Bins=0:0.05:1; %Splitting the position into 20 even bins
                Phase_Bins=0:Initial_Variables.Phase_Bin:360; %Splitting the phases into 36 even bins 
                Normalized_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                for Position_Bin=1:(length(Position_Bins)-1)
                    for Phase_Bin=1:(length(Phase_Bins)-1)
                        Normalized_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Out_Spike_Phases>Phase_Bins(Phase_Bin) & Out_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Normalized_Out_Spike_Positions>Position_Bins(Position_Bin) & Normalized_Out_Spike_Positions<=Position_Bins(Position_Bin+1));
                    end
                end
                for Shuffle=1:Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship
                    Shuffled_Spike_Phases=Out_Spike_Phases+((rand(length(Out_Spike_Phases),1)-0.5)*360);
                    Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)=Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)+360;
                    Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)=Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)-360;
                    Shuffled_Spike_Positions=rand(length(Normalized_Out_Spike_Positions),1);
                    Shuffled_Spike_Positions(Shuffled_Spike_Positions==0)=0.000001;
                    Phase_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                    Position_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                    for Position_Bin=1:(length(Position_Bins)-1)
                        for Phase_Bin=1:(length(Phase_Bins)-1)
                            Phase_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Shuffled_Spike_Phases>Phase_Bins(Phase_Bin) & Shuffled_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Normalized_Out_Spike_Positions>Position_Bins(Position_Bin) & Normalized_Out_Spike_Positions<=Position_Bins(Position_Bin+1));
                            Position_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Out_Spike_Phases>Phase_Bins(Phase_Bin) & Out_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Shuffled_Spike_Positions>Position_Bins(Position_Bin) & Shuffled_Spike_Positions<=Position_Bins(Position_Bin+1));
                        end
                    end
                    Out_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,Shuffle)=Phase_Shuffle_Position_Phase_Histogram;
                    Out_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,Shuffle)=Position_Shuffle_Position_Phase_Histogram;
                end
                Smoothed_Position_Phase_Histogram=filter2(Filter,[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram]);
                Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
                Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
                Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
                Out_Position_Phase_Histograms(:,:,Current_Cell)=[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram];
                Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell)=Interpolated_Position_Phase_Histogram;
            end
        end
        In_Field=Field_Data_Linear_In(:,Current_Cell);
        [Peak_In,Peak_In_Location]=max(In_Field);
        if Peak_In>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_In_Location>=Peak_Cutoff_Location_Bins(1) && Peak_In_Location<=Peak_Cutoff_Location_Bins(2)
            Binary_In_Field=In_Field>=Peak_In*Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Connected_In_Field=grayconnected(double(Binary_In_Field),Peak_In_Location,1);
            Place_Field_Bins=find(Connected_In_Field==1);
            Place_Field_Bins=Place_Field_Bins(Place_Field_Bins>=Cutoff_Location_Bins(1) & Place_Field_Bins<=Cutoff_Location_Bins(2));
            In_Spike_Index=(Cell_Spike_Data(:,7)==-1 & ceil(Cell_Spike_Information(:,Position_Index-1)/Initial_Variables.Bin_Size)>=min(Place_Field_Bins) & ceil(Cell_Spike_Information(:,Position_Index-1)/Initial_Variables.Bin_Size)<=max(Place_Field_Bins));
            In_Spike_Data=Cell_Spike_Data(In_Spike_Index,:);
            In_Spike_Information=Cell_Spike_Information(In_Spike_Index,:);
            In_Spike_Phases=In_Spike_Data(:,3);
            In_Spike_Positions=In_Spike_Information(:,Position_Index-1);
            Normalized_In_Spike_Positions=In_Spike_Positions-min(In_Spike_Positions);
            Normalized_In_Spike_Positions=abs(Normalized_In_Spike_Positions-max(Normalized_In_Spike_Positions))+0.00001; %This makes it so that the IN and OUT runs are in the same 'direction' (both moving from low to high position values)
            Normalized_In_Spike_Positions=Normalized_In_Spike_Positions/max(Normalized_In_Spike_Positions);
            if size(In_Spike_Data,1)>=100 %Need to have at least 100 spikes to analyze
                %Position_Bins is normalized (-1 to 1) location in the place field 
                In_Spike_Data(:,8)=Normalized_In_Spike_Positions;
                Cell_Spike_Data(In_Spike_Index,8)=In_Spike_Data(:,8);
                Position_Bins=0:0.05:1; %Splitting the position into 20 even bins
                Phase_Bins=0:Initial_Variables.Phase_Bin:360; %Splitting the phases into 36 even bins 
                Normalized_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                for Position_Bin=1:(length(Position_Bins)-1)
                    for Phase_Bin=1:(length(Phase_Bins)-1)
                        Normalized_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(In_Spike_Phases>Phase_Bins(Phase_Bin) & In_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Normalized_In_Spike_Positions>Position_Bins(Position_Bin) & Normalized_In_Spike_Positions<=Position_Bins(Position_Bin+1));
                    end
                end
                for Shuffle=1:Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship
                    Shuffled_Spike_Phases=In_Spike_Phases+((rand(length(In_Spike_Phases),1)-0.5)*360);
                    Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)=Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)+360;
                    Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)=Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)-360;
                    Shuffled_Spike_Positions=rand(length(In_Spike_Positions),1);
                    Shuffled_Spike_Positions(Shuffled_Spike_Positions==0)=0.000001;
                    Phase_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                    Position_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                    for Position_Bin=1:(length(Position_Bins)-1)
                        for Phase_Bin=1:(length(Phase_Bins)-1)
                            Phase_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Shuffled_Spike_Phases>Phase_Bins(Phase_Bin) & Shuffled_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Normalized_In_Spike_Positions>Position_Bins(Position_Bin) & Normalized_In_Spike_Positions<=Position_Bins(Position_Bin+1));
                            Position_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(In_Spike_Phases>Phase_Bins(Phase_Bin) & In_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Shuffled_Spike_Positions>Position_Bins(Position_Bin) & Shuffled_Spike_Positions<=Position_Bins(Position_Bin+1));
                        end
                    end
                    In_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,Shuffle)=Phase_Shuffle_Position_Phase_Histogram;
                    In_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,Shuffle)=Position_Shuffle_Position_Phase_Histogram;
                end
                Smoothed_Position_Phase_Histogram=filter2(Filter,[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram]);
                Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:); %This line and the next line assume a Phase_Bin size of 10
                Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
                Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
                In_Position_Phase_Histograms(:,:,Current_Cell)=[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram];
                In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell)=Interpolated_Position_Phase_Histogram;
            end
        end
        Restricted_Spike_Data(Cell_Spike_Index,:)=Cell_Spike_Data;
        if Peak_Out>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_Out_Location>=Peak_Cutoff_Location_Bins(1) && Peak_Out_Location<=Peak_Cutoff_Location_Bins(2) && Peak_In>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_In_Location>=Peak_Cutoff_Location_Bins(1) && Peak_In_Location<=Peak_Cutoff_Location_Bins(2) && size(Out_Spike_Data,1)>=100 && size(In_Spike_Data,1)>=100
            Position_Phase_Histograms(:,:,Current_Cell)=Out_Position_Phase_Histograms(:,:,Current_Cell)+In_Position_Phase_Histograms(:,:,Current_Cell);
            Smoothed_Position_Phase_Histogram=filter2(Filter,Position_Phase_Histograms(:,:,Current_Cell));
            Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:); %This line and the next line assume a Phase_Bin size of 10
            Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
            Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
            Smoothed_Position_Phase_Histograms(:,:,Current_Cell)=Interpolated_Position_Phase_Histogram;
            Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,:)=Out_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,:)+In_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,:);
            Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,:)=Out_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,:)+In_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,:);
        end
        clear Spike_Data_For_Correlation;
        if Peak_Out>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_Out_Location>=Peak_Cutoff_Location_Bins(1) && Peak_Out_Location<=Peak_Cutoff_Location_Bins(2) && Peak_In>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_In_Location>=Peak_Cutoff_Location_Bins(1) && Peak_In_Location<=Peak_Cutoff_Location_Bins(2)
            if size(Out_Spike_Data,1)>=100 && size(In_Spike_Data,1)>=100
                Spike_Data_For_Correlation=[[Out_Spike_Phases,Normalized_Out_Spike_Positions];[In_Spike_Phases,Normalized_In_Spike_Positions]];
            elseif size(Out_Spike_Data,1)>=100
                Spike_Data_For_Correlation=[Out_Spike_Phases,Normalized_Out_Spike_Positions];
            elseif size(In_Spike_Data,1)>=100
                Spike_Data_For_Correlation=[In_Spike_Phases,Normalized_In_Spike_Positions];
            else
                Spike_Data_For_Correlation=find(zeros(1)==1);
            end
        elseif Peak_Out>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_Out_Location>=Peak_Cutoff_Location_Bins(1) && Peak_Out_Location<=Peak_Cutoff_Location_Bins(2) && size(Out_Spike_Data,1)>=100
            Spike_Data_For_Correlation=[Out_Spike_Phases,Normalized_Out_Spike_Positions];
        elseif Peak_In>=Initial_Variables.Place_Field_Firing_Rate_Cutoff && Peak_In_Location>=Peak_Cutoff_Location_Bins(1) && Peak_In_Location<=Peak_Cutoff_Location_Bins(2) && size(In_Spike_Data,1)>=100
            Spike_Data_For_Correlation=[In_Spike_Phases,Normalized_In_Spike_Positions];
        else
            Spike_Data_For_Correlation=find(zeros(1)==1);
        end
        if ~isempty(Spike_Data_For_Correlation)
            Major_Window_Spike_Data_For_Correlation=Spike_Data_For_Correlation(Spike_Data_For_Correlation(:,1)>=Major_Peak_Window(1) | Spike_Data_For_Correlation(:,1)<=Major_Peak_Window(2),:);
            Major_Window_Spike_Data_For_Correlation(Major_Window_Spike_Data_For_Correlation(:,1)<Major_Peak_Window(1),1)=Major_Window_Spike_Data_For_Correlation(Major_Window_Spike_Data_For_Correlation(:,1)<Major_Peak_Window(1),1)+360;
            Minor_Window_Spike_Data_For_Correlation=Spike_Data_For_Correlation(Spike_Data_For_Correlation(:,1)>=Minor_Peak_Window(1) & Spike_Data_For_Correlation(:,1)<=Minor_Peak_Window(2),:);
            [Major_R,Major_P]=corr(Major_Window_Spike_Data_For_Correlation(:,1),Major_Window_Spike_Data_For_Correlation(:,2));
            [Minor_R,Minor_P]=corr(Minor_Window_Spike_Data_For_Correlation(:,1),Minor_Window_Spike_Data_For_Correlation(:,2));
            Linear_Correlations(Current_Cell,:)=[Major_R,Major_P,Minor_R,Minor_P,size(Major_Window_Spike_Data_For_Correlation,1),size(Minor_Window_Spike_Data_For_Correlation,1)];
        else
            Major_R=0;
            Major_P=1;
            Minor_R=0;
            Minor_P=1;
            Linear_Correlations(Current_Cell,:)=[Major_R,Major_P,Minor_R,Minor_P,0,0];
        end
    end
    save('Spike_Data_With_Linear_Position','Spike_Data','Restricted_Spike_Data','Spike_Information','Restricted_Spike_Information','Linear_Correlations','Position_Phase_Histograms_Phase_Shuffles','Position_Phase_Histograms_Position_Shuffles','Position_Phase_Histograms','Smoothed_Position_Phase_Histograms','Out_Position_Phase_Histograms','In_Position_Phase_Histograms','Out_Smoothed_Position_Phase_Histograms','In_Smoothed_Position_Phase_Histograms','Out_Position_Phase_Histograms_Phase_Shuffles','In_Position_Phase_Histograms_Phase_Shuffles','Out_Position_Phase_Histograms_Position_Shuffles','In_Position_Phase_Histograms_Position_Shuffles','-v7.3')
end


end


