function Weighted_Position_Correlation=IRFS_CALCULATE_WEIGHTED_POSITION_CORRELATION(Decoded_Data)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function takes the decoded data (i.e., from BAYESIAN_DECODING) and
% calculates the weighted position correlation.  If the decoded data is
% from a linear track, it calculates the weighted correlation.  If the
% decoded data is from a two-dimensional environment, it calculates an
% X-position weighted correlation and a Y-position weighted correlation.
% The listed weighted correlation is the highest (absolute) value of the X-
% or Y-position weighted correlation.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


if size(Decoded_Data,3)==1, % If the decoding was on linear field data
    Weighted_Correlation_Matrix=zeros(size(Decoded_Data,1)*size(Decoded_Data,2),3);
    Location=1;
    for N=1:size(Decoded_Data,1),
        for M=1:size(Decoded_Data,2),
            Weighted_Correlation_Matrix(Location,1)=N;
            Weighted_Correlation_Matrix(Location,2)=M;
            Weighted_Correlation_Matrix(Location,3)=Decoded_Data(N,M);
            Location=Location+1;
        end
    end
    clear Location;
    Weighted_Time_Mean=sum(Weighted_Correlation_Matrix(:,1).*Weighted_Correlation_Matrix(:,3))/sum(Weighted_Correlation_Matrix(:,3));
    Weighted_Position_Mean=sum(Weighted_Correlation_Matrix(:,2).*Weighted_Correlation_Matrix(:,3))/sum(Weighted_Correlation_Matrix(:,3));
    Weighted_Covariance_TimePosition=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean).*(Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
    Weighted_Covariance_TimeTime=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean).*(Weighted_Correlation_Matrix(:,1)-Weighted_Time_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
    Weighted_Covariance_PositionPosition=sum(Weighted_Correlation_Matrix(:,3).*((Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean).*(Weighted_Correlation_Matrix(:,2)-Weighted_Position_Mean)))/sum(Weighted_Correlation_Matrix(:,3));
    Weighted_Position_Correlation=[Weighted_Covariance_TimePosition/(sqrt(Weighted_Covariance_TimeTime*Weighted_Covariance_PositionPosition)),0];
elseif size(Decoded_Data,3)>1  % If the decoding was on 2D field data
    Summed_X_Decoded_Data=sum(Decoded_Data,1);
    Summed_X_Decoded_Data=permute(Summed_X_Decoded_Data,[2,3,1]);
    Summed_Y_Decoded_Data=sum(Decoded_Data,2);
    Summed_Y_Decoded_Data=permute(Summed_Y_Decoded_Data,[1,3,2]);
    Weighted_X_Correlation_Matrix=zeros(size(Summed_X_Decoded_Data,1)*size(Summed_X_Decoded_Data,2),3);
    Weighted_Y_Correlation_Matrix=zeros(size(Summed_Y_Decoded_Data,1)*size(Summed_Y_Decoded_Data,2),3);
    Location=1;
    for N=1:size(Summed_X_Decoded_Data,2),
        for M=1:size(Summed_X_Decoded_Data,1),
            Weighted_X_Correlation_Matrix(Location,1)=N;
            Weighted_X_Correlation_Matrix(Location,2)=M;
            Weighted_X_Correlation_Matrix(Location,3)=Summed_X_Decoded_Data(M,N);
            Location=Location+1;
        end
    end
    Location=1;
    for N=1:size(Summed_Y_Decoded_Data,2),
        for M=1:size(Summed_Y_Decoded_Data,1),
            Weighted_Y_Correlation_Matrix(Location,1)=N;
            Weighted_Y_Correlation_Matrix(Location,2)=M;
            Weighted_Y_Correlation_Matrix(Location,3)=Summed_Y_Decoded_Data(M,N);
            Location=Location+1;
        end
    end
    clear Location;
    clear N;
    clear M;
    Weighted_X_Time_Mean=sum(Weighted_X_Correlation_Matrix(:,1).*Weighted_X_Correlation_Matrix(:,3))/sum(Weighted_X_Correlation_Matrix(:,3));
    Weighted_X_Position_Mean=sum(Weighted_X_Correlation_Matrix(:,2).*Weighted_X_Correlation_Matrix(:,3))/sum(Weighted_X_Correlation_Matrix(:,3));
    Weighted_X_Covariance_TimePosition=sum(Weighted_X_Correlation_Matrix(:,3).*((Weighted_X_Correlation_Matrix(:,1)-Weighted_X_Time_Mean).*(Weighted_X_Correlation_Matrix(:,2)-Weighted_X_Position_Mean)))/sum(Weighted_X_Correlation_Matrix(:,3));
    Weighted_X_Covariance_TimeTime=sum(Weighted_X_Correlation_Matrix(:,3).*((Weighted_X_Correlation_Matrix(:,1)-Weighted_X_Time_Mean).*(Weighted_X_Correlation_Matrix(:,1)-Weighted_X_Time_Mean)))/sum(Weighted_X_Correlation_Matrix(:,3));
    Weighted_X_Covariance_PositionPosition=sum(Weighted_X_Correlation_Matrix(:,3).*((Weighted_X_Correlation_Matrix(:,2)-Weighted_X_Position_Mean).*(Weighted_X_Correlation_Matrix(:,2)-Weighted_X_Position_Mean)))/sum(Weighted_X_Correlation_Matrix(:,3));
    Weighted_X_Position_Correlation=Weighted_X_Covariance_TimePosition/(sqrt(Weighted_X_Covariance_TimeTime*Weighted_X_Covariance_PositionPosition));
    Weighted_Y_Time_Mean=sum(Weighted_Y_Correlation_Matrix(:,1).*Weighted_Y_Correlation_Matrix(:,3))/sum(Weighted_Y_Correlation_Matrix(:,3));
    Weighted_Y_Position_Mean=sum(Weighted_Y_Correlation_Matrix(:,2).*Weighted_Y_Correlation_Matrix(:,3))/sum(Weighted_Y_Correlation_Matrix(:,3));
    Weighted_Y_Covariance_TimePosition=sum(Weighted_Y_Correlation_Matrix(:,3).*((Weighted_Y_Correlation_Matrix(:,1)-Weighted_Y_Time_Mean).*(Weighted_Y_Correlation_Matrix(:,2)-Weighted_Y_Position_Mean)))/sum(Weighted_Y_Correlation_Matrix(:,3));
    Weighted_Y_Covariance_TimeTime=sum(Weighted_Y_Correlation_Matrix(:,3).*((Weighted_Y_Correlation_Matrix(:,1)-Weighted_Y_Time_Mean).*(Weighted_Y_Correlation_Matrix(:,1)-Weighted_Y_Time_Mean)))/sum(Weighted_Y_Correlation_Matrix(:,3));
    Weighted_Y_Covariance_PositionPosition=sum(Weighted_Y_Correlation_Matrix(:,3).*((Weighted_Y_Correlation_Matrix(:,2)-Weighted_Y_Position_Mean).*(Weighted_Y_Correlation_Matrix(:,2)-Weighted_Y_Position_Mean)))/sum(Weighted_Y_Correlation_Matrix(:,3));
    Weighted_Y_Position_Correlation=Weighted_Y_Covariance_TimePosition/(sqrt(Weighted_Y_Covariance_TimeTime*Weighted_Y_Covariance_PositionPosition));
    Weighted_Position_Correlation=[Weighted_X_Position_Correlation,Weighted_Y_Position_Correlation];
end

end

