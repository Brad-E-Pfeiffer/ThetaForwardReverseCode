function IRFS_COMBINE_AND_SAVE_MODALITY_ACROSS_SESSIONS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads up the previously processed and saved unimodal and
% bimodal data for each individual session, combines it, and saves it.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Place_Field_Properties
        load Spike_Properties
        load Modality
        load Spike_Data
        load Firing_Rate_Per_Phase
        
        Excitatory_Index=find(Neuron_List==1);
        Inhibitory_Index=find(Neuron_List==0);
        All_Modality=Modality;
        All_Modality(:,3)=1;
        for N=1:length(Inhibitory_Neurons)
            All_Modality(All_Modality(:,2)==Inhibitory_Neurons(N),3)=0;
        end
        Modality_Inhibitory=Modality(Inhibitory_Index,:);
        Modality_Peaks_Inhibitory=Modality_Peaks(Inhibitory_Index,:,:);
        Firing_Rate_Per_Phase_Inhibitory=Firing_Rate_Per_Phase(Inhibitory_Index,:,:);
        Modality=Modality(Excitatory_Index,:);
        Modality_Peaks=Modality_Peaks(Excitatory_Index,:,:);
        Firing_Rate_Per_Phase=Firing_Rate_Per_Phase(Excitatory_Index,:,:);
        clear Excitatory_Index;
        clear Inhibitory_Index;
        eval(sprintf('%s_%s_Modality=Modality;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Modality_Peaks=Modality_Peaks;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Firing_Rate_Per_Phase=Unimodal_Firing_Rate_Per_Phase;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Firing_Rate_Per_Phase=Bimodal_Firing_Rate_Per_Phase;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Modality_Inhibitory=Modality_Inhibitory;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Modality_Peaks_Inhibitory=Modality_Peaks_Inhibitory;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Firing_Rate_Per_Phase_Inhibitory=Firing_Rate_Per_Phase_Inhibitory;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Mean_Firing_Rate_Per_Phase_All=Mean_Firing_Rate_Per_Phase_All;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Mean_Firing_Rate_Per_Phase_Unimodal=Mean_Firing_Rate_Per_Phase_Unimodal;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Mean_Firing_Rate_Per_Phase_Bimodal=Mean_Firing_Rate_Per_Phase_Bimodal;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Mean_Firing_Rate_Per_Phase_Inhibitory=Mean_Firing_Rate_Per_Phase_Inhibitory;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Place_Field_Properties=Bimodal_Place_Field_Properties;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Place_Field_Properties=Unimodal_Place_Field_Properties;',Rats(Rat).name,Directory_Name));
        if exist('All_Mean_Firing_Rate_Per_Phase','var')==1
            All_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_All(:,:,1);
            All_Unimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
            All_Bimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
            All_Inhibitory_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
            All_Firing_Rate_Per_Phase((end+1):(end+size(Firing_Rate_Per_Phase,1)),:,:)=Firing_Rate_Per_Phase;
            All_Unimodal_Firing_Rate_Per_Phase((end+1):(end+size(Unimodal_Firing_Rate_Per_Phase,1)),:,:)=Unimodal_Firing_Rate_Per_Phase;
            All_Bimodal_Firing_Rate_Per_Phase((end+1):(end+size(Bimodal_Firing_Rate_Per_Phase,1)),:,:)=Bimodal_Firing_Rate_Per_Phase;
            All_Firing_Rate_Per_Phase_Inhibitory((end+1):(end+size(Firing_Rate_Per_Phase_Inhibitory,1)),:,:)=Firing_Rate_Per_Phase_Inhibitory;
            All_Bimodal_Place_Field_Properties=[All_Bimodal_Place_Field_Properties;Bimodal_Place_Field_Properties];
            All_Unimodal_Place_Field_Properties=[All_Unimodal_Place_Field_Properties;Unimodal_Place_Field_Properties];
            All_Modality=[All_Modality;[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment]];
        else
            All_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_All(:,:,1);
            All_Unimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
            All_Bimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
            All_Inhibitory_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
            All_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase;
            All_Unimodal_Firing_Rate_Per_Phase=Unimodal_Firing_Rate_Per_Phase;
            All_Bimodal_Firing_Rate_Per_Phase=Bimodal_Firing_Rate_Per_Phase;
            All_Firing_Rate_Per_Phase_Inhibitory=Firing_Rate_Per_Phase_Inhibitory;
            All_Bimodal_Place_Field_Properties=Bimodal_Place_Field_Properties;
            All_Unimodal_Place_Field_Properties=Unimodal_Place_Field_Properties;
            All_Modality=[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment];
        end
        if strcmp(Directory_Name(1),'L')
            if exist('Linear_All_Mean_Firing_Rate_Per_Phase','var')==1
                Linear_All_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_All(:,:,1);
                Linear_Unimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
                Linear_Bimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
                Linear_Inhibitory_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
                Linear_All_Firing_Rate_Per_Phase((end+1):(end+size(Firing_Rate_Per_Phase,1)),:,:)=Firing_Rate_Per_Phase;
                Linear_Unimodal_Firing_Rate_Per_Phase((end+1):(end+size(Unimodal_Firing_Rate_Per_Phase,1)),:,:)=Unimodal_Firing_Rate_Per_Phase;
                Linear_Bimodal_Firing_Rate_Per_Phase((end+1):(end+size(Bimodal_Firing_Rate_Per_Phase,1)),:,:)=Bimodal_Firing_Rate_Per_Phase;
                Linear_All_Firing_Rate_Per_Phase_Inhibitory((end+1):(end+size(Firing_Rate_Per_Phase_Inhibitory,1)),:,:)=Firing_Rate_Per_Phase_Inhibitory;
                Linear_Bimodal_Place_Field_Properties=[Linear_Bimodal_Place_Field_Properties;Bimodal_Place_Field_Properties];
                Linear_Unimodal_Place_Field_Properties=[Linear_Unimodal_Place_Field_Properties;Unimodal_Place_Field_Properties];
                Linear_Modality=[Linear_Modality;[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment]];
            else
                Linear_All_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_All(:,:,1);
                Linear_Unimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
                Linear_Bimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
                Linear_Inhibitory_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
                Linear_All_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase;
                Linear_Unimodal_Firing_Rate_Per_Phase=Unimodal_Firing_Rate_Per_Phase;
                Linear_Bimodal_Firing_Rate_Per_Phase=Bimodal_Firing_Rate_Per_Phase;
                Linear_All_Firing_Rate_Per_Phase_Inhibitory=Firing_Rate_Per_Phase_Inhibitory;
                Linear_Bimodal_Place_Field_Properties=Bimodal_Place_Field_Properties;
                Linear_Unimodal_Place_Field_Properties=Unimodal_Place_Field_Properties;
                Linear_Modality=[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment];
            end
        elseif strcmp(Directory_Name(1),'O')
            if exist('Open_All_Mean_Firing_Rate_Per_Phase','var')==1
                Open_All_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_All(:,:,1);
                Open_Unimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
                Open_Bimodal_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
                Open_Inhibitory_Mean_Firing_Rate_Per_Phase(:,:,end+1)=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
                Open_All_Firing_Rate_Per_Phase((end+1):(end+size(Firing_Rate_Per_Phase,1)),:,:)=Firing_Rate_Per_Phase;
                Open_Unimodal_Firing_Rate_Per_Phase((end+1):(end+size(Unimodal_Firing_Rate_Per_Phase,1)),:,:)=Unimodal_Firing_Rate_Per_Phase;
                Open_Bimodal_Firing_Rate_Per_Phase((end+1):(end+size(Bimodal_Firing_Rate_Per_Phase,1)),:,:)=Bimodal_Firing_Rate_Per_Phase;
                Open_All_Firing_Rate_Per_Phase_Inhibitory((end+1):(end+size(Firing_Rate_Per_Phase_Inhibitory,1)),:,:)=Firing_Rate_Per_Phase_Inhibitory;
                Open_Bimodal_Place_Field_Properties=[Open_Bimodal_Place_Field_Properties;Bimodal_Place_Field_Properties];
                Open_Unimodal_Place_Field_Properties=[Open_Unimodal_Place_Field_Properties;Unimodal_Place_Field_Properties];
                Open_Modality=[Open_Modality;[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment]];
            else
                Open_All_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_All(:,:,1);
                Open_Unimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Unimodal(:,:,1);
                Open_Bimodal_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Bimodal(:,:,1);
                Open_Inhibitory_Mean_Firing_Rate_Per_Phase=Mean_Firing_Rate_Per_Phase_Inhibitory(:,:,1);
                Open_All_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase;
                Open_Unimodal_Firing_Rate_Per_Phase=Unimodal_Firing_Rate_Per_Phase;
                Open_Bimodal_Firing_Rate_Per_Phase=Bimodal_Firing_Rate_Per_Phase;
                Open_All_Firing_Rate_Per_Phase_Inhibitory=Firing_Rate_Per_Phase_Inhibitory;
                Open_Bimodal_Place_Field_Properties=Bimodal_Place_Field_Properties;
                Open_Unimodal_Place_Field_Properties=Unimodal_Place_Field_Properties;
                Open_Modality=[Modality,ones(size(Modality,1),1)*Rat,ones(size(Modality,1),1)*Experiment];
            end
        end
        if exist('Unimodal_Spike_Properties','var')
            Unimodal_Spike_Properties=[Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
            Bimodal_Spike_Properties=[Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
            Inhibitory_Spike_Properties=[Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
        else
            Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
            Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
            Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
        end
        if strcmp(Directory_Name(1),'L')
            if exist('Linear_Unimodal_Spike_Properties','var')
                Linear_Unimodal_Spike_Properties=[Linear_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                Linear_Bimodal_Spike_Properties=[Linear_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                Linear_Inhibitory_Spike_Properties=[Linear_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                Linear_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                Linear_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                Linear_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        else
            if exist('OpenField_Unimodal_Spike_Properties','var')
                OpenField_Unimodal_Spike_Properties=[OpenField_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Bimodal_Spike_Properties=[OpenField_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Inhibitory_Spike_Properties=[OpenField_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                OpenField_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                OpenField_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                OpenField_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        end
        cd ..
    end
    clear Directory
    cd ..
end

Mean_Bimodal_Firing_Rate_Index=[mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1)];
[~,Firing_Rate_Troughs]=findpeaks(-Mean_Bimodal_Firing_Rate_Index);
Firing_Rate_Troughs(Firing_Rate_Troughs>36)=Firing_Rate_Troughs(Firing_Rate_Troughs>36)-36;
Firing_Rate_Troughs=unique(Firing_Rate_Troughs);
Bimodal_Firing_Rate_Troughs=Firing_Rate_Troughs;
Bimodal_Firing_Rate_Troughs=Bimodal_Firing_Rate_Troughs*Phase_Bin;
clear Firing_Rate_Troughs;
clear Mean_Bimodal_Firing_Rate_Index;

clear Rat;
clear Rat_Name;
clear Experiment;

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

save('Cell_Modality_Information','Janni*','Harpy*','Imp*','All_*','Open*','Linear*','Unimodal_Spike_Properties','Bimodal_Spike_Properties','Inhibitory_Spike_Properties','Bimodal_Firing_Rate_Troughs');

cd ..

end
