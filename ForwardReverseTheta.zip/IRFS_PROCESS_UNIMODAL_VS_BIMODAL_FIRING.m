function IRFS_PROCESS_UNIMODAL_VS_BIMODAL_FIRING(Initial_Variables,Timepoints_To_Remove)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function uses the previously processed data and calculates the
% firing rate of each neuron with respect to the theta oscillation and then
% determines which neurons are unimodal and bimodal.  It then calculates
% various other properties of individual neurons to compare between these
% classes.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if 1%exist('Completed_Process_Unimodal_Vs_Bimodal_Cells.mat','file')~=2
            
            disp('--------------------------------------------------------------------------');
            disp(sprintf('Starting Bimodal/Unimodal Quantification for Rat: %s, Session: %s.',Rat_Name,Directory_Name));

            Spike_Position_Integration_Minimum_Time_Difference=Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference;
            Bin_Size=Initial_Variables.Bin_Size;
            Place_Field_Velocity_Cutoff=Initial_Variables.Place_Field_Velocity_Cutoff;
            Place_Field_Firing_Rate_Cutoff=Initial_Variables.Place_Field_Firing_Rate_Cutoff;
            Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
            Limit_Analysis_By_Theta_Length=Initial_Variables.Limit_Analysis_By_Theta_Length;
            Theta_Length_Min_Max=Initial_Variables.Theta_Length_Min_Max;
            Number_Of_Shuffles=Initial_Variables.Number_Of_Shuffles;
            Phase_Bin=Initial_Variables.Phase_Bin;
            Gaussian_Smoothing_Sigma=Initial_Variables.Gaussian_Smoothing_Sigma;
            Rayleigh_Test_P_Value_Cutoff=Initial_Variables.Rayleigh_Test_P_Value_Cutoff;
            Minimum_Place_Field_Firing_Rate_Fraction=Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Minimum_Contiguous_Place_Field_Bins=Initial_Variables.Minimum_Contiguous_Place_Field_Bins;
            Velocity_Cutoff=Initial_Variables.Velocity_Cutoff;
            Minimum_Spike_Count=Initial_Variables.Minimum_Spike_Count;
            Decoding_Time_Window=Initial_Variables.Decoding_Time_Window;
            Decoding_Time_Advance=Initial_Variables.Decoding_Time_Advance;
            Use_Maximum_Posterior_Probability=Initial_Variables.Use_Maximum_Posterior_Probability;
            
            Janni_Open2_To_Remove=Timepoints_To_Remove.Janni_Open2_To_Remove;
            Janni_Linear2_To_Remove=Timepoints_To_Remove.Janni_Linear2_To_Remove;
            Janni_Linear3_To_Remove=Timepoints_To_Remove.Janni_Linear3_To_Remove;
            Harpy_Linear1_To_Remove=Timepoints_To_Remove.Harpy_Linear1_To_Remove;
            Harpy_Linear2_To_Remove=Timepoints_To_Remove.Harpy_Linear2_To_Remove;
            Harpy_Linear3_To_Remove=Timepoints_To_Remove.Harpy_Linear3_To_Remove;
            Harpy_Open1_To_Remove=Timepoints_To_Remove.Harpy_Open1_To_Remove;
            Harpy_Open2_To_Remove=Timepoints_To_Remove.Harpy_Open2_To_Remove;
            Imp_Linear1_To_Remove=Timepoints_To_Remove.Imp_Linear1_To_Remove;
            Imp_Open1_To_Remove=Timepoints_To_Remove.Imp_Open1_To_Remove;
            Imp_Open2_To_Remove=Timepoints_To_Remove.Imp_Open2_To_Remove;
            
            disp('Loading Data.')
            IRFS_LOAD_DATA_FOR_UNIMODAL_VS_BIMODAL_QUANTIFICATION;
            
            disp('Removing Identified Noisy Segments From Analysis.');
            % This removes noisy sections of the experiment and calculates the total duration of this experiment
            IRFS_REMOVE_NOISE_AND_CLEAN_DATA_FOR_ANALYSIS;

            disp('Analyzing Cycle-to-Cycle Duration.');
            % This quantifies the duration of each theta oscillation and will be later used to elminiate unusual theta oscillations from analysis
            IRFS_QUANTIFY_INDIVIDUAL_THETA_OSCILLATION_DURATION;
            % LFP_Theta
            % |     1    |            2         |       3     |       4     |                     5                      |                        6                     ||
            % | Time (s) | Filtered Theta Trace | Theta Power | Theta Phase | Cycle Duration (Seconds, Trough-to-Trough) | Monotonically Increasing Cycle? (1=yes;0=no) ||
            
            disp('Quantifying theta phase for each spike.');
            if exist('Spike_Data_With_Theta_Phase.mat','file')==2
                load Spike_Data_With_Theta_Phase;
            else
                IRFS_QUANTIFY_THETA_PHASE_FOR_EVERY_SPIKE(Spike_Data,LFP_Theta);
                load Spike_Data_With_Theta_Phase;
            end
            % Spike_Data
            %|     1    |     2   |       3     |                           4                             |                      5                       |                            6                        ||
            %| Time (s) | Cell ID | Theta Phase | Duration of LFP Oscillation (seconds, trough-to-trough) | Monotonically Increasing Cycle? (1=yes;0=no) | Time of LFP Trace That The Phase Was Taken From (s) ||
            %                                                                                                                                                     (for comparison to actual spike time) 

            disp('Calculating Theta-Phase-Locked Firing for Each Neuron.');
            Firing_Rate_Per_Phase=IRFS_CALCULATE_PHASE_LOCKED_FIRING_FOR_EACH_NEURON(Spike_Data,Spike_Information,Velocity_Cutoff,Phase_Bin,Gaussian_Smoothing_Sigma,Total_Duration,Minimum_Spike_Count,Theta_Length_Min_Max,Limit_Analysis_By_Theta_Length);
            % Firing_Rate_Per_Phase
            % Each row is a cell, each column is a phase bin (from 0-360 degrees).
            % Page 1 is the raw firing rate per phase.
            % Page 2 is the smoothed firing rate per phase.
            % Page 3 is the Firing Rate Index per phase.
            % Page 4 is the raw total number of spikes per phase.
            % Page 5 is the smoothed total number of spikes per phase.
            
            disp('Identifying Peaks of Firing and Classifying Neuron Modalities.');
            IRFS_CALCULATE_THETA_MODALITY;
            % Modality
            %|                                     1                                      |     2   ||
            %| Modality (1=Unimodal, 2=Bimodal, 3=Multimodal, 0=Uniform/Not enough spikes | Cell ID ||
            %
            % Modality_Peaks -- Each row is a neuron, each column is a quantified peak in firing, page 1 is the Peak Value, page 2 is the phase of the peak firing
            
            disp('Quantifying Place Field Properties for Unimodal Vs. Bimodal Neurons.');
            IRFS_CALCULATE_UNIMODAL_AND_BIMODAL_PLACE_FIELD_PROPERTIES;
            % Unimodal/Bimodal_Place_Field_Properties
            % |              1               |              2         |        3         |         4        |              5              |     6   |            7              ||
            % | Mean Place Field Size (bins) | Number Of Place Fields | Peak Firing Rate | Mean Firing Rate | Informaton Per Spike (bits) | L-Ratio | Mean In-Field Firing Rate ||
            
            disp('Quantifying Spike Properties for Unimodal Vs. Bimodal Neurons.');
            IRFS_CALCULATE_UNIMODAL_AND_BIMODAL_SPIKE_PROPERTIES;
            
            %Option to plot the data thus far on unimodal vs. bimodal cell properties
            Plot_Data=0;  %Set to 0 to skip plotting, set to 1 to plot
            Plot_Individual_Cell_Histograms=0;  %Set to 0 to skip plotting each individual cell, set to 1 to plot
            IRFS_PLOT_UNIMODAL_BIMODAL_CELL_PROPERTIES;
            
            Completed_Process_Unimodal_Vs_Bimodal_Cells=1;
            save('Completed_Process_Unimodal_Vs_Bimodal_Cells','Completed_Process_Unimodal_Vs_Bimodal_Cells');
            
            clearvars -except Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name
            
            disp(sprintf('Finished Bimodal/Unimodal Quantification for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            disp('--------------------------------------------------------------------------');
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

clear Rat
clear Experiment
clear Rats

disp('Combining and Saving Modality Quantification Across Rats and Sessions.')
IRFS_COMBINE_AND_SAVE_MODALITY_ACROSS_SESSIONS(Initial_Variables);

if 1
    IRFS_PLOT_FIGURE_TWO_AB;
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_NINE;
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_TWELVE;
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_ELEVEN;
end

clearvars -except Initial_Variables Timepoints_To_Remove

end

