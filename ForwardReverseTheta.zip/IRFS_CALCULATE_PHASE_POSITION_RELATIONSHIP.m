function IRFS_CALCULATE_PHASE_POSITION_RELATIONSHIP(Spike_Data,Spike_Information,Modality,Position_Data,Field_Data,Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function first calculates the place field for each cell.  It then
% calculates the normalized location with the cell's place field for each
% spike.  The phase for each spike has already been calculated, and this
% relationship is quantified across all cells. 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%This resets the random number generator
Current_Time=clock;
eval(sprintf('rng(round(sqrt(%d%d%d%d%d%d)));',round(Current_Time(6)*1000),Current_Time(5),Current_Time(4),Current_Time(3),Current_Time(2),Current_Time(1)-2000));
clear Current_Time;

if exist('Spike_Data_With_Relative_Position.mat','file')~=2

    Filter=fspecial('gaussian',[10 5],2); %This is the filter used to smooth the position-phase histograms

    % Spike_Data
    %|     1    |     2   |       3     |                           4                             |                      5                       |                            6                        |         7         |                 8                ||
    %| Time (s) | Cell ID | Theta Phase | Duration of LFP Oscillation (seconds, trough-to-trough) | Monotonically Increasing Cycle? (1=yes;0=no) | Time of LFP Trace That The Phase Was Taken From (s) | Relative Position | Relative Position for Best Field ||
    Spike_Data(:,7:8)=NaN;
    
    %This eliminates spikes that occurred before the video turned on, which
    %likely has negligable impact on the analysis, but I'm removing them here
    %just be safe.
    Spike_Information=Spike_Information(Spike_Data(:,1)>=min(Position_Data(:,1)) & Spike_Data(:,1)<=max(Position_Data(:,1)),:);
    Spike_Data=Spike_Data(Spike_Data(:,1)>=min(Position_Data(:,1)) & Spike_Data(:,1)<=max(Position_Data(:,1)),:);
    
    % This preallocates the phase-position histograms and shuffles
    Position_Phase_Histograms=zeros(round(360/Initial_Variables.Phase_Bin)*2,20,max(Spike_Data(:,2)));
    Smoothed_Position_Phase_Histograms=zeros(720,200,max(Spike_Data(:,2)));
    Position_Phase_Histograms_Phase_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);
    Position_Phase_Histograms_Position_Shuffles=zeros(round(360/Initial_Variables.Phase_Bin),20,max(Spike_Data(:,2)),Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship);

    % First, put the position information into bins
    Spike_Information(:,5:6)=ceil(Spike_Information(:,1:2)/Initial_Variables.Bin_Size);
    Position_Data(:,8:9)=ceil(Position_Data(:,2:3)/Initial_Variables.Bin_Size);
    
    % This runs through each place field of each cell and calculates a relative position value for each spike based on the rat's location and movement relative to that field's peak
    for Current_Cell=1:max(Spike_Data(:,2))
        Current_Cell_Place_Field=Field_Data(:,:,Current_Cell);
        Current_Cell_Modality=Modality(Current_Cell,1);
        if max(max(Current_Cell_Place_Field))>0 && (Current_Cell_Modality==1 || Current_Cell_Modality==2) %Only analyze unimodal or bimodal cells
            Peak_Firing_Rate=max(max(Current_Cell_Place_Field));
            Used_Best=0;
            Contiguous_Place_Fields=zeros(size(Current_Cell_Place_Field,1),size(Current_Cell_Place_Field,2));
            %This finds all the place fields that meet our criteria
            Current_Cell_Binary_Place_Field=double(Current_Cell_Place_Field>=Peak_Firing_Rate*Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction);
            Number_Of_Fields=0;
            [Y_Index,X_Index]=find(Current_Cell_Binary_Place_Field==1);
            for M=1:length(Y_Index)
                if Contiguous_Place_Fields(Y_Index(M),X_Index(M))==0 && Current_Cell_Binary_Place_Field(Y_Index(M),X_Index(M))==1
                    This_Place_Field=grayconnected(Current_Cell_Binary_Place_Field,Y_Index(M),X_Index(M),0);
                    This_Place_Field_Edges=double(edge(This_Place_Field));
                    if sum(sum(This_Place_Field))>=Initial_Variables.Minimum_Contiguous_Place_Field_Bins
                        Number_Of_Fields=Number_Of_Fields+1;
                        This_Place_Field_Max=max(max(Current_Cell_Place_Field(This_Place_Field)));
                        [This_Place_Field_Peak_Y,This_Place_Field_Peak_X]=find(Current_Cell_Place_Field==This_Place_Field_Max,1,'first');
                        This_Place_Field_Peak_Y=This_Place_Field_Peak_Y*Initial_Variables.Bin_Size; %convert from bins to cm
                        This_Place_Field_Peak_X=This_Place_Field_Peak_X*Initial_Variables.Bin_Size; %convert from bins to cm
                        Contiguous_Place_Fields(This_Place_Field)=Number_Of_Fields;
                        [This_Place_Field_Y_Bins,This_Place_Field_X_Bins]=find(This_Place_Field==1);
                        Position_Data_In_This_Place_Field=zeros(1,9);
                        Spikes_In_This_Place_Field_Index=zeros(1,1);
                        for Bin=1:length(This_Place_Field_Y_Bins)
                            Position_Data_In_This_Place_Field=[Position_Data_In_This_Place_Field;Position_Data(Position_Data(:,8)==This_Place_Field_X_Bins(Bin) & Position_Data(:,9)==This_Place_Field_Y_Bins(Bin),:)];
                            Spikes_In_This_Place_Field_Index=[Spikes_In_This_Place_Field_Index;find(Spike_Data(:,2)==Current_Cell & Spike_Information(:,5)==This_Place_Field_X_Bins(Bin) & Spike_Information(:,6)==This_Place_Field_Y_Bins(Bin))];
                        end
                        Position_Data_In_This_Place_Field=Position_Data_In_This_Place_Field(2:end,:);
                        Spikes_In_This_Place_Field_Index=Spikes_In_This_Place_Field_Index(2:end,:);
                        Position_Data_In_This_Place_Field=sortrows(Position_Data_In_This_Place_Field,1);
                        Distance_From_Place_Field_Peak=sqrt(((Position_Data_In_This_Place_Field(:,2)-This_Place_Field_Peak_X).^2)+((Position_Data_In_This_Place_Field(:,3)-This_Place_Field_Peak_Y).^2));
                        Normalized_Distance_From_Place_Field_Peak=Distance_From_Place_Field_Peak-min(Distance_From_Place_Field_Peak);
                        Normalized_Distance_From_Place_Field_Peak=Normalized_Distance_From_Place_Field_Peak/max(Normalized_Distance_From_Place_Field_Peak);
                        Movement_Direction_Relative_To_Place_Field_Peak=zeros(size(Position_Data_In_This_Place_Field,1),1);
                        for N=1:size(Position_Data_In_This_Place_Field,1)
                            X_Diff=This_Place_Field_Peak_X-Position_Data_In_This_Place_Field(N,2);
                            Y_Diff=This_Place_Field_Peak_Y-Position_Data_In_This_Place_Field(N,3);
                            if Y_Diff==0 && X_Diff>0
                                Angle=270;
                            elseif Y_Diff==0 && X_Diff<0
                                Angle=90;
                            elseif X_Diff==0 && Y_Diff>0
                                Angle=180;
                            elseif X_Diff==0 && Y_Diff<0
                                Angle=360;
                            elseif X_Diff>0 && Y_Diff>0
                                Angle=180+atand(abs(X_Diff)/abs(Y_Diff));
                            elseif X_Diff>0 && Y_Diff<0
                                Angle=270+abs(atand(abs(Y_Diff)/abs(X_Diff)));
                            elseif X_Diff<0 && Y_Diff>0
                                Angle=90+abs(atand(abs(Y_Diff)/abs(X_Diff)));
                            elseif X_Diff<0 && Y_Diff<0
                                Angle=atand(abs(X_Diff)/abs(Y_Diff));
                            else
                                Angle=NaN;
                            end
                            if Angle>360
                                Angle=Angle-360;
                            end
                            Angle_Difference=max([Position_Data_In_This_Place_Field(N,6)-Angle,Angle-Position_Data_In_This_Place_Field(N,6)]); %Position_Data(:,6) is the current movement angle of the rat
                            if Angle_Difference>180
                                Angle_Difference=abs(Angle_Difference-360);
                            end
                            Movement_Direction_Relative_To_Place_Field_Peak(N,1)=Angle_Difference;
                        end
                        Normalized_Distance_From_Place_Field_Peak(Movement_Direction_Relative_To_Place_Field_Peak<90)=-1*Normalized_Distance_From_Place_Field_Peak(Movement_Direction_Relative_To_Place_Field_Peak<90);
                        Normalized_Distance_Per_Spike=zeros(length(Spikes_In_This_Place_Field_Index),1);
                        for N=1:length(Spikes_In_This_Place_Field_Index)
                            Normalized_Distance_Per_Spike(N,1)=Normalized_Distance_From_Place_Field_Peak(find(abs(Position_Data_In_This_Place_Field(:,1)-Spike_Data(Spikes_In_This_Place_Field_Index(N),1))==min(abs(Position_Data_In_This_Place_Field(:,1)-Spike_Data(Spikes_In_This_Place_Field_Index(N),1))),1,'first'));
                        end
                        Spike_Data(Spikes_In_This_Place_Field_Index,7)=Normalized_Distance_Per_Spike;
                        if Used_Best==0 && This_Place_Field_Max==Peak_Firing_Rate
                            Used_Best=1;
                            Spike_Data(Spikes_In_This_Place_Field_Index,8)=Normalized_Distance_Per_Spike;
                        end
                    end
                end
                clear This_Place_Field;
            end
            Position_Bins=-1:0.1:1; %Splitting the position into 20 even bins
            Phase_Bins=0:Initial_Variables.Phase_Bin:360; %Splitting the phases into 36 even bins 
            Restricted_Spike_Data=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & ~isnan(Spike_Data(:,7)),:);
            Restricted_Spike_Data(Restricted_Spike_Data(:,7)==-1,7)=-0.999999999; 
            Normalized_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
            for Position_Bin=1:(length(Position_Bins)-1)
                for Phase_Bin=1:(length(Phase_Bins)-1)
                    Normalized_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Restricted_Spike_Data(:,3)>Phase_Bins(Phase_Bin) & Restricted_Spike_Data(:,3)<=Phase_Bins(Phase_Bin+1) & Restricted_Spike_Data(:,7)>Position_Bins(Position_Bin) & Restricted_Spike_Data(:,7)<=Position_Bins(Position_Bin+1));
                end
            end
            for Shuffle=1:Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship
                Shuffled_Spike_Phases=Restricted_Spike_Data(:,3)+((rand(size(Restricted_Spike_Data,1),1)-0.5)*360);
                Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)=Shuffled_Spike_Phases(Shuffled_Spike_Phases<=0)+360;
                Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)=Shuffled_Spike_Phases(Shuffled_Spike_Phases>360)-360;
                Shuffled_Spike_Positions=(2*(rand(size(Restricted_Spike_Data,1),1)))-1;
                Shuffled_Spike_Positions(Shuffled_Spike_Positions==-1)=-0.999999999;
                Phase_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                Position_Shuffle_Position_Phase_Histogram=zeros(length(Phase_Bins)-1,length(Position_Bins)-1);
                for Position_Bin=1:(length(Position_Bins)-1)
                    for Phase_Bin=1:(length(Phase_Bins)-1)
                        Phase_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Shuffled_Spike_Phases>Phase_Bins(Phase_Bin) & Shuffled_Spike_Phases<=Phase_Bins(Phase_Bin+1) & Restricted_Spike_Data(:,7)>Position_Bins(Position_Bin) & Restricted_Spike_Data(:,7)<=Position_Bins(Position_Bin+1));
                        Position_Shuffle_Position_Phase_Histogram(Phase_Bin,Position_Bin)=sum(Restricted_Spike_Data(:,3)>Phase_Bins(Phase_Bin) & Restricted_Spike_Data(:,3)<=Phase_Bins(Phase_Bin+1) & Shuffled_Spike_Positions>Position_Bins(Position_Bin) & Shuffled_Spike_Positions<=Position_Bins(Position_Bin+1));
                    end
                end
                Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,Shuffle)=Phase_Shuffle_Position_Phase_Histogram;
                Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,Shuffle)=Position_Shuffle_Position_Phase_Histogram;
            end
            Smoothed_Position_Phase_Histogram=filter2(Filter,[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram]);
            Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
            Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
            Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
            Position_Phase_Histograms(:,:,Current_Cell)=[Normalized_Position_Phase_Histogram;Normalized_Position_Phase_Histogram];
            Smoothed_Position_Phase_Histograms(:,:,Current_Cell)=Interpolated_Position_Phase_Histogram;
        end
    end
    
    save('Spike_Data_With_Relative_Position','Spike_Data','Spike_Information','Position_Phase_Histograms','Smoothed_Position_Phase_Histograms','Position_Phase_Histograms_Phase_Shuffles','Position_Phase_Histograms_Position_Shuffles','-v7.3')
end

end

