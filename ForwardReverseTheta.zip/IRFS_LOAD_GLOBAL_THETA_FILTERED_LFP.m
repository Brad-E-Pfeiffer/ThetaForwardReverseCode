function LFP_Left_Theta=IRFS_LOAD_GLOBAL_THETA_FILTERED_LFP(Raw_LFP_Root_Directory,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function pulls up the raw LFP for each experiment and filters it in
% the theta band and saves it.  For legacy reasons, it saves it as
% "Left_LFP_Theta" (because all of the original choices are from the left
% hemisphere). 
% 
% Depending on where the raw LFP data is stored, the Raw_LFP_Directory
% variables might need to be changed below.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Current_Working_Directory=pwd;

if Rat==1
    %Channel_Number=77;  %This was my original choice (Tetrode 20)
    Channel_Number=9;  %This was Mengni's original choice (Tetrode 3)
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-06_LinearTrack_NoReplay\\2010-04-06_13-35-33'';',Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Raw_LFP_Root_Directory));
    elseif Experiment==3
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Raw_LFP_Root_Directory));
    elseif Experiment==4
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-11_LinearTrack_OneReplay\\2010-04-11_12-45-01'';',Raw_LFP_Root_Directory));
    elseif Experiment==5
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Raw_LFP_Root_Directory));
    elseif Experiment==6
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Raw_LFP_Root_Directory));
    elseif Experiment==7
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-07_OpenField(Day_ZeroTwo)\\2010-04-07_11-03-59'';',Raw_LFP_Root_Directory));
    elseif Experiment==8
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-07_OpenField(DayOne)\\2010-04-07_18-30-08'';',Raw_LFP_Root_Directory));
    end
elseif Rat==2
    %Channel_Number=70;  %This was my original choice (Tetrode 18)
    Channel_Number=139;  %This was Mengni's original choice (Tetrode 35)
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-08 One_Run_Trial\\2010-01-08_12-33-36'';',Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Raw_LFP_Root_Directory));
    elseif Experiment==3
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-10 First_Open_Field\\2010-01-10_15-48-05'';',Raw_LFP_Root_Directory));
    elseif Experiment==4
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-12 Second_Open_Field\\2010-01-12_15-20-49'';',Raw_LFP_Root_Directory));
    end
elseif Rat==3
    %Channel_Number=13;  %This was my original choice (Tetrode 4)
    Channel_Number=61;  %This was Mengni's original choice (Tetrode 16)
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-22 Linear_Track_Reward_Big_Reward_Separate\\2010-02-22_17-29-17'';',Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-27 Linear_Track_Reward_Big_Reward_Same\\2010-02-27_16-12-54'';',Raw_LFP_Root_Directory));
    elseif Experiment==3
        eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-17 First Open Field Experiment\\2010-02-17_17-23-35'';',Raw_LFP_Root_Directory));
    elseif Experiment==4
        eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-18 Second Open Field Experiment\\2010-02-18_17-03-47'';',Raw_LFP_Root_Directory));
    end
end

cd(Raw_LFP_Directory)

LFP_Filename=sprintf('CSC%d.ncs',Channel_Number);
LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);
LFP_Header=Nlx2MatCSC(LFP_Filename,[0 0 0 0 0],1,1,0);
for Header_Line=1:length(LFP_Header)
    Header_Info=cell2mat(LFP_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            Max_Value=str2double(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            Max_Range=str2double(Header_Info(13:end));
        end
    end
end
[LFP_Times,LFP_Samples]=Nlx2MatCSC(LFP_Filename,[1 0 0 0 1],0,1);
LFP_Times=LFP_Times/1000000; %put timestamps into seconds scale
LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value); %put LFP data into uV scale
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
end
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
clear B;
clear LFP_Times;
Times=Times(:);
LFP_Data=[Times,LFP_Samples];
LFP_Left=LFP_Data;
LFP_Electrodes=Channel_Number;

cd(Current_Working_Directory);

save('LFP_Left','LFP_Left','LFP_Frequency','LFP_Electrodes','-v7.3');
clear LFP_Left;
clear Times;
clear LFP_Samples;
clear Max_Range;
clear Max_Value;

Theta_Stop_Low=5;
Theta_Pass_Low=6;                % Some papers use as low as 4 Hz as the low cutoff
Theta_Pass_High=12;              % Some papers use as high as 12 Hz as the high cutoff
Theta_Stop_High=14;
Stop_Band_Attenuation_One=60;    % This was the default, I think.
Pass_Band=1;                     % This was the default, I think.
Stop_Band_Attenuation_Two=80;    % This was the default, I think.
Filter_Design_For_Theta=fdesign.bandpass(Theta_Stop_Low, Theta_Pass_Low, Theta_Pass_High, Theta_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Theta_Filter=design(Filter_Design_For_Theta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

Theta_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
Theta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,LFP_Data(:,2));
clear LFP_Data;
Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,Theta_Filtered_LFP_Data(:,2));
Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);
Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi)+180;
Theta_Filtered_LFP_Data(:,3)=abs(Theta_Filtered_LFP_Data(:,3));
Theta_Gaussian_Filter=fspecial('gaussian',[round(3*(300/((1/LFP_Frequency)*1000))),1],round(300/((1/LFP_Frequency)*1000))); %Gaussian filter with a sigma of 300 ms
Theta_Filtered_LFP_Data(:,3)=filtfilt(Theta_Gaussian_Filter,1,Theta_Filtered_LFP_Data(:,3));
Theta_Filtered_LFP_Data(:,3)=zscore(Theta_Filtered_LFP_Data(:,3));
LFP_Left_Theta=Theta_Filtered_LFP_Data;

save('LFP_Left_Theta','LFP_Left_Theta','-v7.3');

end

