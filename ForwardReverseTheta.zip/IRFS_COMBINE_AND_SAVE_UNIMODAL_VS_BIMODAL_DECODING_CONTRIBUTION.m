function IRFS_COMBINE_AND_SAVE_UNIMODAL_VS_BIMODAL_DECODING_CONTRIBUTION(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads up the previously processed and saved unimodal and
% bimodal data for each individual session, combines it, and saves it.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Bimodal_Analysis_Windows
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load('Comparison_Between_Unimodal_And_Bimodal_Decoding','Unimodal_Vs_Bimodal_Decoded_Data');
        load('Decoding_Time_Info','Decoding_Time_Info','Decoding_Window_Index');
        Decoding_Time_Phases=Decoding_Time_Info(Decoding_Window_Index,6);
        Unimodal_Probability_Sums=(sum(Unimodal_Vs_Bimodal_Decoded_Data(:,:,1)))';
        Bimodal_Probability_Sums=(sum(Unimodal_Vs_Bimodal_Decoded_Data(:,:,2)))';
        UPS_Foward_Window=Unimodal_Probability_Sums(Decoding_Time_Phases>Forward_Window(1) | Decoding_Time_Phases<=Forward_Window(2));
        UPS_Reverse_Window=Unimodal_Probability_Sums(Decoding_Time_Phases>Reverse_Window(1) & Decoding_Time_Phases<=Reverse_Window(2));
        BPS_Foward_Window=Bimodal_Probability_Sums(Decoding_Time_Phases>Forward_Window(1) | Decoding_Time_Phases<=Forward_Window(2));
        BPS_Reverse_Window=Bimodal_Probability_Sums(Decoding_Time_Phases>Reverse_Window(1) & Decoding_Time_Phases<=Reverse_Window(2));
        
        eval(sprintf('%s_%s_Unimodal_Probability_Sums=Unimodal_Probability_Sums;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Probability_Sums=Bimodal_Probability_Sums;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Uni_Prob_Sums_Forward_Window=UPS_Foward_Window;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Uni_Prob_Sums_Reverse_Window=UPS_Reverse_Window;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Bi_Prob_Sums_Forward_Window=BPS_Foward_Window;',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Bi_Prob_Sums_Reverse_Window=BPS_Reverse_Window;',Rats(Rat).name,Directory_Name));
        if exist('All_Unimodal_Probability_Sums','var')==1
            All_Unimodal_Probability_Sums=[All_Unimodal_Probability_Sums;Unimodal_Probability_Sums];
            All_Bimodal_Probability_Sums=[All_Bimodal_Probability_Sums;Bimodal_Probability_Sums];
            All_Uni_Prob_Sums_Forward_Window=[All_Uni_Prob_Sums_Forward_Window;UPS_Foward_Window];
            All_Uni_Prob_Sums_Reverse_Window=[All_Uni_Prob_Sums_Reverse_Window;UPS_Reverse_Window];
            All_Bi_Prob_Sums_Forward_Window=[All_Bi_Prob_Sums_Forward_Window;BPS_Foward_Window];
            All_Bi_Prob_Sums_Reverse_Window=[All_Bi_Prob_Sums_Reverse_Window;BPS_Reverse_Window];
            All_Uni_Prob_Sums_Mean_Forward_Window=[All_Uni_Prob_Sums_Mean_Forward_Window;mean(UPS_Foward_Window)];
            All_Uni_Prob_Sums_Mean_Reverse_Window=[All_Uni_Prob_Sums_Mean_Reverse_Window;mean(UPS_Reverse_Window)];
            All_Bi_Prob_Sums_Mean_Forward_Window=[All_Bi_Prob_Sums_Mean_Forward_Window;mean(BPS_Foward_Window)];
            All_Bi_Prob_Sums_Mean_Reverse_Window=[All_Bi_Prob_Sums_Mean_Reverse_Window;mean(BPS_Reverse_Window)];
        else
            All_Unimodal_Probability_Sums=Unimodal_Probability_Sums;
            All_Bimodal_Probability_Sums=Bimodal_Probability_Sums;
            All_Uni_Prob_Sums_Forward_Window=UPS_Foward_Window;
            All_Uni_Prob_Sums_Reverse_Window=UPS_Reverse_Window;
            All_Bi_Prob_Sums_Forward_Window=BPS_Foward_Window;
            All_Bi_Prob_Sums_Reverse_Window=BPS_Reverse_Window;
            All_Uni_Prob_Sums_Mean_Forward_Window=mean(UPS_Foward_Window);
            All_Uni_Prob_Sums_Mean_Reverse_Window=mean(UPS_Reverse_Window);
            All_Bi_Prob_Sums_Mean_Forward_Window=mean(BPS_Foward_Window);
            All_Bi_Prob_Sums_Mean_Reverse_Window=mean(BPS_Reverse_Window);
        end
        cd ..
        clearvars -except All_* Janni_* Harpy_* Imp_* Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name Forward_Window Reverse_Window
    end
    clear Directory
    cd ..
end

clear Rat;
clear Rat_Name;
clear Experiment;

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

save('Combined_Unimodal_Bimodal_Probability_Sums','-v7.3');

cd ..

end
