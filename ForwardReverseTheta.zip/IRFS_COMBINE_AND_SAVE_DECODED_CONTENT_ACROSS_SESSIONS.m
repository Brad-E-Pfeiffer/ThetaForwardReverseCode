function IRFS_COMBINE_AND_SAVE_DECODED_CONTENT_ACROSS_SESSIONS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads up the previously processed and saved unimodal and
% bimodal data for each individual session, combines it, and saves it.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Average_Theta_Sequence_And_Posterior_Dists
        load Average_Theta_Sequence_And_Posterior_Dists_Uni_Vs_Bi
        
        eval(sprintf('%s_%s_Average_Theta_Sequence=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Average_Theta_Sequence_Bimodal_Only=Average_Decoded_Theta_Sequence_Bimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Average_Theta_Sequence_Unimodal_Only=Average_Decoded_Theta_Sequence_Unimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Average_Theta_Sequence_Bimodal=Average_Decoded_Theta_Sequence_Bimodal((floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Average_Theta_Sequence_Unimodal=Average_Decoded_Theta_Sequence_Unimodal((floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post=Dist_Of_Peak_Post((floor(size(Dist_Of_Peak_Post,1)/2)-30):(floor(size(Dist_Of_Peak_Post,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Bi_Only=Dist_Of_Peak_Post_Bimodal_Only((floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Uni_Only=Dist_Of_Peak_Post_Unimodal_Only((floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Bi=Dist_Of_Peak_Post_Bimodal((floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Uni=Dist_Of_Peak_Post_Unimodal((floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Minor_Window_Tenths=Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Major_Window_Tenths=Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Minor_Window_Thirds=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Dist_Of_Peak_Post_Major_Window_Thirds=Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post=Norm_Dist_Of_Peak_Post((floor(size(Norm_Dist_Of_Peak_Post,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Bi_Only=Norm_Dist_Of_Peak_Post_Bimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Uni_Only=Norm_Dist_Of_Peak_Post_Unimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Bi=Norm_Dist_Of_Peak_Post_Bimodal((floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Uni=Norm_Dist_Of_Peak_Post_Unimodal((floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Minor_Window_Tenths=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Major_Window_Tenths=Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        eval(sprintf('%s_%s_Norm_Dist_Of_Peak_Post_Major_Window_Thirds=Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);',Rats(Rat).name,Directory_Name));
        if strcmp(Directory_Name(1),'L')
            eval(sprintf('%s_%s_Average_Linear_Theta_Sequence=Average_Linear_Decoded_Theta_Sequence((floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)+30),:);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Dist_Of_Linear_In_Down_Minor_Top_Third=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Dist_Of_Linear_In_Up_Minor_Top_Third=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Dist_Of_Linear_Out_Down_Minor_Top_Third=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Dist_Of_Linear_Out_Up_Minor_Top_Third=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third=Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third=Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third=Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third=Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);',Rats(Rat).name,Directory_Name));
        end
        if exist('All_Average_Theta_Sequence','var')==1
            All_Average_Theta_Sequence(:,:,end+1)=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
            All_Average_Theta_Sequence_Bimodal_Only(:,:,end+1)=Average_Decoded_Theta_Sequence_Bimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)+30),:);
            All_Average_Theta_Sequence_Unimodal_Only(:,:,end+1)=Average_Decoded_Theta_Sequence_Unimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)+30),:);
            All_Average_Theta_Sequence_Bimodal(:,:,end+1)=Average_Decoded_Theta_Sequence_Bimodal((floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)+30),:);
            All_Average_Theta_Sequence_Unimodal(:,:,end+1)=Average_Decoded_Theta_Sequence_Unimodal((floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post(:,:,end+1)=Dist_Of_Peak_Post((floor(size(Dist_Of_Peak_Post,1)/2)-30):(floor(size(Dist_Of_Peak_Post,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Bi_Only(:,:,end+1)=Dist_Of_Peak_Post_Bimodal_Only((floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Uni_Only(:,:,end+1)=Dist_Of_Peak_Post_Unimodal_Only((floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Bi(:,:,end+1)=Dist_Of_Peak_Post_Bimodal((floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Uni(:,:,end+1)=Dist_Of_Peak_Post_Unimodal((floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Minor_Window_Tenths(:,:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Major_Window_Tenths(:,:,:,end+1)=Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds(:,:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni(:,:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi(:,:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Major_Window_Thirds(:,:,:,end+1)=Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post(:,:,end+1)=Norm_Dist_Of_Peak_Post((floor(size(Norm_Dist_Of_Peak_Post,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Bi_Only(:,:,end+1)=Norm_Dist_Of_Peak_Post_Bimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Uni_Only(:,:,end+1)=Norm_Dist_Of_Peak_Post_Unimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Bi(:,:,end+1)=Norm_Dist_Of_Peak_Post_Bimodal((floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Uni(:,:,end+1)=Norm_Dist_Of_Peak_Post_Unimodal((floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Tenths(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Major_Window_Tenths(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Major_Window_Thirds(:,:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);
        else
            All_Average_Theta_Sequence=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
            All_Average_Theta_Sequence_Bimodal_Only=Average_Decoded_Theta_Sequence_Bimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal_Only,1)/2)+30),:);
            All_Average_Theta_Sequence_Unimodal_Only=Average_Decoded_Theta_Sequence_Unimodal_Only((floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal_Only,1)/2)+30),:);
            All_Average_Theta_Sequence_Bimodal=Average_Decoded_Theta_Sequence_Bimodal((floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Bimodal,1)/2)+30),:);
            All_Average_Theta_Sequence_Unimodal=Average_Decoded_Theta_Sequence_Unimodal((floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence_Unimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post=Dist_Of_Peak_Post((floor(size(Dist_Of_Peak_Post,1)/2)-30):(floor(size(Dist_Of_Peak_Post,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Bi_Only=Dist_Of_Peak_Post_Bimodal_Only((floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Uni_Only=Dist_Of_Peak_Post_Unimodal_Only((floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Bi=Dist_Of_Peak_Post_Bimodal((floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Uni=Dist_Of_Peak_Post_Unimodal((floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);
            All_Dist_Of_Peak_Post_Minor_Window_Tenths=Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Major_Window_Tenths=Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);
            All_Dist_Of_Peak_Post_Major_Window_Thirds=Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post=Norm_Dist_Of_Peak_Post((floor(size(Norm_Dist_Of_Peak_Post,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Bi_Only=Norm_Dist_Of_Peak_Post_Bimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal_Only,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Uni_Only=Norm_Dist_Of_Peak_Post_Unimodal_Only((floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal_Only,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Bi=Norm_Dist_Of_Peak_Post_Bimodal((floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Bimodal,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Uni=Norm_Dist_Of_Peak_Post_Unimodal((floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_Unimodal,1)/2)+30),:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Tenths=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Major_Window_Tenths=Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Uni=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds_Bi=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,1)/2)+30),:,:);
            All_Norm_Dist_Of_Peak_Post_Major_Window_Thirds=Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds,1)/2)+30),:,:);
        end
        if strcmp(Directory_Name(1),'L')
            if exist('All_Average_Linear_Theta_Sequence','var')==1
                All_Average_Linear_2D_Theta_Sequence(:,:,end+1)=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Average_Linear_Theta_Sequence(:,:,end+1)=Average_Linear_Decoded_Theta_Sequence((floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Dist_Of_Linear_2D_Top_Third(:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Top_Third(:,:,end+1)=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_In_Down_Minor_Top_Third(:,:,end+1)=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_In_Up_Minor_Top_Third(:,:,end+1)=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Out_Down_Minor_Top_Third(:,:,end+1)=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Out_Up_Minor_Top_Third(:,:,end+1)=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_2D_Top_Third(:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Top_Third(:,:,end+1)=Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third(:,:,end+1)=Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third(:,:,end+1)=Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third(:,:,end+1)=Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third(:,:,end+1)=Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
            else
                All_Average_Linear_2D_Theta_Sequence=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Average_Linear_Theta_Sequence=Average_Linear_Decoded_Theta_Sequence((floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Linear_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Dist_Of_Linear_2D_Top_Third=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Top_Third=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_In_Down_Minor_Top_Third=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_In_Up_Minor_Top_Third=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Out_Down_Minor_Top_Third=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Dist_Of_Linear_Out_Up_Minor_Top_Third=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_2D_Top_Third=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Top_Third=Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_In_Down_Minor_Top_Third=Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_In_Up_Minor_Top_Third=Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Out_Down_Minor_Top_Third=Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Linear_Out_Up_Minor_Top_Third=Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
            end
        else
            if exist('All_Average_Open_Theta_Sequence','var')==1
                All_Average_Open_Theta_Sequence(:,:,end+1)=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Dist_Of_Open_Top_Third(:,:,end+1)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Open_Top_Third(:,:,end+1)=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
            else
                All_Average_Open_Theta_Sequence=Average_Decoded_Theta_Sequence((floor(size(Average_Decoded_Theta_Sequence,1)/2)-30):(floor(size(Average_Decoded_Theta_Sequence,1)/2)+30),:);
                All_Dist_Of_Open_Top_Third=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
                All_Norm_Dist_Of_Open_Top_Third=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)-30):(floor(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2)+30),:,3);
            end
        end
        cd ..
        clearvars -except All_* Janni_* Harpy_* Imp_* Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name
    end
    clear Directory
    cd ..
end

clear Rat;
clear Rat_Name;
clear Experiment;

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

save('Combined_Theta_Sequences','-v7.3');

cd ..

end
