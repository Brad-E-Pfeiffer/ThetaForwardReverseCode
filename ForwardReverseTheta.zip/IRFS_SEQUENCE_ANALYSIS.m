function [Sequence_Value]=IRFS_SEQUENCE_ANALYSIS(Matrix,Max_Step_Size)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This takes a two-dimensional Matrix of position probabilities across time
% and calculates the Sequence Value.  The Sequence Value is the average
% value of all steps.  The step value is calculated by comparing the
% location of maximum posterior probability between consecutive steps.  A
% step has a value of 1 if it is in the same direction as the median step
% direction and is less than Max_Step_Size (in bins).  The larger the step,
% the lower the value. Steps that don't move have a value of 0.5.  Steps
% that move in the opposite direction of the median step direction have a
% value of 0.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

[~,Max_Locations]=max(Matrix);
Step_Sizes=diff(Max_Locations);
Step_Values=zeros(length(Step_Sizes),1);
Step_Values(Step_Sizes==0,1)=0.5;
Step_Values(abs(Step_Sizes)>0 & abs(Step_Sizes)<=Max_Step_Size,1)=1;
if sum(abs(Step_Sizes)>Max_Step_Size)>0
    Step_Values(abs(Step_Sizes)>Max_Step_Size,1)=1./(abs(Step_Sizes(abs(Step_Sizes)>Max_Step_Size))-(Max_Step_Size-1));
end
Step_Directions=sign(Step_Sizes);
if sum(Step_Directions~=0)>0
    Opposite_Movement_Direction=-1*median(Step_Directions(Step_Directions~=0));
    Step_Values(Step_Directions==Opposite_Movement_Direction)=0;
end
Sequence_Value=mean(Step_Values);

end