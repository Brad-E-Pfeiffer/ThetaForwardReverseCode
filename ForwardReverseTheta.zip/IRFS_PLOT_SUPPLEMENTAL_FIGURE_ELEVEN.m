function IRFS_PLOT_SUPPLEMENTAL_FIGURE_ELEVEN

cd Janni
cd Open1
load Spike_Data
load Spike_Waveforms
load Modality
cd ..
cd ..
cd AllRatsCombined
cd _Figures_For_Paper
cd SupplementalFigure11

Tetrodes_To_Use=unique(Tetrode_Cell_IDs(:,1));
for Current_Tetrode=1:length(Tetrodes_To_Use)
    Tetrode=Tetrodes_To_Use(Current_Tetrode);
    Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Tetrode,2);
    Cells_On_This_Tetrode(:,2)=0;
    for Current_Cell=1:size(Cells_On_This_Tetrode,1)
        Cell=Cells_On_This_Tetrode(Current_Cell);
        Cells_On_This_Tetrode(Current_Cell,2)=Modality(Modality(:,2)==Cell,1);
    end
    Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode(:,2)==1 | Cells_On_This_Tetrode(:,2)==2,1);
    for N=1:length(Inhibitory_Neurons)
        Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode~=Inhibitory_Neurons(N));
    end
    if ~isempty(Cells_On_This_Tetrode)
        for Current_Cell=1:length(Cells_On_This_Tetrode)
            Cell=Cells_On_This_Tetrode(Current_Cell);
            Current_Cell_Waveforms=Spike_Waveforms(:,:,Spike_Data(:,2)==Cell);
            Recentered_Current_Cell_Waveforms=zeros(size(Current_Cell_Waveforms));
            for Spike=1:size(Current_Cell_Waveforms,3)
                [Max1,Location1]=max(Current_Cell_Waveforms(:,1,Spike));
                [Max2,Location2]=max(Current_Cell_Waveforms(:,2,Spike));
                [Max3,Location3]=max(Current_Cell_Waveforms(:,3,Spike));
                [Max4,Location4]=max(Current_Cell_Waveforms(:,4,Spike));
                Maxes=[Max1,Max2,Max3,Max4];
                Locations=[Location1,Location2,Location3,Location4];
                [~,Max_Location]=max(Maxes);
                Max_Location=Locations(Max_Location);
                Current_Spike_Waveforms=Current_Cell_Waveforms(:,:,Spike);
                if Max_Location<8
                    Diff=8-Max_Location;
                    Current_Spike_Waveforms=[nan(Diff,4);Current_Spike_Waveforms(1:(size(Current_Spike_Waveforms,1)-Diff),:)];
                elseif Max_Location>8
                    Diff=Max_Location-8;
                    Current_Spike_Waveforms=[Current_Spike_Waveforms((Diff+1):size(Current_Spike_Waveforms,1),:);nan(Diff,4)];
                end
                Recentered_Current_Cell_Waveforms(:,:,Spike)=Current_Spike_Waveforms;
            end
            Mean_Cell_Waveforms=mean(Recentered_Current_Cell_Waveforms,3,'omitnan');
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,1,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,1),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,2,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,2),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,3,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,3),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,4,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,4),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat1_Open1_Tetrode%d_Cell%d_Unimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat1_Open1_Tetrode%d_Cell%d_Bimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,1),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,2),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,3),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,4),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat1_Open1_Tetrode_%d_Cell_%d_Unimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat1_Open1_Tetrode_%d_Cell_%d_Bimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
        end
    end
end
cd ..
cd ..
cd ..
clear Spike_Data
clear Spike_Waveforms
clear Modality
clear Tetrode_Cell_IDs

cd Harpy
cd Open2
load Spike_Data
load Spike_Waveforms
load Modality
cd ..
cd ..
cd AllRatsCombined
cd _Figures_For_Paper
cd SupplementalFigure15
Tetrodes_To_Use=unique(Tetrode_Cell_IDs(:,1));
for Current_Tetrode=1:length(Tetrodes_To_Use)
    Tetrode=Tetrodes_To_Use(Current_Tetrode);
    Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Tetrode,2);
    Cells_On_This_Tetrode(:,2)=0;
    for Current_Cell=1:size(Cells_On_This_Tetrode,1)
        Cell=Cells_On_This_Tetrode(Current_Cell);
        Cells_On_This_Tetrode(Current_Cell,2)=Modality(Modality(:,2)==Cell,1);
    end
    Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode(:,2)==1 | Cells_On_This_Tetrode(:,2)==2,1);
    for N=1:length(Inhibitory_Neurons)
        Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode~=Inhibitory_Neurons(N));
    end
    if ~isempty(Cells_On_This_Tetrode)
        for Current_Cell=1:length(Cells_On_This_Tetrode)
            Cell=Cells_On_This_Tetrode(Current_Cell);
            Current_Cell_Waveforms=Spike_Waveforms(:,:,Spike_Data(:,2)==Cell);
            Recentered_Current_Cell_Waveforms=zeros(size(Current_Cell_Waveforms));
            for Spike=1:size(Current_Cell_Waveforms,3)
                [Max1,Location1]=max(Current_Cell_Waveforms(:,1,Spike));
                [Max2,Location2]=max(Current_Cell_Waveforms(:,2,Spike));
                [Max3,Location3]=max(Current_Cell_Waveforms(:,3,Spike));
                [Max4,Location4]=max(Current_Cell_Waveforms(:,4,Spike));
                Maxes=[Max1,Max2,Max3,Max4];
                Locations=[Location1,Location2,Location3,Location4];
                [~,Max_Location]=max(Maxes);
                Max_Location=Locations(Max_Location);
                Current_Spike_Waveforms=Current_Cell_Waveforms(:,:,Spike);
                if Max_Location<8
                    Diff=8-Max_Location;
                    Current_Spike_Waveforms=[nan(Diff,4);Current_Spike_Waveforms(1:(size(Current_Spike_Waveforms,1)-Diff),:)];
                elseif Max_Location>8
                    Diff=Max_Location-8;
                    Current_Spike_Waveforms=[Current_Spike_Waveforms((Diff+1):size(Current_Spike_Waveforms,1),:);nan(Diff,4)];
                end
                Recentered_Current_Cell_Waveforms(:,:,Spike)=Current_Spike_Waveforms;
            end
            Mean_Cell_Waveforms=mean(Recentered_Current_Cell_Waveforms,3,'omitnan');
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,1,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,1),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,2,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,2),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,3,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,3),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,4,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,4),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat2_Open1_Tetrode%d_Cell%d_Unimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat2_Open1_Tetrode%d_Cell%d_Bimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,1),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,2),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,3),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,4),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat2_Open2_Tetrode_%d_Cell_%d_Unimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat2_Open2_Tetrode_%d_Cell_%d_Bimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
        end
    end
end
cd ..
cd ..
cd ..
clear Spike_Data
clear Spike_Waveforms
clear Modality
clear Tetrode_Cell_IDs

cd Imp
cd Open1
load Spike_Data
load Spike_Waveforms
load Modality
cd ..
cd ..
cd AllRatsCombined
cd _Figures_For_Paper
cd SupplementalFigure15

Tetrodes_To_Use=unique(Tetrode_Cell_IDs(:,1));
for Current_Tetrode=1:length(Tetrodes_To_Use)
    Tetrode=Tetrodes_To_Use(Current_Tetrode);
    Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Tetrode,2);
    Cells_On_This_Tetrode(:,2)=0;
    for Current_Cell=1:size(Cells_On_This_Tetrode,1)
        Cell=Cells_On_This_Tetrode(Current_Cell);
        Cells_On_This_Tetrode(Current_Cell,2)=Modality(Modality(:,2)==Cell,1);
    end
    Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode(:,2)==1 | Cells_On_This_Tetrode(:,2)==2,1);
    for N=1:length(Inhibitory_Neurons)
        Cells_On_This_Tetrode=Cells_On_This_Tetrode(Cells_On_This_Tetrode~=Inhibitory_Neurons(N));
    end
    if ~isempty(Cells_On_This_Tetrode)
        for Current_Cell=1:length(Cells_On_This_Tetrode)
            Cell=Cells_On_This_Tetrode(Current_Cell);
            Current_Cell_Waveforms=Spike_Waveforms(:,:,Spike_Data(:,2)==Cell);
            Recentered_Current_Cell_Waveforms=zeros(size(Current_Cell_Waveforms));
            for Spike=1:size(Current_Cell_Waveforms,3)
                [Max1,Location1]=max(Current_Cell_Waveforms(:,1,Spike));
                [Max2,Location2]=max(Current_Cell_Waveforms(:,2,Spike));
                [Max3,Location3]=max(Current_Cell_Waveforms(:,3,Spike));
                [Max4,Location4]=max(Current_Cell_Waveforms(:,4,Spike));
                Maxes=[Max1,Max2,Max3,Max4];
                Locations=[Location1,Location2,Location3,Location4];
                [~,Max_Location]=max(Maxes);
                Max_Location=Locations(Max_Location);
                Current_Spike_Waveforms=Current_Cell_Waveforms(:,:,Spike);
                if Max_Location<8
                    Diff=8-Max_Location;
                    Current_Spike_Waveforms=[nan(Diff,4);Current_Spike_Waveforms(1:(size(Current_Spike_Waveforms,1)-Diff),:)];
                elseif Max_Location>8
                    Diff=Max_Location-8;
                    Current_Spike_Waveforms=[Current_Spike_Waveforms((Diff+1):size(Current_Spike_Waveforms,1),:);nan(Diff,4)];
                end
                Recentered_Current_Cell_Waveforms(:,:,Spike)=Current_Spike_Waveforms;
            end
            Mean_Cell_Waveforms=mean(Recentered_Current_Cell_Waveforms,3,'omitnan');
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,1,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,1),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,2,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,2),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,3,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,3),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            for N=1:size(Recentered_Current_Cell_Waveforms,3)
                plot(1:32,Recentered_Current_Cell_Waveforms(:,4,N),'Color',[0.5 0.5 0.5]);
            end
            plot(1:32,Mean_Cell_Waveforms(:,4),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat3_Open1_Tetrode%d_Cell%d_Unimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat3_Open1_Tetrode%d_Cell%d_Bimodal(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
            Max=0;
            Min=0;
            figure;
            hold on;
            A=subplot('Position',[0 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,1),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            B=subplot('Position',[0.5 0 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,2),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            C=subplot('Position',[0.5 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,3),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            D=subplot('Position',[0 0.5 0.5 0.5]);
            hold on;
            plot([1,32],[0,0],'k--');
            plot(1:0.1:32,interp1(1:32,Mean_Cell_Waveforms(:,4),1:0.1:32,'spline'),'r','LineWidth',4);
            Y_Lim=ylim;
            if Y_Lim(1)<Min
                Min=Y_Lim(1);
            end
            if Y_Lim(2)>Max
                Max=Y_Lim(2);
            end
            set(A,'YLim',[Min Max]);
            set(B,'YLim',[Min Max]);
            set(C,'YLim',[Min Max]);
            set(D,'YLim',[Min Max]);
            set(A,'XLim',[1 32]);
            set(B,'XLim',[1 32]);
            set(C,'XLim',[1 32]);
            set(D,'XLim',[1 32]);
            set(A,'XTick',[]);
            set(A,'YTick',[]);
            set(B,'XTick',[]);
            set(B,'YTick',[]);
            set(C,'XTick',[]);
            set(C,'YTick',[]);
            set(D,'XTick',[]);
            set(D,'YTick',[]);
            if Modality(Modality(:,2)==Cell,1)==1
                eval(sprintf('print(''-djpeg'',''Rat3_Open1_Tetrode_%d_Cell_%d_Unimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            elseif Modality(Modality(:,2)==Cell,1)==2
                eval(sprintf('print(''-djpeg'',''Rat3_Open1_Tetrode_%d_Cell_%d_Bimodal_MeanOnly(Y=%dto%d).jpg'');',Tetrode,Cell,Min,Max));
            end
            close
        end
    end
end
cd ..
cd ..
cd ..
clear Spike_Data
clear Spike_Waveforms
clear Modality
clear Tetrode_Cell_IDs


end

