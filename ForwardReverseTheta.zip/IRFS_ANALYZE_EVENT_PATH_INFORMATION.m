function [Best_Sequence_Data,Best_Sequence]=IRFS_ANALYZE_EVENT_PATH_INFORMATION(Decoded_Sequence,Minimum_Step_Size,Minimum_Step_Number,Total_Distance)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function analyzes the path information listed in Decoded_Sequence
% (i.e., from the BAYESIAN_DECODING function).  This calculates the distance
% moved on each step and then finds consecutive steps that are within a
% certain number of bins, defined by Minimum_Step_Size.  Then, if there are
% a minimum number of consecutive steps (Minimum_Step_Number) and if that
% path goes a certain distance (start-to-end, Total_Distance), then this is
% considered a valid sequence.  The best (longest) sequence is identified
% and the data from this sequence is sent as output.  
% 
% Best_Sequence is a limited version of the input Decoded_Sequence that
% only contains the best sequence.  Best_Sequence_Data has the following
% data:
% 
% Best_Sequence_Data
% |     1      |     2     |        3        |          4            |       5        |
% |Start Index | End Index | Number of Steps | Start-to-End Distance | Total Distance |
% 
% If there are no consecutive sequences that meet the Minimum_Step_Number
% and Total_Distance requirements, Best_Sequence and Best_Sequence_Data are
% given values of zero. 
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


% If the user did not fully define the input variables, the most likely
% values are either searched for or automatically provided.
if ~exist('Minimum_Step_Size','var'),
    Minimum_Step_Size=20;
end
if ~exist('Minimum_Step_Number','var'),
    Minimum_Step_Number=10;
end
if ~exist('Total_Distance','var')
    Total_Distance=25;
end

% This adjusts Decoded_Sequence in case it came from a one-dimensional decoding 
if size(Decoded_Sequence,2)==2,
    Decoded_Sequence(:,3)=0;
end
Decoded_Sequence(:,4:8)=0;

% This measures the distance moved on each decoded frame
Decoded_Sequence(1:end-1,4)=sqrt((diff(Decoded_Sequence(:,2)).^2)+((diff(Decoded_Sequence(:,3)).^2)));

% This identifies periods of time when the movement was less than the Minimum_Step_Size
Decoded_Sequence(Decoded_Sequence(:,4)<=Minimum_Step_Size,5)=1;

% This finds the different stretches of movement, adding up the number
% of consecutive steps (column 6), the total distance covered (column
% 7), and the distance-from-the-start (column 8).
if Decoded_Sequence(1,5)==1,
    Decoded_Sequence(1,6)=1;
    Start_Index=1;
end
Max_Length=0;
for N=2:size(Decoded_Sequence,1)
    if Decoded_Sequence(N-1,5)==0,
        Decoded_Sequence(N,6)=Decoded_Sequence(N,5);
    else
        Decoded_Sequence(N,6)=Decoded_Sequence(N-1,6)+Decoded_Sequence(N,5);
        Decoded_Sequence(N,7)=Decoded_Sequence(N-1,7)+sqrt((diff(Decoded_Sequence((N-1):N,2)).^2)+((diff(Decoded_Sequence((N-1):N,3)).^2)));
    end
    if Decoded_Sequence(N,6)==Decoded_Sequence(N-1,6) && Decoded_Sequence(N,6)>0,
        Decoded_Sequence(N,6)=Decoded_Sequence(N,6)+1;
    end
    if Decoded_Sequence(N,6)<=1,
        Start_Index=N;
        Max_Length=0;
    elseif Decoded_Sequence(N,6)>1,
        M=N;
        while Decoded_Sequence(M,6)>1,
            Max_Length=max([Max_Length,sqrt((diff(Decoded_Sequence([Start_Index,M],2)).^2)+((diff(Decoded_Sequence([Start_Index,M],3)).^2)))]);
            M=M-1;
        end
        Decoded_Sequence(N,8)=Max_Length;
        %Decoded_Sequence(N,8)=max([sqrt((diff(Decoded_Sequence([Start_Index,N],2)).^2)+((diff(Decoded_Sequence([Start_Index,N],3)).^2))),max(Decoded_Sequence((Start_Index:N-1),8))]);
    end
end

% This finds all the contiguous movement sequences within the event
if size(Decoded_Sequence,1)>=3,
    [Peaks,Locations]=findpeaks(Decoded_Sequence(:,6));
    if Decoded_Sequence(end,6)>1,
        Locations(end+1,1)=size(Decoded_Sequence,1);
    end
else
    [Max,Locations]=max(Decoded_Sequence(:,6));
end

% This pulls up the number of steps, the total distance traveled, and
% the start-to-end distance traveled for every segment.
Sequence_Scores=Decoded_Sequence(Locations,6:8);

% This orders the various epochs of continuous movement, first by the
% number of steps, then (if there's a tie) by the maximum distance moved,
% then (if there's two ties) by the start-to-end distance.
Sequence_Scores=sortrows(Sequence_Scores,[-1,-3,-2]);

Good_Sequences=Sequence_Scores(find(Sequence_Scores(:,1)>=Minimum_Step_Number & Sequence_Scores(:,3)>=Total_Distance),:);
if ~isempty(Good_Sequences),
    Best_Sequence_End=find(Decoded_Sequence(:,6)==Good_Sequences(1,1) & Decoded_Sequence(:,8)==Good_Sequences(1,3),1,'first');
    Best_Sequence_Start=find(Decoded_Sequence(:,6)==1);
    Best_Sequence_Start=Best_Sequence_Start(find(Best_Sequence_Start<Best_Sequence_End,1,'last'));
    Best_Sequence=Decoded_Sequence(Best_Sequence_Start:Best_Sequence_End,:);
    Best_Sequence_Data=[Best_Sequence_Start,Best_Sequence_End,Best_Sequence(end,6),Best_Sequence(end,8),Best_Sequence(end,7)];
else
    Best_Sequence_Data=zeros(1,5);
    Best_Sequence=zeros(1,size(Decoded_Sequence,2));
end

end