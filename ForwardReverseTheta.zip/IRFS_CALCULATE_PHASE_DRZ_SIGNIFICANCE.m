function IRFS_CALCULATE_PHASE_DRZ_SIGNIFICANCE(Modality,Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function first calculates the place field for each cell.  It then
% calculates the DRZ for each spike (a normalized measure of location
% within each place field).  The phase for each spike has already been
% calculated, and this relationship is quantified across all cells.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Spike_Data_With_DRZ
Spike_Data(Spike_Data(:,3)==0,3)=360;
% Spike_Data
%|     1    |     2   |       3     |                           4                             |                      5                       |                            6                        |  7  |          8         ||
%| Time (s) | Cell ID | Theta Phase | Duration of LFP Oscillation (seconds, trough-to-trough) | Monotonically Increasing Cycle? (1=yes;0=no) | Time of LFP Trace That The Phase Was Taken From (s) | DRZ | DRZ for Best Field ||

All_Spikes_While_Running=Spike_Data(Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & Spike_Data(:,5)==1 & ~isnan(Spike_Data(:,7)),:);

for Current_Cell=1:max(Spike_Data(:,2))
    %This finds all spikes for this cell when the rat is running and when the theta cycle is monotonically increasing and when the DRZ is not 1 or -1 (i.e., when the rat is actually moving through the place field) 
    Spikes_While_Running=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & Spike_Data(:,5)==1 & ~isnan(Spike_Data(:,7)) & Spike_Data(:,7)>-1 & Spike_Data(:,7)<1,:);
    %Spikes_While_Running=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=Initial_Variables.Velocity_Cutoff & Spike_Data(:,5)==1 & ~isnan(Spike_Data(:,8)) & Spike_Data(:,8)>-1 & Spike_Data(:,8)<1,:);
    
    %For simplicity, I'm assuming a DRZ bin of 0.1 and a phase bin of 10 degrees 
    Phase_DRZ_Histogram=zeros(36,20);
    Phase_Bins=10:10:360;
    DRZ_Bins=-0.9:0.1:1;
    for Phase_Bin=1:36
        for DRZ_Bin=1:20
            Phase_DRZ_Histogram(Phase_Bin,DRZ_Bin)=sum(Spikes_While_Running(:,3)>(Phase_Bins(Phase_Bin)-10) & Spikes_While_Running(:,3)<=Phase_Bins(Phase_Bin) & Spikes_While_Running(:,7)>(DRZ_Bins(DRZ_Bin)-0.1) & Spikes_While_Running(:,7)<=DRZ_Bins(DRZ_Bin));
        end
    end
    
    Cell_Modality=Modality(Current_Cell,1);
    
%     Filter=fspecial('gaussian',[10 5],2);
%     Smoothed_Phase_DRZ_Histogram=filter2(Filter,[Phase_DRZ_Histogram;Phase_DRZ_Histogram]);
%     Interpolated_Smoothed_Phase_DRZ_Histogram=interp2(permute(ones(20,72).*(-0.9:0.1:1)',[2,1]),ones(72,20).*(10:10:720)',Smoothed_Phase_DRZ_Histogram,permute(ones(200,720).*(-0.99:0.01:1)',[2,1]),ones(720,200).*(1:1:720)');
%     figure;hold on;subplot(2,2,1);hold on;imagesc([Phase_DRZ_Histogram;Phase_DRZ_Histogram]);colormap('hot');
%     subplot(2,2,2);hold on;imagesc(Smoothed_Phase_DRZ_Histogram);colormap('hot');
%     subplot(2,2,3);hold on;imagesc(Interpolated_Smoothed_Phase_DRZ_Histogram);colormap('hot');
%     subplot(2,2,4);hold on;contour(Interpolated_Smoothed_Phase_DRZ_Histogram,'k');
%     eval(sprintf('title(''Cell %d; Modality = %d'');',Current_Cell,Cell_Modality));
    

%Good examples
%JL4, Cell 1 (U)
%     Cell 33 (B)

            
    
    if Cell_Modality==1 && exist('Unimodal_Spikes_While_Running','var')
        Unimodal_Spikes_While_Running=[Unimodal_Spikes_While_Running;Spikes_While_Running];
    elseif Cell_Modality==1
        Unimodal_Spikes_While_Running=Spikes_While_Running;
    elseif Cell_Modality==2 && exist('Bimodal_Spikes_While_Running','var')
        Bimodal_Spikes_While_Running=[Bimodal_Spikes_While_Running;Spikes_While_Running];
    elseif Cell_Modality==2
        Bimodal_Spikes_While_Running=Spikes_While_Running;
    end
    %figure;hold on;plot([Spikes_While_Running(:,7);Spikes_While_Running(:,7)],[Spikes_While_Running(:,3);Spikes_While_Running(:,3)+360],'.')
    
end


    Unimodal_Phase_DRZ_Histogram=zeros(36,20);
    Bimodal_Phase_DRZ_Histogram=zeros(36,20);
    Phase_Bins=10:10:360;
    DRZ_Bins=-0.9:0.1:1;
    for Phase_Bin=1:36
        for DRZ_Bin=1:20
            Unimodal_Phase_DRZ_Histogram(Phase_Bin,DRZ_Bin)=sum(Unimodal_Spikes_While_Running(:,3)>(Phase_Bins(Phase_Bin)-10) & Unimodal_Spikes_While_Running(:,3)<=Phase_Bins(Phase_Bin) & Unimodal_Spikes_While_Running(:,7)>(DRZ_Bins(DRZ_Bin)-0.1) & Unimodal_Spikes_While_Running(:,7)<=DRZ_Bins(DRZ_Bin));
            Bimodal_Phase_DRZ_Histogram(Phase_Bin,DRZ_Bin)=sum(Bimodal_Spikes_While_Running(:,3)>(Phase_Bins(Phase_Bin)-10) & Bimodal_Spikes_While_Running(:,3)<=Phase_Bins(Phase_Bin) & Bimodal_Spikes_While_Running(:,7)>(DRZ_Bins(DRZ_Bin)-0.1) & Bimodal_Spikes_While_Running(:,7)<=DRZ_Bins(DRZ_Bin));
        end
    end
    
    
    Filter=fspecial('gaussian',[10 5],2);
    Smoothed_Unimodal_Phase_DRZ_Histogram=filter2(Filter,[Unimodal_Phase_DRZ_Histogram;Unimodal_Phase_DRZ_Histogram]);
    Smoothed_Bimodal_Phase_DRZ_Histogram=filter2(Filter,[Bimodal_Phase_DRZ_Histogram;Bimodal_Phase_DRZ_Histogram]);
    Interpolated_Unimodal_Smoothed_Phase_DRZ_Histogram=interp2(permute(ones(20,72).*(-0.9:0.1:1)',[2,1]),ones(72,20).*(10:10:720)',Smoothed_Unimodal_Phase_DRZ_Histogram,permute(ones(200,720).*(-0.99:0.01:1)',[2,1]),ones(720,200).*(1:1:720)');
    Interpolated_Bimodal_Smoothed_Phase_DRZ_Histogram=interp2(permute(ones(20,72).*(-0.9:0.1:1)',[2,1]),ones(72,20).*(10:10:720)',Smoothed_Bimodal_Phase_DRZ_Histogram,permute(ones(200,720).*(-0.99:0.01:1)',[2,1]),ones(720,200).*(1:1:720)');
    figure;title('Unimodal');hold on;subplot(2,2,1);hold on;imagesc([Unimodal_Phase_DRZ_Histogram;Unimodal_Phase_DRZ_Histogram]);colormap('hot');
    subplot(2,2,2);hold on;imagesc(Smoothed_Unimodal_Phase_DRZ_Histogram);colormap('hot');
    subplot(2,2,3);hold on;imagesc(Interpolated_Unimodal_Smoothed_Phase_DRZ_Histogram);colormap('hot');
    subplot(2,2,4);hold on;contour(Interpolated_Unimodal_Smoothed_Phase_DRZ_Histogram,'k');
    figure;title('Bimodal');hold on;subplot(2,2,1);hold on;imagesc([Bimodal_Phase_DRZ_Histogram;Bimodal_Phase_DRZ_Histogram]);colormap('hot');
    subplot(2,2,2);hold on;imagesc(Smoothed_Bimodal_Phase_DRZ_Histogram);colormap('hot');
    subplot(2,2,3);hold on;imagesc(Interpolated_Bimodal_Smoothed_Phase_DRZ_Histogram);colormap('hot');
    subplot(2,2,4);hold on;contour(Interpolated_Bimodal_Smoothed_Phase_DRZ_Histogram,'k');

    
    
    
    
    
    
for Current_Cell=1:max(Spike_Data(:,2))
    Current_Cell=Current_Cell+1
    close all;
    Current_Spike_Data=Spike_Data(Spike_Data(:,2)==Current_Cell,:);
    Current_Spike_Information=Spike_Information(Spike_Data(:,2)==Current_Cell,:);
    Phase_Position_Histogram=zeros(36,100);
    Phase_Bins=10:10:360;
    Position_Bins=2:2:200;
    for Phase_Bin=1:36
        for Position_Bin=1:100
            Phase_Position_Histogram(Phase_Bin,Position_Bin)=sum(Current_Spike_Data(:,3)>(Phase_Bins(Phase_Bin)-10) & Current_Spike_Data(:,3)<=Phase_Bins(Phase_Bin) & Current_Spike_Information(:,1)>(Position_Bins(Position_Bin)-2) & Current_Spike_Information(:,1)<=Position_Bins(Position_Bin));
        end
    end
    Filter=fspecial('gaussian',[10 10],2);
    Smoothed_Phase_Position_Histogram=filter2(Filter,[Phase_Position_Histogram;Phase_Position_Histogram]);
    Interpolated_Smoothed_Phase_Position_Histogram=interp2(permute(ones(100,72).*(2:2:200)',[2,1]),ones(72,100).*(10:10:720)',Smoothed_Phase_Position_Histogram,permute(ones(200,720).*(1:1:200)',[2,1]),ones(720,200).*(1:1:720)');
    figure;hold on;subplot(2,2,1);hold on;plot([Current_Spike_Information(:,1);Current_Spike_Information(:,1)],[Current_Spike_Data(:,3);Current_Spike_Data(:,3)+360],'k.');
    subplot(2,2,2);hold on;imagesc([Phase_Position_Histogram;Phase_Position_Histogram]);colormap('hot');
    subplot(2,2,3);hold on;imagesc(Smoothed_Phase_Position_Histogram);colormap('hot');
    %subplot(2,2,3);hold on;imagesc(Interpolated_Smoothed_Phase_Position_Histogram);colormap('hot');
    subplot(2,2,4);hold on;contour(Interpolated_Smoothed_Phase_Position_Histogram,'k');
    
    Phase_DRZ_Histogram=zeros(36,20);
    Phase_Bins=10:10:360;
    DRZ_Bins=-0.9:0.1:1;
    for Phase_Bin=1:36
        for DRZ_Bin=1:20
            Phase_DRZ_Histogram(Phase_Bin,DRZ_Bin)=sum(Current_Spike_Data(:,3)>(Phase_Bins(Phase_Bin)-10) & Current_Spike_Data(:,3)<=Phase_Bins(Phase_Bin) & Current_Spike_Data(:,7)>(DRZ_Bins(DRZ_Bin)-0.1) & Current_Spike_Data(:,7)<=DRZ_Bins(DRZ_Bin));
        end
    end
    Filter=fspecial('gaussian',[10 5],2);
    Smoothed_Phase_DRZ_Histogram=filter2(Filter,[Phase_DRZ_Histogram;Phase_DRZ_Histogram]);
    Interpolated_Smoothed_Phase_DRZ_Histogram=interp2(permute(ones(20,72).*(-0.9:0.1:1)',[2,1]),ones(72,20).*(10:10:720)',Smoothed_Phase_DRZ_Histogram,permute(ones(200,720).*(-0.99:0.01:1)',[2,1]),ones(720,200).*(1:1:720)');
    figure;hold on;subplot(2,2,1);hold on;plot([Current_Spike_Data(:,7);Current_Spike_Data(:,7)],[Current_Spike_Data(:,3);Current_Spike_Data(:,3)+360],'k.');
    subplot(2,2,2);hold on;imagesc([Phase_DRZ_Histogram;Phase_DRZ_Histogram]);colormap('hot');
    subplot(2,2,3);hold on;imagesc(Smoothed_Phase_DRZ_Histogram);colormap('hot');
    %subplot(2,2,3);hold on;imagesc(Interpolated_Smoothed_Phase_DRZ_Histogram);colormap('hot');
    subplot(2,2,4);hold on;contour(Interpolated_Smoothed_Phase_DRZ_Histogram,'k');

end