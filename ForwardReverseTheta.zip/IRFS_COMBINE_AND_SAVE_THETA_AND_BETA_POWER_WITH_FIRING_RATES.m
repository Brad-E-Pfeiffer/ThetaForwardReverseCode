function IRFS_COMBINE_AND_SAVE_THETA_AND_BETA_POWER_WITH_FIRING_RATES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads up the previously processed and saved unimodal and
% bimodal data for each individual session, combines it, and saves it.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Theta_And_Beta_Power_Correlated_To_Firing_Rate_Index
        eval(sprintf('%s_%s_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];',Rat_Name,Directory_Name));
        if exist('All_Theta_Power_Vs_Major_Peak_FRI','var')
            All_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        else
            All_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Unimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Unimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Unimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Unimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Bimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Bimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Bimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Bimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        end
        if strcmp(Directory_Name(1),'L') && exist('All_Linear_Theta_Power_Vs_Major_Peak_FRI','var')
            All_Linear_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        elseif strcmp(Directory_Name(1),'L')
            All_Linear_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        end
        if strcmp(Directory_Name(1),'O') && exist('All_OpenField_Theta_Power_Vs_Major_Peak_FRI','var')
            All_OpenField_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Theta_ZScore_Power_By_Theta_Rank),:)=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end+1:end+length(Beta_ZScore_Power_By_Beta_Rank),:)=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        elseif strcmp(Directory_Name(1),'O')
            All_OpenField_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(:,1)];
            All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI=[Theta_ZScore_Power_By_Theta_Rank,Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(:,1)];
            All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI=[Beta_ZScore_Power_By_Beta_Rank,Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(:,1)];
        end
        cd ..
        clearvars -except All_* Janni_* Harpy_* Imp_* Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name
    end
    clear Directory
    cd ..
end

clear Rat;
clear Rat_Name;
clear Experiment;

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

save('Combined_Theta_And_Beta_Power_Vs_Firing_Rates','All_*','Janni_*','Harpy_*','Imp_*','-v7.3');

cd ..

end
