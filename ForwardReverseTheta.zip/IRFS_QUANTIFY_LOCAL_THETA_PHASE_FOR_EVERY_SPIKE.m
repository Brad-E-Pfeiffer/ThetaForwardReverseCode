function Spike_Data_With_Local_Theta_Phase=IRFS_QUANTIFY_LOCAL_THETA_PHASE_FOR_EVERY_SPIKE(Raw_LFP_Root_Directory,Spike_Data,Tetrode_Cell_IDs,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the theta phase of each spike in the recording.
% It loads and processes the theta oscillation for every tetrode
% on which spikes were recorded and quantifies the phase for each spike
% based on the local theta. 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if exist('Spike_Data_With_Local_Theta_Phase.mat','file')==2
    Spike_Data_With_Local_Theta_Phase=load('Spike_Data_With_Local_Theta_Phase','Spike_Data');
    Spike_Data_With_Local_Theta_Phase=Spike_Data_With_Local_Theta_Phase.Spike_Data;
else
    Spike_Data(:,3:6)=0;
    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-06_LinearTrack_NoReplay\\2010-04-06_13-35-33'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-11_LinearTrack_OneReplay\\2010-04-11_12-45-01'';',Raw_LFP_Root_Directory));
        elseif Experiment==5
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Raw_LFP_Root_Directory));
        elseif Experiment==6
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Raw_LFP_Root_Directory));
        elseif Experiment==7
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-07_OpenField(Day_ZeroTwo)\\2010-04-07_11-03-59'';',Raw_LFP_Root_Directory));
        elseif Experiment==8
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-07_OpenField(DayOne)\\2010-04-07_18-30-08'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-08 One_Run_Trial\\2010-01-08_12-33-36'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-10 First_Open_Field\\2010-01-10_15-48-05'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-12 Second_Open_Field\\2010-01-12_15-20-49'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-22 Linear_Track_Reward_Big_Reward_Separate\\2010-02-22_17-29-17'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-27 Linear_Track_Reward_Big_Reward_Same\\2010-02-27_16-12-54'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-17 First Open Field Experiment\\2010-02-17_17-23-35'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Imp\\2010-02-18 Second Open Field Experiment\\2010-02-18_17-03-47'';',Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    Directory_List=dir;
    for N=1:size(Directory_List,1)
        for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if you have more channels, increase this number accordingly
            Comparison_String=sprintf('CSC%d.ncs',M);
            if strcmp(Directory_List(N).name,Comparison_String)
                if exist('LFP_Electrodes','var')
                    LFP_Electrodes=[LFP_Electrodes,M];
                else
                    LFP_Electrodes=M;
                end
            end
            clear Comparison_String;
        end
    end
    if ~exist('LFP_Electrodes','var')
        error('ERROR! No CSC files were identified in the listed load directory.')
    end
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);
    clear M;
    clear N;
    clear Directory_List;
    clear LFP_Electrodes;
    clear LFP_Filename;
    Theta_Stop_Low=5;
    Theta_Pass_Low=6;                % Some papers use as low as 4 Hz as the low cutoff
    Theta_Pass_High=12;              % Some papers use as high as 12 Hz as the high cutoff
    Theta_Stop_High=14;
    Stop_Band_Attenuation_One=60;    % This was the default, I think.
    Pass_Band=1;                     % This was the default, I think.
    Stop_Band_Attenuation_Two=80;    % This was the default, I think.
    Filter_Design_For_Theta=fdesign.bandpass(Theta_Stop_Low, Theta_Pass_Low, Theta_Pass_High, Theta_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Theta_Filter=design(Filter_Design_For_Theta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    for Current_Tetrode=min(Tetrode_Cell_IDs(:,1)):max(Tetrode_Cell_IDs(:,1))
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2);
        if ~isempty(Cells_On_This_Tetrode)
            for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4)
                Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
                if exist(Electrode_Name,'file')==2
                    LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                    for Header_Line=1:length(LFP_Header)
                        Header_Info=cell2mat(LFP_Header(Header_Line));
                        if length(Header_Info)>12
                            if strcmp(Header_Info(1:11),'-ADMaxValue')
                                Max_Value=str2num(Header_Info(13:end));
                            end
                            if strcmp(Header_Info(1:11),'-InputRange')
                                Max_Range=str2num(Header_Info(13:end));
                            end
                        end
                    end
                    LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                    Times=zeros(512,size(LFP_Times,2));
                    for B=1:length(LFP_Times)-1
                        Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                    end
                    Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                    clear B;
                    clear LFP_Times;
                    Times=Times(:);
                    LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                    LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);
                    LFP_Data=[Times,LFP_Samples];
                    LFP_Data=LFP_Data(LFP_Data(:,1)>=(min(Spike_Data(:,1))-100) & LFP_Data(:,1)<=(max(Spike_Data(:,1))+100),:);
                    clear Times;
                    clear LFP_Samples;
                    clear Max_Range;
                    clear Max_Value;
                    Theta_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                    Theta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,LFP_Data(:,2));
                    clear LFP_Data;
                    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,Theta_Filtered_LFP_Data(:,2));
                    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);
                    Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
                    Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi)+180;
                    %This gets rid of large gaps of no spikes (such as when there are several linear track experiments separated by sleep sessions) to speed up the program
                    Theta_Filtered_LFP_Data=Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,1)>=min(Spike_Data(:,1)) & Theta_Filtered_LFP_Data(:,1)<=max(Spike_Data(:,1)),:);
                    Time_Gaps=diff(Spike_Data(:,1));
                    Time_Gap_Index=find(Time_Gaps>5);
                    if ~isempty(Time_Gap_Index)
                        for Current_Gap=1:length(Time_Gap_Index)
                            Theta_Filtered_LFP_Data=[Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,1)<=Spike_Data(Time_Gap_Index(Current_Gap),1),:);Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,1)>=Spike_Data((Time_Gap_Index(Current_Gap)+1),1),:)];
                        end
                    end
                    
                    %This finds the cycle duration and whether or not each cycle is monotonously increasing
                    Theta_Filtered_LFP_Data(:,5:6)=0;
                    Phase_Difference=diff(Theta_Filtered_LFP_Data(:,4));
                    Troughs=find(Phase_Difference<-345);
                    Troughs=Troughs+1;
                    Monotonic_Increasing=zeros(length(Troughs),1);
                    for N=1:(length(Troughs)-1)
                        if all(diff(Theta_Filtered_LFP_Data(Troughs(N):(Troughs(N+1)-1),4))>0)
                            Monotonic_Increasing(N,1)=1;
                        end
                    end
                    clear N;
                    Cycle_Durations=zeros(length(Troughs),1);
                    for N=1:(length(Troughs)-1)
                        Cycle_Durations(N,1)=Theta_Filtered_LFP_Data((Troughs(N+1)-1),1)-Theta_Filtered_LFP_Data(Troughs(N),1);
                    end
                    clear N;
                    for N=1:(length(Troughs)-1)
                        Theta_Filtered_LFP_Data(Troughs(N):(Troughs(N+1)-1),5:6)=ones(length(Theta_Filtered_LFP_Data(Troughs(N):(Troughs(N+1)-1),1)),2).*[Cycle_Durations(N),Monotonic_Increasing(N)];
                    end
                    clear N;
                    clear Monotonic_Increasing;
                    clear Cycle_Durations;
                    clear Troughs;
                    clear Phase_Difference;
                    
                    %This finds the phase for each spike recorded on this tetrode
                    for Cell=1:length(Cells_On_This_Tetrode)
                        Current_Cell=Cells_On_This_Tetrode(Cell);
                        Spike_Index=find(Spike_Data(:,2)==Current_Cell);
                        Additional_Information=zeros(length(Spike_Index),4);
                        parfor N=1:length(Spike_Index)
                            Spike_Data_Addition=Theta_Filtered_LFP_Data(abs(Theta_Filtered_LFP_Data(:,1)-Spike_Data(Spike_Index(N),1))==min(abs(Theta_Filtered_LFP_Data(:,1)-Spike_Data(Spike_Index(N),1))),[4,5,6,1]);
                            if size(Spike_Data_Addition,1)>1
                                Additional_Information(N,:)=Theta_Filtered_LFP_Data(find(abs(Theta_Filtered_LFP_Data(:,1)-Spike_Data(Spike_Index(N),1))==min(abs(Theta_Filtered_LFP_Data(:,1)-Spike_Data(Spike_Index(N),1))),1,'first'),[4,5,6,1]);
                            else
                                Additional_Information(N,:)=Spike_Data_Addition;
                            end
                        end
                        Spike_Data(Spike_Index,3:6)=Additional_Information;
                        clear Additional_Information;
                        clear Spike_Data_Addition;
                        clear N;
                        clear Spike_Index;
                    end
                    clear Cell;
                end
            end
        end
        disp(sprintf('Finished quantifying local theta for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    cd(Current_Working_Directory);
    clear Raw_LFP_Directory;
    clear Current_Directory;
    save('Spike_Data_With_Local_Theta_Phase','Spike_Data');
    Spike_Data_With_Local_Theta_Phase=Spike_Data;
end

end

