% This plots the phase-locked firing plots for each neuron, comparisons of
% place field properties, distribution of unimodal vs. bimodal neurons, and
% other related plots.

if Plot_Data
    disp('Plotting Data.');
    if exist('_Figures','dir')==7
        cd _Figures
    else
        mkdir('_Figures')
        cd _Figures
    end
    if exist('Phase_Locked_Firing_Plots_With_Global_Theta','dir')==7
        cd Phase_Locked_Firing_Plots_With_Global_Theta
    else
        mkdir Phase_Locked_Firing_Plots_With_Global_Theta
        cd Phase_Locked_Firing_Plots_With_Global_Theta
    end
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(1,:,1),Mean_Firing_Rate_Per_Phase_All(1,:,1)],[Mean_Firing_Rate_Per_Phase_All(1,:,2),Mean_Firing_Rate_Per_Phase_All(1,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(2,:,1),Mean_Firing_Rate_Per_Phase_All(2,:,1)],[Mean_Firing_Rate_Per_Phase_All(2,:,2),Mean_Firing_Rate_Per_Phase_All(2,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(3,:,1),Mean_Firing_Rate_Per_Phase_All(3,:,1)],[Mean_Firing_Rate_Per_Phase_All(3,:,2),Mean_Firing_Rate_Per_Phase_All(3,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_All_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    clear Y_Lim;
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(1,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(1,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(1,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(1,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(2,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(2,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(2,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(2,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(3,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(3,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(3,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(3,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Unimodal_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    clear Y_Lim;
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(1,:,1),Mean_Firing_Rate_Per_Phase_All(1,:,1)],[Mean_Firing_Rate_Per_Phase_All(1,:,2),Mean_Firing_Rate_Per_Phase_All(1,:,2)],'k')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(1,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(1,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(1,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(1,:,2)],'r')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(1,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(1,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(1,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(1,:,2)],'b')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Raw_Firing_Rate_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Raw_Firing_Rate_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(2,:,1),Mean_Firing_Rate_Per_Phase_All(2,:,1)],[Mean_Firing_Rate_Per_Phase_All(2,:,2),Mean_Firing_Rate_Per_Phase_All(2,:,2)],'k')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(2,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(2,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(2,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(2,:,2)],'r')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(2,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(2,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(2,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(2,:,2)],'b')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Smoothed_Firing_Rate_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Smoothed_Firing_Rate_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2),[Mean_Firing_Rate_Per_Phase_All(3,:,1),Mean_Firing_Rate_Per_Phase_All(3,:,1)],[Mean_Firing_Rate_Per_Phase_All(3,:,2),Mean_Firing_Rate_Per_Phase_All(3,:,2)],'k')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Unimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Unimodal(3,:,1),Mean_Firing_Rate_Per_Phase_Unimodal(3,:,1)],[Mean_Firing_Rate_Per_Phase_Unimodal(3,:,2),Mean_Firing_Rate_Per_Phase_Unimodal(3,:,2)],'r')
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(3,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(3,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(3,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(3,:,2)],'b')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_All,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Firing_Rate_Index_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Firing_Rate_Index_Per_Phase_w_SEM_(Black=All;Red=Unimodal;Blue=Bimodal)(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    clear Y_Lim;
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(1,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(1,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(1,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(1,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(2,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(2,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(2,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(2,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2),[Mean_Firing_Rate_Per_Phase_Bimodal(3,:,1),Mean_Firing_Rate_Per_Phase_Bimodal(3,:,1)],[Mean_Firing_Rate_Per_Phase_Bimodal(3,:,2),Mean_Firing_Rate_Per_Phase_Bimodal(3,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Bimodal,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==1))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Excitatory_Bimodal_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==1))));
    close;
    clear Y_Lim;
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2),[Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,1),Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,1)],[Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,2),Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==0))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Raw_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==0))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2),[Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,1),Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,1)],[Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,2),Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==0))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Smoothed_Firing_Rate_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==0))));
    close;
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    errorbar(Phase_Bin:Phase_Bin:Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2),[Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,1),Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,1)],[Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,2),Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,2)],'k')
    set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*(size(Mean_Firing_Rate_Per_Phase_Inhibitory,2)*2)+(Phase_Bin/2)]);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=0to%d)(N=%d).jpg'');',Y_Lim(2),length(find(Neuron_List==0))));
    set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
    eval(sprintf('print(''-djpeg'',''Mean_Inhibitory_All_Firing_Rate_Index_Per_Phase_w_SEM_(X=0to720)(Y=%dto%d)(N=%d).jpg'');',Y_Lim(1),Y_Lim(2),length(find(Neuron_List==0))));
    close;
    clear Y_Lim;
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    Unimodal_Cell_Count=length(find(Modality(:,1)==1 & Neuron_List==1));
    Bimodal_Cell_Count=length(find(Modality(:,1)==2 & Neuron_List==1));
    Multimodal_Cell_Count=length(find(Modality(:,1)==3 & Neuron_List==1));
    Low_Spike_Cell_Count=length(find(Modality(:,1)==0 & Neuron_List==1));
    %Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count,Low_Spike_Cell_Count]);  
    Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
    set(Pie_Chart(1),'FaceColor','r')
    set(Pie_Chart(3),'FaceColor','b')
    if Multimodal_Cell_Count>0
        set(Pie_Chart(5),'FaceColor','w')
    end
    %set(Pie_Chart(7),'FaceColor',[0.6 0.6 0.6])
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    %eval(sprintf('print(''-djpeg'',''Pie_Chart_Of_Cell_Modality_Numbers_(Unimodal=%d;Bimodal=%d,Multimodal=%d,LowCount=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count,Low_Spike_Cell_Count));
    eval(sprintf('print(''-djpeg'',''Pie_Chart_Of_Cell_Modality_Numbers_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
    close
    clear Unimodal_Cell_Count;
    clear Bimodal_Cell_Count;
    clear Multimodal_Cell_Count;
    clear Low_Spike_Cell_Count;
    clear Pie_Chart;
    
    if Plot_Individual_Cell_Histograms
        if exist('Unimodal','dir')==7
        else
            mkdir('Unimodal');
        end
        if exist('Bimodal','dir')==7
        else
            mkdir('Bimodal');
        end
        if exist('Multimodal','dir')==7
        else
            mkdir('Multimodal');
        end
        if exist('Other','dir')==7
        else
            mkdir('Other');
        end
        for N=1:size(Firing_Rate_Per_Phase,1)
            if Modality(N,1)~=0  % Don't plot neurons without enough spikes for quantification
                if Modality(N,1)==1
                    cd Unimodal
                elseif Modality(N,1)==2
                    cd Bimodal
                elseif Modality(N,1)==3
                    cd Multimodal
                else
                    cd Other
                end
                figure;
                hold on;
                subplot('Position',[0 0 1 1]);
                hold on;
                Data=[Firing_Rate_Per_Phase(N,:,1),Firing_Rate_Per_Phase(N,:,1)];
                bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
                Line=[Firing_Rate_Per_Phase(N,:,2),Firing_Rate_Per_Phase(N,:,2)];
                plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
                set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
                Y_Lim=ylim;
                set(gca,'YLim',[0 Y_Lim(2)]);
                set(gca,'XTick',[]);
                set(gca,'YTick',[]);
                eval(sprintf('print(''-djpeg'',''Firing_Rate_Per_Phase_Neuron_%d_(X=0to720)(Y=0to%d).jpg'');',N,Y_Lim(2)));
                close;
                clear Data;
                clear Line;
                clear Y_Lim;
                figure;
                hold on;
                subplot('Position',[0 0 1 1]);
                hold on;
                Data=[Firing_Rate_Per_Phase(N,:,3),Firing_Rate_Per_Phase(N,:,3)];
                bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
                Line=[Firing_Rate_Per_Phase(N,:,3),Firing_Rate_Per_Phase(N,:,3)];
                plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
                set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
                Y_Lim=ylim;
                set(gca,'YLim',[0 Y_Lim(2)]);
                set(gca,'XTick',[]);
                set(gca,'YTick',[]);
                eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Per_Phase_Neuron_%d_(X=0to720)(Y=0to%d).jpg'');',N,Y_Lim(2)));
                close;
                clear Data;
                clear Line;
                clear Y_Lim;
                figure;
                hold on;
                subplot('Position',[0 0 1 1]);
                hold on;
                Data=[Firing_Rate_Per_Phase(N,:,4),Firing_Rate_Per_Phase(N,:,4)];
                bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
                Line=[Firing_Rate_Per_Phase(N,:,5),Firing_Rate_Per_Phase(N,:,5)];
                plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
                set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
                Y_Lim=ylim;
                set(gca,'YLim',[0 Y_Lim(2)]);
                set(gca,'XTick',[]);
                set(gca,'YTick',[]);
                eval(sprintf('print(''-djpeg'',''Spikes_Per_Phase_Neuron_%d_(X=0to720)(Y=0to%d).jpg'');',N,Y_Lim(2)));
                close;
                clear Data;
                clear Line;
                clear Y_Lim;
                cd ..
            end
        end
    end
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,1),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,1),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,1)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,1),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_Place_Field_Size_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,2),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,2),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,2)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,2),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_Number_Of_Place_Fields_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,3),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,3),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,3)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,3),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_Peak_Firing_Rate_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,4),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,4),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,4)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,4),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_Mean_Firing_Rate_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,5),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,5),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,5)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,5),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_Information_Per_Spike_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    [V1,~,V1_Mean,V1_Median]=violin([Unimodal_Place_Field_Properties(:,6),-1000*ones(size(Unimodal_Place_Field_Properties,1),1)],'x',[1 2],'edgecolor',[],'facecolor','r','mc',[],'medc',[]);
    plot((rand(size(Unimodal_Place_Field_Properties,1),1)/4)+0.875,Unimodal_Place_Field_Properties(:,6),'.k')
    [V2,~,V2_Mean,V2_Median]=violin([-1000*ones(size(Bimodal_Place_Field_Properties,1),1),Bimodal_Place_Field_Properties(:,6)],'x',[1 2],'edgecolor',[],'facecolor','b','mc',[],'medc',[]);
    plot((rand(size(Bimodal_Place_Field_Properties,1),1)/4)+1.875,Bimodal_Place_Field_Properties(:,6),'.k')
    plot([0.75 1.25],[V1_Mean(1) V1_Mean(1)],'k','LineWidth',3)
    plot([1.75 2.25],[V2_Mean(2) V2_Mean(2)],'k','LineWidth',3)
    plot([0.75 1.25],[V1_Median(1) V1_Median(1)],'k--','LineWidth',3)
    plot([1.75 2.25],[V2_Median(2) V2_Median(2)],'k--','LineWidth',3)
    Y_Min=min([min(V1(1).Vertices(:,2)),min(V2(2).Vertices(:,2))]);
    Y_Max=max([max(V1(1).Vertices(:,2)),max(V2(2).Vertices(:,2))]);
    set(gca,'YLim',[Y_Min Y_Max]);
    set(gca,'XLim',[0.5 2.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Unimodal_Vs_Bimodal_L_Ratio_(Y=%dto%d).jpg'');',Y_Min,Y_Max));
    clear V1;
    clear V2;
    clear V1_Mean;
    clear V2_Mean;
    clear V1_Median;
    clear V2_Median;
    clear Y_Min;
    clear Y_Max;
    close
    
    cd ..
    cd ..
    clear N;
end
