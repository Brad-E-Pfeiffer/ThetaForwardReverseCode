function IRFS_PLOT_FIGURE_ONE_B(Initial_Variables)

load Bimodal_Analysis_Windows
Phase_Bin=Initial_Variables.Phase_Bin;
Position_Bin=Initial_Variables.Bin_Size;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load('Average_Theta_Sequence_And_Posterior_Dists','Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds')
        Midpoint=ceil(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2);
        
        if strcmp(Directory_Name(1),'O')
            if exist('Open_Field_Dist_Of_Peak_Post','var')==1
                Open_Field_Dist_Of_Peak_Post=Open_Field_Dist_Of_Peak_Post+[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3)];
            else
                Open_Field_Dist_Of_Peak_Post=[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3)];
            end
        else
            if exist('Linear_Track_Dist_Of_Peak_Post','var')==1
                Linear_Track_Dist_Of_Peak_Post=Linear_Track_Dist_Of_Peak_Post+[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3)];
            else
                Linear_Track_Dist_Of_Peak_Post=[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,3)];
            end
        end
        cd ..
    end
    clear Directory
    cd ..
end
Open_Field_Dist_Of_Peak_Post=Open_Field_Dist_Of_Peak_Post/6; %Divide by 6 sessions to make it a mean rather than a sum
Linear_Track_Dist_Of_Peak_Post=Linear_Track_Dist_Of_Peak_Post/10; %Divide by 10 sessions to make it a mean rather than a sum
clear Rat
clear Experiment
clear Rats
cd AllRatsCombined
cd _Figures_For_Paper
cd Figure1

Open_Field_Max_Prob=filtfilt(fspecial('gaussian',[7,1],1),1,max(Open_Field_Dist_Of_Peak_Post));
Open_Field_Max_Prob=Open_Field_Max_Prob([round(360/Phase_Bin):round(540/Phase_Bin),round(190/Phase_Bin):round(350/Phase_Bin)]);
Open_Field_Max_Prob=[Open_Field_Max_Prob,Open_Field_Max_Prob];
Linear_Track_Max_Prob=filtfilt(fspecial('gaussian',[7,1],1),1,max(Linear_Track_Dist_Of_Peak_Post));
Linear_Track_Max_Prob=Linear_Track_Max_Prob([round(360/Phase_Bin):round(540/Phase_Bin),round(190/Phase_Bin):round(350/Phase_Bin)]);
Linear_Track_Max_Prob=[Linear_Track_Max_Prob,Linear_Track_Max_Prob];

Open_Field_Forward_Window=Open_Field_Dist_Of_Peak_Post(:,(round(Forward_Window(1)/Phase_Bin)):(round(Forward_Window(2)/Phase_Bin)+round(360/Phase_Bin)));
Open_Field_Reverse_Window=Open_Field_Dist_Of_Peak_Post(:,(round(Reverse_Window(1)/Phase_Bin)):(round(Reverse_Window(2)/Phase_Bin)));
Linear_Track_Forward_Window=Linear_Track_Dist_Of_Peak_Post(:,(round(Forward_Window(1)/Phase_Bin)):(round(Forward_Window(2)/Phase_Bin)+round(360/Phase_Bin)));
Linear_Track_Reverse_Window=Linear_Track_Dist_Of_Peak_Post(:,(round(Reverse_Window(1)/Phase_Bin)):(round(Reverse_Window(2)/Phase_Bin)));

%This calculates the best-fit line based on the maximum value in each phase
%bin and uses least-squares to find the best fit line.

Y_Locations=(1:61);
Forward_X_Locations=round(Forward_Window(1)/Phase_Bin):round((360+Forward_Window(2))/Phase_Bin);
[~,Y_Max]=max(Open_Field_Forward_Window);
Y1=Y_Locations(Y_Max);
P1=polyfit(Forward_X_Locations,Y1,1);
Open_Field_Forward_Best_Fit_Line=polyval(P1,Forward_X_Locations);

Reverse_X_Locations=round(Reverse_Window(1)/Phase_Bin):round((Reverse_Window(2))/Phase_Bin);
[~,Y_Max]=max(Open_Field_Reverse_Window);
Y1=Y_Locations(Y_Max);
P1=polyfit(Reverse_X_Locations,Y1,1);
Open_Field_Reverse_Best_Fit_Line=polyval(P1,Reverse_X_Locations);

[~,Y_Max]=max(Linear_Track_Forward_Window);
Y1=Y_Locations(Y_Max);
P1=polyfit(Forward_X_Locations,Y1,1);
Linear_Track_Forward_Best_Fit_Line=polyval(P1,Forward_X_Locations);

[~,Y_Max]=max(Linear_Track_Reverse_Window);
Y1=Y_Locations(Y_Max);
P1=polyfit(Reverse_X_Locations,Y1,1);
Linear_Track_Reverse_Best_Fit_Line=polyval(P1,Reverse_X_Locations);


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Open_Field_Dist_Of_Peak_Post,[0 max(max(Open_Field_Dist_Of_Peak_Post))]);
colormap('hot');
set(gca,'YDir','normal');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[1 size(Open_Field_Dist_Of_Peak_Post,2)]);
set(gca,'YLim',[1 size(Open_Field_Dist_Of_Peak_Post,1)]);
eval(sprintf('print(''-djpeg'',''Figure_1B_Open_Field_Normalized_Histogram(Map=0to%d).jpg'');',max(max(Open_Field_Dist_Of_Peak_Post))));
plot(Forward_X_Locations,Open_Field_Forward_Best_Fit_Line,'c--','LineWidth',3);
plot(Reverse_X_Locations,Open_Field_Reverse_Best_Fit_Line,'c--','LineWidth',3);
plot([(Forward_Window(1)-Phase_Bin)/Phase_Bin,(Forward_Window(1)-Phase_Bin)/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Reverse_Window(1)-Phase_Bin)/Phase_Bin,(Reverse_Window(1)-Phase_Bin)/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Forward_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin,(Forward_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Reverse_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin,(Reverse_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin],[1 60],'w--','LineWidth',2)
set(gca,'XLim',[1 size(Open_Field_Dist_Of_Peak_Post,2)]);
set(gca,'YLim',[1 size(Open_Field_Dist_Of_Peak_Post,1)]);
eval(sprintf('print(''-djpeg'',''Figure_1B_Open_Field_Normalized_Histogram_With_Lines(Map=0to%d).jpg'');',max(max(Open_Field_Dist_Of_Peak_Post))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Linear_Track_Dist_Of_Peak_Post,[0 max(max(Linear_Track_Dist_Of_Peak_Post))]);
colormap('hot');
set(gca,'YDir','normal');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[1 size(Linear_Track_Dist_Of_Peak_Post,2)]);
set(gca,'YLim',[1 size(Linear_Track_Dist_Of_Peak_Post,1)]);
eval(sprintf('print(''-djpeg'',''Figure_1B_Linear_Track_Normalized_Histogram(Map=0to%d).jpg'');',max(max(Linear_Track_Dist_Of_Peak_Post))));
plot(Forward_X_Locations,Linear_Track_Forward_Best_Fit_Line,'c--','LineWidth',3);
plot(Reverse_X_Locations,Linear_Track_Reverse_Best_Fit_Line,'c--','LineWidth',3);
plot([(Forward_Window(1)-Phase_Bin)/Phase_Bin,(Forward_Window(1)-Phase_Bin)/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Reverse_Window(1)-Phase_Bin)/Phase_Bin,(Reverse_Window(1)-Phase_Bin)/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Forward_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin,(Forward_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin],[1 60],'w--','LineWidth',2)
plot([(Reverse_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin,(Reverse_Window(1)-Phase_Bin)/Phase_Bin+360/Phase_Bin],[1 60],'w--','LineWidth',2)
set(gca,'XLim',[1 size(Linear_Track_Dist_Of_Peak_Post,2)]);
set(gca,'YLim',[1 size(Linear_Track_Dist_Of_Peak_Post,1)]);
eval(sprintf('print(''-djpeg'',''Figure_1B_Linear_Track_Normalized_Histogram_With_Lines(Map=0to%d).jpg'');',max(max(Linear_Track_Dist_Of_Peak_Post))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot((Phase_Bin:Phase_Bin:720)-(Phase_Bin/2),Open_Field_Max_Prob,'ko-','LineWidth',5,'MarkerSize',10,'MarkerFaceColor','k')
set(gca,'XLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Figure_1B_Open_Field_Smoothed_Maximum_Probability_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot((Phase_Bin:Phase_Bin:720)-(Phase_Bin/2),Linear_Track_Max_Prob,'ko-','LineWidth',5,'MarkerSize',10,'MarkerFaceColor','k')
set(gca,'XLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Figure_1B_Linear_Track_Smoothed_Maximum_Probability_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

cd ..
cd ..
cd ..

end
