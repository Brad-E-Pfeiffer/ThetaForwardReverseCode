% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script calculates the place field properties of unimodal and bimodal
% cells, including mean firing rate, peak firing rate, place field size,
% number of place fields, and L-ratio.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Unimodal/Bimodal_Place_Field_Properties
% |              1               |              2         |        3         |         4        |              5              |     6   |            7              ||
% | Mean Place Field Size (bins) | Number Of Place Fields | Peak Firing Rate | Mean Firing Rate | Informaton Per Spike (bits) | L-Ratio | Mean In-Field Firing Rate ||

if exist('Place_Field_Properties.mat','file')==2
    load Place_Field_Properties.mat
else
    Total_Duration=sum(Position_Data(Position_Data(:,5)>=Place_Field_Velocity_Cutoff,7));
    Time_In_Position=zeros(size(Field_Data,1),size(Field_Data,2));
    for N=1:size(Position_Data,1)
        if Position_Data(N,5)>=Place_Field_Velocity_Cutoff
            Time_In_Position(ceil(Position_Data(N,3)/Bin_Size),ceil(Position_Data(N,2)/Bin_Size))=Time_In_Position(ceil(Position_Data(N,3)/Bin_Size),ceil(Position_Data(N,2)/Bin_Size))+Position_Data(N,7);
        end
    end
    clear N;
    Normalized_Time_In_Position=Time_In_Position/sum(sum(Time_In_Position));
    for N=1:length(Excitatory_Neurons)
        Place_Field=Field_Data(:,:,Excitatory_Neurons(N));
        if max(max(Place_Field))>0
            L_Ratio=L_Ratios(Excitatory_Neurons(N),1);
            Peak_Firing_Rate=max(max(Place_Field));
            Mean_Firing_Rate=length(find(Spike_Data(:,2)==Excitatory_Neurons(N) & Spike_Information(:,4)>=Place_Field_Velocity_Cutoff))/Total_Duration;
            Information_Field=Normalized_Time_In_Position.*(Place_Field/Mean_Firing_Rate).*log2((Place_Field/Mean_Firing_Rate));
            Information_Field=Information_Field(Normalized_Time_In_Position>0); %Limit analysis only to parts of the track where the rat explored
            Information_Field(isnan(Information_Field))=0;
            Information_Per_Spike=sum(sum(Information_Field));
            Number_Of_Fields=0;
            Contiguous_Place_Fields=zeros(size(Place_Field,1),size(Place_Field,2));
            Place_Field=double(Place_Field>=Peak_Firing_Rate*Minimum_Place_Field_Firing_Rate_Fraction);
            Place_Field_Sizes=0;
            [Y_Index,X_Index]=find(Place_Field==1);
            for M=1:length(Y_Index)
                if Contiguous_Place_Fields(Y_Index(M),X_Index(M))==0 && Place_Field(Y_Index(M),X_Index(M))==1
                    This_Place_Field=grayconnected(Place_Field,Y_Index(M),X_Index(M),0);
                    if sum(sum(This_Place_Field))>=Minimum_Contiguous_Place_Field_Bins
                        Number_Of_Fields=Number_Of_Fields+1;
                        Contiguous_Place_Fields(This_Place_Field)=Number_Of_Fields;
                        Place_Field_Sizes=[Place_Field_Sizes;sum(sum(This_Place_Field))];
                    end
                end
                clear This_Place_Field;
            end
            [Y,X]=find(Contiguous_Place_Fields>0);
            Mean_InField_Firing_Rate=mean(mean(Field_Data(Y,X,Excitatory_Neurons(N))));
            clear M;
            clear X;
            clear Y;
            clear X_Index;
            clear Y_Index;
            if length(Place_Field_Sizes>1)
                Place_Field_Sizes=Place_Field_Sizes(2:end);
            end
            %Might still need to quantify place fields for place field size and place field number
            if Modality(Excitatory_Neurons(N),1)==1
                if exist('Unimodal_Place_Field_Properties','var')==1
                    Unimodal_Place_Field_Properties=[Unimodal_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate]];
                else
                    Unimodal_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate];
                end
            elseif Modality(Excitatory_Neurons(N),1)==2
                if exist('Bimodal_Place_Field_Properties','var')==1
                    Bimodal_Place_Field_Properties=[Bimodal_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate]];
                else
                    Bimodal_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate];
                end
            end
            clear L_Ratio
            clear Peak_Firing_Rate;
            clear Mean_Firing_Rate;
            clear Mean_InField_Firing_Rate;
            clear Information_Per_Spike;
            clear Information_Field;
            clear Place_Field_Size;
            clear Number_Of_Fields;
            clear Contiguous_Place_Fields;
            clear Place_Field_Sizes;
        end
        clear Place_Field;
    end
    clear Total_Duration;
    clear Time_In_Position;
    clear Normalized_Time_In_Position;
    clear N;
    save('Place_Field_Properties','Unimodal_Place_Field_Properties','Bimodal_Place_Field_Properties');
end


