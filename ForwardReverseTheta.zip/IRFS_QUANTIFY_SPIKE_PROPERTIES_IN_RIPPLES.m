% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This script finds all the spikes (bimodal and unimodal, spikes in
% prior/future forward/reverse window, etc., for each ripple.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%Ripple_Spike_Properties (each page is a ripple)
%|     1   |            2             |                   3            |                4               |              5             |             6              |                 7               |                 8               |               9             |              10             |       11           |           12        |                 13                    |                 14             |               15               |               16             |              17              |             18          ||
%| Cell ID | Spikes In Current Ripple | Spikes In Prior Reverse Window | Spikes In Prior Forward Window | Spikes In Prior Minor Peak | Spikes In Prior Major Peak | Spikes In Future Reverse Window | Spikes In Future Forward Window | Spikes In Future Minor Peak | Spikes In Future Major Peak | Total Prior Spikes | Total Future Spikes | Total Spikes Across Entire Experiment | Total Spikes In Reverse Window | Total Spikes In Forward Window | Total Spikes In Minor Window | Total Spikes In Major Window | Total Spikes In Ripples ||

if 0%exist('Ripple_Spike_Properties.mat','file')==2
    load Ripple_Spike_Properties;
else
    Time_To_Look_Behind=10; %10 seconds back
    Time_To_Look_Ahead=10; %10 seconds ahead
    load Spike_Data;
    All_Spike_Data=Spike_Data;
    load Spike_Data_With_Theta_Phase;
    load Position_Data;
    Velocity=IRFS_CALCULATE_VELOCITY(Position_Data);
    Matched_Spike_Velocity=zeros(size(Spike_Data,1),1);
    parfor N=1:size(Spike_Data,1)
        Index=abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1)));
        if sum(Index)>1
            Index=find(abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1))),1,'first');
        end
        Matched_Spike_Velocity(N,1)=Velocity(Index,1);
    end
    clear Index;
    clear Velocity;
    
    Ripple_Spike_Properties=zeros(max(All_Spike_Data(:,2)),18,size(Ripple_Events,1));
    
    %This calculates overall spike counts for each cell and overall spike counts in Forward/Reverse and Major/Minor Windows 
    Cell_Spike_Counts=zeros(max(All_Spike_Data(:,2)),5);
    for Current_Cell=1:max(All_Spike_Data(:,2))
        Cell_Spike_Counts(Current_Cell,1)=length(find(Spike_Data(:,2)==Current_Cell));
        Cell_Spike_Counts(Current_Cell,2)=length(find(Spike_Data(:,2)==Current_Cell & (Spike_Data(:,3)>=Reverse_Window(1) & Spike_Data(:,3)<=Reverse_Window(2))));
        Cell_Spike_Counts(Current_Cell,3)=length(find(Spike_Data(:,2)==Current_Cell & (Spike_Data(:,3)>=Forward_Window(1) | Spike_Data(:,3)<=Forward_Window(2))));
        Cell_Spike_Counts(Current_Cell,4)=length(find(Spike_Data(:,2)==Current_Cell & (Spike_Data(:,3)>=Minor_Peak_Window(1) & Spike_Data(:,3)<=Minor_Peak_Window(2))));
        Cell_Spike_Counts(Current_Cell,5)=length(find(Spike_Data(:,2)==Current_Cell & (Spike_Data(:,3)>=Major_Peak_Window(1) | Spike_Data(:,3)<=Major_Peak_Window(2))));
    end
    
    for Current_Ripple=1:size(Ripple_Events,1)
        Ripple_Spike_Data=All_Spike_Data(All_Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & All_Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
        Past_Spike_Data=Spike_Data(Spike_Data(:,1)>=(Ripple_Events(Current_Ripple,1)-Time_To_Look_Behind) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,1) & Matched_Spike_Velocity>=Velocity_Cutoff,:);
        Future_Spike_Data=Spike_Data(Spike_Data(:,1)<=(Ripple_Events(Current_Ripple,2)+Time_To_Look_Ahead) & Spike_Data(:,1)>=Ripple_Events(Current_Ripple,2) & Matched_Spike_Velocity>=Velocity_Cutoff,:);
        for Current_Cell=1:max(All_Spike_Data(:,2))
            Ripple_Spike_Properties(Current_Cell,1,Current_Ripple)=Current_Cell;
            Ripple_Spike_Properties(Current_Cell,2,Current_Ripple)=length(find(Ripple_Spike_Data(:,2)==Current_Cell));
            Ripple_Spike_Properties(Current_Cell,3,Current_Ripple)=length(find(Past_Spike_Data(:,2)==Current_Cell & (Past_Spike_Data(:,3)>=Reverse_Window(1) & Past_Spike_Data(:,3)<=Reverse_Window(2))));
            Ripple_Spike_Properties(Current_Cell,4,Current_Ripple)=length(find(Past_Spike_Data(:,2)==Current_Cell & (Past_Spike_Data(:,3)>=Forward_Window(1) | Past_Spike_Data(:,3)<=Forward_Window(2))));
            Ripple_Spike_Properties(Current_Cell,5,Current_Ripple)=length(find(Past_Spike_Data(:,2)==Current_Cell & (Past_Spike_Data(:,3)>=Minor_Peak_Window(1) & Past_Spike_Data(:,3)<=Minor_Peak_Window(2))));
            Ripple_Spike_Properties(Current_Cell,6,Current_Ripple)=length(find(Past_Spike_Data(:,2)==Current_Cell & (Past_Spike_Data(:,3)>=Major_Peak_Window(1) | Past_Spike_Data(:,3)<=Major_Peak_Window(2))));
            Ripple_Spike_Properties(Current_Cell,7,Current_Ripple)=length(find(Future_Spike_Data(:,2)==Current_Cell & (Future_Spike_Data(:,3)>=Reverse_Window(1) & Future_Spike_Data(:,3)<=Reverse_Window(2))));
            Ripple_Spike_Properties(Current_Cell,8,Current_Ripple)=length(find(Future_Spike_Data(:,2)==Current_Cell & (Future_Spike_Data(:,3)>=Forward_Window(1) | Future_Spike_Data(:,3)<=Forward_Window(2))));
            Ripple_Spike_Properties(Current_Cell,9,Current_Ripple)=length(find(Future_Spike_Data(:,2)==Current_Cell & (Future_Spike_Data(:,3)>=Minor_Peak_Window(1) & Future_Spike_Data(:,3)<=Minor_Peak_Window(2))));
            Ripple_Spike_Properties(Current_Cell,10,Current_Ripple)=length(find(Future_Spike_Data(:,2)==Current_Cell & (Future_Spike_Data(:,3)>=Major_Peak_Window(1) | Future_Spike_Data(:,3)<=Major_Peak_Window(2))));
            Ripple_Spike_Properties(Current_Cell,11,Current_Ripple)=length(find(Past_Spike_Data(:,2)==Current_Cell));
            Ripple_Spike_Properties(Current_Cell,12,Current_Ripple)=length(find(Future_Spike_Data(:,2)==Current_Cell));
            Ripple_Spike_Properties(Current_Cell,13,Current_Ripple)=Cell_Spike_Counts(Current_Cell,1);
            Ripple_Spike_Properties(Current_Cell,14,Current_Ripple)=Cell_Spike_Counts(Current_Cell,2);
            Ripple_Spike_Properties(Current_Cell,15,Current_Ripple)=Cell_Spike_Counts(Current_Cell,3);
            Ripple_Spike_Properties(Current_Cell,16,Current_Ripple)=Cell_Spike_Counts(Current_Cell,4);
            Ripple_Spike_Properties(Current_Cell,17,Current_Ripple)=Cell_Spike_Counts(Current_Cell,5);
        end
    end
    
    for Current_Cell=1:max(All_Spike_Data(:,2))
        Ripple_Spike_Properties(Current_Cell,18,:)=sum(sum(sum(Ripple_Spike_Properties(Current_Cell,2,:))));
    end
    
    save('Ripple_Spike_Properties','Ripple_Spike_Properties');
    
end