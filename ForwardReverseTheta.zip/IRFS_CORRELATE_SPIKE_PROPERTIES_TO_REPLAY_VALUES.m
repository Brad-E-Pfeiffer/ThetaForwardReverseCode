
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script correlates spike properties and replay.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% First, I quantify overall properties of spiking with respect to ripples,
% regardless of the content of those ripples.

%Ideas: Ratio of ripple firing in ripples immediately after firing in a
%window vs. ripples immeidately after not firing.  Compare this to the
%before condition.  No, this needs to be a correlation depending on how
%much firing happened during running in the window.

if 0%exist('Ripple_Spike_Correlations.mat','file')==2
    
    load Ripple_Spike_Correlations
    
else

    load Modality
    load Position_Data_Processed;
    load LFP_Left_Theta;
    
    LFP_Left_Theta(:,7)=0;
    LFP_Left_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=min(Position_Data(:,1)) & LFP_Left_Theta(:,1)<=max(Position_Data(:,1)),:);
    if eval(sprintf('exist(''%s_%s_To_Remove'',''var'')',Rat_Name,Directory_Name))
        eval(sprintf('Sections_To_Remove=%s_%s_To_Remove;',Rat_Name,Directory_Name));
        for Section=1:size(Sections_To_Remove,1)
            LFP_Left_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)<Sections_To_Remove(Section,1) | LFP_Left_Theta(:,1)>Sections_To_Remove(Section,2),:);
            Position_Data=Position_Data(Position_Data(:,1)<Sections_To_Remove(Section,1) | Position_Data(:,1)>Sections_To_Remove(Section,2),:);
        end
        clear Section
    end
    Total_Duration=sum(Position_Data(:,7)); %The total extent (in seconds) of this experimental session, not including sections that were removed above
    clear Sections_To_Remove
    
    
    
    
    %Bimodal_Unimodal_All_Ripples_Overall_Ratios
    %|       1     |        2       |
    %|   Modality  |    Ratio of    |
    %| (1=Unimodal)|  Ripple Spikes |
    %| (2=Bimodal) | to Total Spikes|
    Bimodal_Unimodal_All_Ripples_Overall_Ratios=zeros(max(Spike_Data(:,2)),2);
    for Cell=1:length(Excitatory_Neurons)
        Current_Cell=Excitatory_Neurons(Cell);
        Ratio_Of_Ripple_To_Total=Ripple_Spike_Properties(Current_Cell,18,1)/Ripple_Spike_Properties(Current_Cell,13,1);
        if sum(Modality(:,2)==Current_Cell)>0
            Bimodal_Unimodal_All_Ripples_Overall_Ratios(Cell,:)=[Modality(Modality(:,2)==Current_Cell,1),Ratio_Of_Ripple_To_Total];
        end
    end
    clear Current_Cell;
    clear Ratio_Of_Ripple_To_Total;
    clear Cell;
    [Bimodal_Unimodal_All_Ripples_Overall_Ratios_P_Value,~]=ranksum(Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==1,2),Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==2,2));
    % figure;
    % hold on;
    % errorbar(1,mean(Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==1,2)),std(Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==1,2))/sqrt(sum(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==1)));
    % errorbar(2,mean(Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==2,2)),std(Bimodal_Unimodal_All_Ripples_Overall_Ratios(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==2,2))/sqrt(sum(Bimodal_Unimodal_All_Ripples_Overall_Ratios(:,1)==2)));
    
    %Individual_Runs_Ripple_Spike_Properties (all cells and all ripples are just combined into one long variable for correlational purposes)
    %|           1             |                 2              |                3               |              4             |             5              |                 6               |                 7               |               8             |              9              ||
    %|Spikes In Current Ripple | Spikes In Prior Reverse Window | Spikes In Prior Forward Window | Spikes In Prior Minor Peak | Spikes In Prior Major Peak | Spikes In Future Reverse Window | Spikes In Future Forward Window | Spikes In Future Minor Peak | Spikes In Future Major Peak ||
    Individual_Runs_Ripple_Spike_Properties=[0,0,0,0,0,0,0,0,0];
    for Cell=1:length(Excitatory_Neurons)
        Current_Cell=Excitatory_Neurons(Cell);
        for Current_Ripple=1:size(Ripple_Events,1)
            Individual_Runs_Ripple_Spike_Properties(end+1,:)=Ripple_Spike_Properties(Current_Cell,2:10,Current_Ripple);
        end
    end
    clear Cell;
    clear Current_Cell;
    clear Current_Ripple;
    Individual_Runs_Ripple_Spike_Properties=Individual_Runs_Ripple_Spike_Properties(1:(end-1),:);
    
    if strcmp(Directory_Name(1),'L')
        Replay_Only_Spike_Properties=Ripple_Spike_Properties(:,:,Linear_Replay_Stats(:,3)<=0.05);
        Forward_Replay_Only_Spike_Properties=Ripple_Spike_Properties(:,:,Linear_Replay_Stats(:,3)<=0.05 & ((Linear_Replay_Stats(:,2)>0 & Linear_Replay_Stats(:,4)<=0.335) | (Linear_Replay_Stats(:,2)<0 & Linear_Replay_Stats(:,4)>=0.665)));
        Reverse_Replay_Only_Spike_Properties=Ripple_Spike_Properties(:,:,Linear_Replay_Stats(:,3)<=0.05 & ((Linear_Replay_Stats(:,2)<0 & Linear_Replay_Stats(:,4)<=0.335) | (Linear_Replay_Stats(:,2)>0 & Linear_Replay_Stats(:,4)>=0.665)));
        
        %Bimodal_Unimodal_All_Replay_Overall_Ratios
        %|       1     |        2       |
        %|   Modality  |    Ratio of    |
        %| (1=Unimodal)|  Replay Spikes |
        %| (2=Bimodal) | to Total Spikes|
        Bimodal_Unimodal_All_Replay_Overall_Ratios=zeros(max(Spike_Data(:,2)),2);
        for Cell=1:length(Excitatory_Neurons)
            Current_Cell=Excitatory_Neurons(Cell);
            Ratio_Of_Replay_To_Total=sum(Replay_Only_Spike_Properties(Current_Cell,2,:),3)/Replay_Only_Spike_Properties(Current_Cell,13,1);
            if sum(Modality(:,2)==Current_Cell)>0
                Bimodal_Unimodal_All_Replay_Overall_Ratios(Cell,:)=[Modality(Modality(:,2)==Current_Cell,1),Ratio_Of_Replay_To_Total];
            end
        end
        clear Current_Cell;
        clear Ratio_Of_Replay_To_Total;
        clear Cell;
        [Bimodal_Unimodal_All_Replay_Overall_Ratios_P_Value,~]=ranksum(Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==1,2),Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==2,2));
        % figure;
        % hold on;
        % errorbar(1,mean(Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==1,2)),std(Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==1,2))/sqrt(sum(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==1)));
        % errorbar(2,mean(Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==2,2)),std(Bimodal_Unimodal_All_Replay_Overall_Ratios(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==2,2))/sqrt(sum(Bimodal_Unimodal_All_Replay_Overall_Ratios(:,1)==2)));
        
        %Bimodal_Unimodal_Forward_Replay_Overall_Ratios
        %|       1     |            2           |
        %|   Modality  |         Ratio of       |
        %| (1=Unimodal)|  Forward Replay Spikes |
        %| (2=Bimodal) |     to Total Spikes    |
        Bimodal_Unimodal_Forward_Replay_Overall_Ratios=zeros(max(Spike_Data(:,2)),2);
        if ~isempty(Forward_Replay_Only_Spike_Properties)
            for Cell=1:length(Excitatory_Neurons)
                Current_Cell=Excitatory_Neurons(Cell);
                Ratio_Of_Forward_Replay_To_Total=sum(Forward_Replay_Only_Spike_Properties(Current_Cell,2,:),3)/Forward_Replay_Only_Spike_Properties(Current_Cell,13,1);
                if sum(Modality(:,2)==Current_Cell)>0
                    Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Cell,:)=[Modality(Modality(:,2)==Current_Cell,1),Ratio_Of_Forward_Replay_To_Total];
                end
            end
            clear Current_Cell;
            clear Ratio_Of_Forward_Replay_To_Total;
            clear Cell;
            [Bimodal_Unimodal_Forward_Replay_Overall_Ratios_P_Value,~]=ranksum(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==1,2),Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==2,2));
        end
        % figure;
        % hold on;
        % errorbar(1,mean(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==1,2)),std(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==1,2))/sqrt(sum(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==1)));
        % errorbar(2,mean(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==2,2)),std(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==2,2))/sqrt(sum(Bimodal_Unimodal_Forward_Replay_Overall_Ratios(:,1)==2)));
        
        %Bimodal_Unimodal_Reverse_Replay_Overall_Ratios
        %|       1     |            2           |
        %|   Modality  |         Ratio of       |
        %| (1=Unimodal)|  Reverse Replay Spikes |
        %| (2=Bimodal) |     to Total Spikes    |
        Bimodal_Unimodal_Reverse_Replay_Overall_Ratios=zeros(max(Spike_Data(:,2)),2);
        if ~isempty(Reverse_Replay_Only_Spike_Properties)
            for Cell=1:length(Excitatory_Neurons)
                Current_Cell=Excitatory_Neurons(Cell);
                Ratio_Of_Reverse_Replay_To_Total=sum(Reverse_Replay_Only_Spike_Properties(Current_Cell,2,:),3)/Reverse_Replay_Only_Spike_Properties(Current_Cell,13,1);
                if sum(Modality(:,2)==Current_Cell)>0
                    Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Cell,:)=[Modality(Modality(:,2)==Current_Cell,1),Ratio_Of_Reverse_Replay_To_Total];
                end
            end
            clear Current_Cell;
            clear Ratio_Of_Reverse_Replay_To_Total;
            clear Cell;
            [Bimodal_Unimodal_Reverse_Replay_Overall_Ratios_P_Value,~]=ranksum(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==1,2),Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==2,2));
        end
        % figure;
        % hold on;
        % errorbar(1,mean(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==1,2)),std(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==1,2))/sqrt(sum(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==1)));
        % errorbar(2,mean(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==2,2)),std(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==2,2))/sqrt(sum(Bimodal_Unimodal_Reverse_Replay_Overall_Ratios(:,1)==2)));
        
        %Individual_Runs_Replay_Only_Spike_Properties (all cells and all ripples are just combined into one long variable for correlational purposes)
        %|           1             |                 2              |                3               |              4             |             5              |                 6               |                 7               |               8             |              9              ||
        %|Spikes In Current Replay | Spikes In Prior Reverse Window | Spikes In Prior Forward Window | Spikes In Prior Minor Peak | Spikes In Prior Major Peak | Spikes In Future Reverse Window | Spikes In Future Forward Window | Spikes In Future Minor Peak | Spikes In Future Major Peak ||
        Individual_Runs_Replay_Only_Spike_Properties=[0,0,0,0,0,0,0,0,0];
        for Cell=1:length(Excitatory_Neurons)
            Current_Cell=Excitatory_Neurons(Cell);
            for Current_Ripple=1:size(Replay_Only_Spike_Properties,3)
                Individual_Runs_Replay_Only_Spike_Properties(end+1,:)=Replay_Only_Spike_Properties(Current_Cell,2:10,Current_Ripple);
            end
        end
        clear Cell;
        clear Current_Cell;
        clear Current_Ripple;
        Individual_Runs_Replay_Only_Spike_Properties=Individual_Runs_Replay_Only_Spike_Properties(1:(end-1),:);
        
        %Individual_Runs_Forward_Replay_Only_Spike_Properties (all cells and all ripples are just combined into one long variable for correlational purposes)
        %|               1                 |                 2              |                3               |              4             |             5              |                 6               |                 7               |               8             |              9              ||
        %|Spikes In Current Forward Replay | Spikes In Prior Reverse Window | Spikes In Prior Forward Window | Spikes In Prior Minor Peak | Spikes In Prior Major Peak | Spikes In Future Reverse Window | Spikes In Future Forward Window | Spikes In Future Minor Peak | Spikes In Future Major Peak ||
        Individual_Runs_Forward_Replay_Only_Spike_Properties=[0,0,0,0,0,0,0,0,0];
        for Cell=1:length(Excitatory_Neurons)
            Current_Cell=Excitatory_Neurons(Cell);
            for Current_Ripple=1:size(Forward_Replay_Only_Spike_Properties,3)
                Individual_Runs_Forward_Replay_Only_Spike_Properties(end+1,:)=Forward_Replay_Only_Spike_Properties(Current_Cell,2:10,Current_Ripple);
            end
        end
        clear Cell;
        clear Current_Cell;
        clear Current_Ripple;
        Individual_Runs_Forward_Replay_Only_Spike_Properties=Individual_Runs_Forward_Replay_Only_Spike_Properties(1:(end-1),:);
        
        %Individual_Runs_Reverse_Replay_Only_Spike_Properties (all cells and all ripples are just combined into one long variable for correlational purposes)
        %|               1                 |                 2              |                3               |              4             |             5              |                 6               |                 7               |               8             |              9              ||
        %|Spikes In Current Reverse Replay | Spikes In Prior Reverse Window | Spikes In Prior Forward Window | Spikes In Prior Minor Peak | Spikes In Prior Major Peak | Spikes In Future Reverse Window | Spikes In Future Forward Window | Spikes In Future Minor Peak | Spikes In Future Major Peak ||
        Individual_Runs_Reverse_Replay_Only_Spike_Properties=[0,0,0,0,0,0,0,0,0];
        for Cell=1:length(Excitatory_Neurons)
            Current_Cell=Excitatory_Neurons(Cell);
            for Current_Ripple=1:size(Reverse_Replay_Only_Spike_Properties,3)
                Individual_Runs_Reverse_Replay_Only_Spike_Properties(end+1,:)=Reverse_Replay_Only_Spike_Properties(Current_Cell,2:10,Current_Ripple);
            end
        end
        clear Cell;
        clear Current_Cell;
        clear Current_Ripple;
        Individual_Runs_Reverse_Replay_Only_Spike_Properties=Individual_Runs_Reverse_Replay_Only_Spike_Properties(1:(end-1),:);
        
    end
    
    save('Ripple_Spike_Correlations','Individual_Runs_*','Bimodal_Unimodal_*')
    
end