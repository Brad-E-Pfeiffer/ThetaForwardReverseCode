% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script loads the necessary files (many produced by the
% PROCESS_RAW_DATA function) for the quantification of Unimodal and Bimodal
% cells.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Spike_Data
load Spike_Information
load LFP_Left_Theta
LFP_Theta=LFP_Left_Theta;
clear LFP_Left_Theta;
load Position_Data_Processed
load L_Ratios
load Field_Data


