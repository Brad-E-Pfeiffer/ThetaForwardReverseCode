function IRFS_PLOT_FIGURE_THREE(Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

load('Combined_OpenField_Phase_Position_Histograms','All_Unimodal_Phase_Position_Histogram','All_Bimodal_Phase_Position_Histogram')
All_Unimodal=All_Unimodal_Phase_Position_Histogram;
All_Bimodal=All_Bimodal_Phase_Position_Histogram;
load('Combined_OpenField_Phase_Position_Histograms','All_Unimodal_Phase_Position_Histogram','All_Bimodal_Phase_Position_Histogram')
All_Unimodal=All_Unimodal+All_Unimodal_Phase_Position_Histogram;
All_Bimodal=All_Bimodal+All_Bimodal_Phase_Position_Histogram;

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('Figure3','dir')==7
    cd Figure3
else
    mkdir Figure3
    cd Figure3
end

Filter=fspecial('gaussian',[10 5],2);
Smoothed_Position_Phase_Histogram=filter2(Filter,All_Unimodal);
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
Interpolated_Position_Phase_Histogram(isnan(Interpolated_Position_Phase_Histogram))=0;
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram(:,6:end-5);  %The interpolation doesn't do the ends
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram/sum(sum(Interpolated_Position_Phase_Histogram));
figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Smoothed_Heatmap_All_Unimodal_Cells(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(1)/Initial_Variables.Phase_Bin)-0.5 (Major_Peak_Window(1)/Initial_Variables.Phase_Bin)-0.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+0.5 (Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+0.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(1)/Initial_Variables.Phase_Bin)+35.5 (Major_Peak_Window(1)/Initial_Variables.Phase_Bin)+35.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+36.5 (Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+36.5],'k--');
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Smoothed_Heatmap_All_Unimodal_Cells_With_Lines(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close;

figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:));
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:),2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:),1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Unimodal_Cells_Minor_Window_Only(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:))),max(max(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:)))));
close

figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Interpolated_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Interpolated_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Interpolated_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Unimodal_Cells(Colormap=%dto%d).jpg'');',min(min(Interpolated_Position_Phase_Histogram)),max(max(Interpolated_Position_Phase_Histogram))));
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(1)-5 Major_Peak_Window(1)-5],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(2)+5 Major_Peak_Window(2)+5],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(1)+355 Major_Peak_Window(1)+355],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(2)+365 Major_Peak_Window(2)+365],'k--');
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Unimodal_Cells_With_Lines(Colormap=%dto%d).jpg'');',min(min(Interpolated_Position_Phase_Histogram)),max(max(Interpolated_Position_Phase_Histogram))));
close;

Smoothed_Position_Phase_Histogram=filter2(Filter,All_Bimodal);
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
Interpolated_Position_Phase_Histogram(isnan(Interpolated_Position_Phase_Histogram))=0;
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram(:,6:end-5);  %The interpolation doesn't do the ends
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram/sum(sum(Interpolated_Position_Phase_Histogram));
figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Smoothed_Heatmap_All_Bimodal_Cells(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(1)/Initial_Variables.Phase_Bin)-0.5 (Major_Peak_Window(1)/Initial_Variables.Phase_Bin)-0.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+0.5 (Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+0.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(1)/Initial_Variables.Phase_Bin)+35.5 (Major_Peak_Window(1)/Initial_Variables.Phase_Bin)+35.5],'k--');
plot([1 size(Smoothed_Position_Phase_Histogram,2)],[(Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+36.5 (Major_Peak_Window(2)/Initial_Variables.Phase_Bin)+36.5],'k--');
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Smoothed_Heatmap_All_Bimodal_Cells_With_Lines(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close;

figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Interpolated_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Interpolated_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Interpolated_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Bimodal_Cells(Colormap=%dto%d).jpg'');',min(min(Interpolated_Position_Phase_Histogram)),max(max(Interpolated_Position_Phase_Histogram))));
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(1)-5 Major_Peak_Window(1)-5],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(2)+5 Major_Peak_Window(2)+5],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(1)+355 Major_Peak_Window(1)+355],'k--');
plot([1 size(Interpolated_Position_Phase_Histogram,2)],[Major_Peak_Window(2)+365 Major_Peak_Window(2)+365],'k--');
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Bimodal_Cells_With_Lines(Colormap=%dto%d).jpg'');',min(min(Interpolated_Position_Phase_Histogram)),max(max(Interpolated_Position_Phase_Histogram))));
close;

figure;hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:));
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:),2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:),1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure3B_Phase_Position_Interpolated_Heatmap_All_Bimodal_Cells_Minor_Window_Only(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:))),max(max(Smoothed_Position_Phase_Histogram(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin:Minor_Peak_Window(2)/Initial_Variables.Phase_Bin,:)))));
close

cd ..
cd ..
cd ..

cd Janni
cd Linear2
Orientation=2;
load Spike_Data_With_Linear_Position;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
cd ..
cd ..

cd AllRatsCombined
cd _Figures_For_Paper
cd Figure3

Current_Cell=80;
Direction=1;

SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
figure;subplot('Position',[0 0 1 1]);hold on;
plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
set(gca,'XLim',[31 110]);
set(gca,'YLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_3A_Example1_Spikes.jpg');
close

figure;subplot('Position',[0 0 1 1]);hold on;
bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XLim',[0.5 72.5]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example1_Spikes_Per_Phase(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;subplot('Position',[0 0 1 1]);hold on;
Smoothed_Position_Phase_Histogram=filter2(Filter,Out_Position_Phase_Histograms(:,:,Current_Cell));
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example1_Phase_Position_Heatmap(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close

cd ..
cd ..
cd ..

cd Janni
cd Linear6
Orientation=1;
load Spike_Data_With_Linear_Position;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
cd ..
cd ..

cd AllRatsCombined
cd _Figures_For_Paper
cd Figure3

Current_Cell=100;
Direction=-1;

SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
figure;subplot('Position',[0 0 1 1]);hold on;
plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
set(gca,'XLim',[-125 -22]);
set(gca,'YLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_3A_Example2_Spikes.jpg');
close

figure;subplot('Position',[0 0 1 1]);hold on;
bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XLim',[0.5 72.5]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example2_Spikes_Per_Phase(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;subplot('Position',[0 0 1 1]);hold on;
Smoothed_Position_Phase_Histogram=filter2(Filter,In_Position_Phase_Histograms(:,:,Current_Cell));
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example2_Phase_Position_Heatmap(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close

cd ..
cd ..
cd ..

cd Janni
cd Linear4
Orientation=1;
load Spike_Data_With_Linear_Position;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
cd ..
cd ..

cd AllRatsCombined
cd _Figures_For_Paper
cd Figure3

Current_Cell=42;
Direction=-1;

SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
figure;subplot('Position',[0 0 1 1]);hold on;
plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
set(gca,'XLim',[-130 -25]);
set(gca,'YLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_3A_Example3_Spikes.jpg');
close

figure;subplot('Position',[0 0 1 1]);hold on;
bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XLim',[0.5 72.5]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example3_Spikes_Per_Phase(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;subplot('Position',[0 0 1 1]);hold on;
Smoothed_Position_Phase_Histogram=filter2(Filter,In_Position_Phase_Histograms(:,:,Current_Cell));
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example3_Phase_Position_Heatmap(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close

cd ..
cd ..
cd ..

cd Janni
cd Linear3
Orientation=2;
load Spike_Data_With_Linear_Position;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
cd ..
cd ..

cd AllRatsCombined
cd _Figures_For_Paper
cd Figure3

Current_Cell=133;
Direction=-1;

SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
figure;subplot('Position',[0 0 1 1]);hold on;
plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
set(gca,'XLim',[-135 -32]);
set(gca,'YLim',[0 720]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_3A_Example4_Spikes.jpg');
close

figure;subplot('Position',[0 0 1 1]);hold on;
bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XLim',[0.5 72.5]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example4_Spikes_Per_Phase(Y=0to%d).jpg'');',Y_Lim(2)));
close

figure;subplot('Position',[0 0 1 1]);hold on;
Smoothed_Position_Phase_Histogram=filter2(Filter,In_Position_Phase_Histograms(:,:,Current_Cell));
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_Position_Phase_Histogram(isnan(Smoothed_Position_Phase_Histogram))=0;
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram/sum(sum(Smoothed_Position_Phase_Histogram));
imagesc(Smoothed_Position_Phase_Histogram);
colormap('jet');
set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histogram,2)]);
set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histogram,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3A_Example4_Phase_Position_Heatmap(Colormap=%dto%d).jpg'');',min(min(Smoothed_Position_Phase_Histogram)),max(max(Smoothed_Position_Phase_Histogram))));
close

cd ..
cd ..
cd ..

cd AllRatsCombined
load('Combined_OpenField_Phase_Position_Histograms','All_Unimodal_Phase_Position_Histogram','All_Bimodal_Phase_Position_Histogram','All_Unimodal_Phase_Position_Histogram_Phase_Shuffles','All_Unimodal_Phase_Position_Histogram_Position_Shuffles','All_Bimodal_Phase_Position_Histogram_Phase_Shuffles','All_Bimodal_Phase_Position_Histogram_Position_Shuffles');
All_Unimodal=All_Unimodal_Phase_Position_Histogram;
All_Bimodal=All_Bimodal_Phase_Position_Histogram;
Unimodal_Phase_Shuffles=All_Unimodal_Phase_Position_Histogram_Phase_Shuffles;
Unimodal_Position_Shuffles=All_Unimodal_Phase_Position_Histogram_Position_Shuffles;
Bimodal_Phase_Shuffles=All_Bimodal_Phase_Position_Histogram_Phase_Shuffles;
Bimodal_Position_Shuffles=All_Bimodal_Phase_Position_Histogram_Position_Shuffles;
load('Combined_Linear_Phase_Position_Histograms','All_Unimodal_Phase_Position_Histogram','All_Bimodal_Phase_Position_Histogram','All_Unimodal_Phase_Position_Histogram_Phase_Shuffles','All_Unimodal_Phase_Position_Histogram_Position_Shuffles','All_Bimodal_Phase_Position_Histogram_Phase_Shuffles','All_Bimodal_Phase_Position_Histogram_Position_Shuffles');
All_Unimodal=All_Unimodal+All_Unimodal_Phase_Position_Histogram;
All_Bimodal=All_Bimodal+All_Bimodal_Phase_Position_Histogram;
Unimodal_Phase_Shuffles=Unimodal_Phase_Shuffles+All_Unimodal_Phase_Position_Histogram_Phase_Shuffles;
Unimodal_Position_Shuffles=Unimodal_Position_Shuffles+All_Unimodal_Phase_Position_Histogram_Position_Shuffles;
Bimodal_Phase_Shuffles=Bimodal_Phase_Shuffles+All_Bimodal_Phase_Position_Histogram_Phase_Shuffles;
Bimodal_Position_Shuffles=Bimodal_Position_Shuffles+All_Bimodal_Phase_Position_Histogram_Position_Shuffles;

cd _Figures_For_Paper
cd Figure3

Smoothed_All_Unimodal=filter2(Filter,All_Unimodal/sum(sum(All_Unimodal)));
Smoothed_All_Unimodal=Smoothed_All_Unimodal([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_All_Unimodal(isnan(Smoothed_All_Unimodal))=0;
Smoothed_All_Bimodal=filter2(Filter,All_Bimodal/sum(sum(All_Bimodal)));
Smoothed_All_Bimodal=Smoothed_All_Bimodal([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Smoothed_All_Bimodal(isnan(Smoothed_All_Bimodal))=0;
Smoothed_All_Unimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Smoothed_All_Unimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:))
Smoothed_All_Bimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Smoothed_All_Bimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:))
Smoothed_All_Unimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Smoothed_All_Unimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:))
Smoothed_All_Bimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Smoothed_All_Bimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:))
[Smoothed_All_Unimodal_Major_Peak_Score,Smoothed_All_Unimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_All_Unimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5)
[Smoothed_All_Bimodal_Major_Peak_Score,Smoothed_All_Bimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_All_Bimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5)
[Smoothed_All_Unimodal_Minor_Peak_Score,Smoothed_All_Unimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_All_Unimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5)
[Smoothed_All_Bimodal_Minor_Peak_Score,Smoothed_All_Bimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_All_Bimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5)
Smoothed_Unimodal_Major_Shuffle_Correlations=zeros(1000,2);
Smoothed_Unimodal_Minor_Shuffle_Correlations=zeros(1000,2);
Smoothed_Bimodal_Major_Shuffle_Correlations=zeros(1000,2);
Smoothed_Bimodal_Minor_Shuffle_Correlations=zeros(1000,2);
Smoothed_Unimodal_Major_Shuffle_Scores=zeros(1000,2);
Smoothed_Unimodal_Minor_Shuffle_Scores=zeros(1000,2);
Smoothed_Bimodal_Major_Shuffle_Scores=zeros(1000,2);
Smoothed_Bimodal_Minor_Shuffle_Scores=zeros(1000,2);
for Shuffle=1:1000
    Smoothed_Unimodal_Phase_Shuffle=filter2(Filter,Unimodal_Phase_Shuffles(:,:,Shuffle)/sum(sum(Unimodal_Phase_Shuffles(:,:,Shuffle))));
    Smoothed_Unimodal_Phase_Shuffle=Smoothed_Unimodal_Phase_Shuffle([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
    Smoothed_Unimodal_Phase_Shuffle(isnan(Smoothed_Unimodal_Phase_Shuffle))=0;
    Smoothed_Unimodal_Position_Shuffle=filter2(Filter,Unimodal_Position_Shuffles(:,:,Shuffle)/sum(sum(Unimodal_Position_Shuffles(:,:,Shuffle))));
    Smoothed_Unimodal_Position_Shuffle=Smoothed_Unimodal_Position_Shuffle([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
    Smoothed_Unimodal_Position_Shuffle(isnan(Smoothed_Unimodal_Position_Shuffle))=0;
    Smoothed_Bimodal_Phase_Shuffle=filter2(Filter,Bimodal_Phase_Shuffles(:,:,Shuffle)/sum(sum(Bimodal_Phase_Shuffles(:,:,Shuffle))));
    Smoothed_Bimodal_Phase_Shuffle=Smoothed_Bimodal_Phase_Shuffle([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
    Smoothed_Bimodal_Phase_Shuffle(isnan(Smoothed_Bimodal_Phase_Shuffle))=0;
    Smoothed_Bimodal_Position_Shuffle=filter2(Filter,Bimodal_Position_Shuffles(:,:,Shuffle)/sum(sum(Bimodal_Position_Shuffles(:,:,Shuffle))));
    Smoothed_Bimodal_Position_Shuffle=Smoothed_Bimodal_Position_Shuffle([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
    Smoothed_Bimodal_Position_Shuffle(isnan(Smoothed_Bimodal_Position_Shuffle))=0;
    Smoothed_Unimodal_Major_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Smoothed_Unimodal_Phase_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
    Smoothed_Unimodal_Major_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Smoothed_Unimodal_Position_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
    Smoothed_Unimodal_Minor_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Smoothed_Unimodal_Phase_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
    Smoothed_Unimodal_Minor_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Smoothed_Unimodal_Position_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
    Smoothed_Bimodal_Major_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Smoothed_Bimodal_Phase_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
    Smoothed_Bimodal_Major_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Smoothed_Bimodal_Position_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
    Smoothed_Bimodal_Minor_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Smoothed_Bimodal_Phase_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
    Smoothed_Bimodal_Minor_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Smoothed_Bimodal_Position_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
    [Phase_Shuffle_Unimodal_Major_Peak_Score,Phase_Shuffle_Unimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Unimodal_Phase_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5);
    [Position_Shuffle_Unimodal_Major_Peak_Score,Position_Shuffle_Unimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Unimodal_Position_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5);
    [Phase_Shuffle_Unimodal_Minor_Peak_Score,Phase_Shuffle_Unimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Unimodal_Phase_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5);
    [Position_Shuffle_Unimodal_Minor_Peak_Score,Position_Shuffle_Unimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Unimodal_Position_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5);
    [Phase_Shuffle_Bimodal_Major_Peak_Score,Phase_Shuffle_Bimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Bimodal_Phase_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5);
    [Position_Shuffle_Bimodal_Major_Peak_Score,Position_Shuffle_Bimodal_Major_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Bimodal_Position_Shuffle(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:),5);
    [Phase_Shuffle_Bimodal_Minor_Peak_Score,Phase_Shuffle_Bimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Bimodal_Phase_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5);
    [Position_Shuffle_Bimodal_Minor_Peak_Score,Position_Shuffle_Bimodal_Minor_Peak_Slope]=IRFS_SEQUENCE_SCORE(Smoothed_Bimodal_Position_Shuffle(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:),5);
    Smoothed_Unimodal_Major_Shuffle_Scores(Shuffle,1)=Phase_Shuffle_Unimodal_Major_Peak_Score*sign(Phase_Shuffle_Unimodal_Major_Peak_Slope);
    Smoothed_Unimodal_Major_Shuffle_Scores(Shuffle,2)=Position_Shuffle_Unimodal_Major_Peak_Score*sign(Position_Shuffle_Unimodal_Major_Peak_Slope);
    Smoothed_Unimodal_Minor_Shuffle_Scores(Shuffle,1)=Phase_Shuffle_Unimodal_Minor_Peak_Score*sign(Phase_Shuffle_Unimodal_Minor_Peak_Slope);
    Smoothed_Unimodal_Minor_Shuffle_Scores(Shuffle,2)=Position_Shuffle_Unimodal_Minor_Peak_Score*sign(Position_Shuffle_Unimodal_Minor_Peak_Slope);
    Smoothed_Bimodal_Major_Shuffle_Scores(Shuffle,1)=Phase_Shuffle_Bimodal_Major_Peak_Score*sign(Phase_Shuffle_Bimodal_Major_Peak_Slope);
    Smoothed_Bimodal_Major_Shuffle_Scores(Shuffle,2)=Position_Shuffle_Bimodal_Major_Peak_Score*sign(Position_Shuffle_Bimodal_Major_Peak_Slope);
    Smoothed_Bimodal_Minor_Shuffle_Scores(Shuffle,1)=Phase_Shuffle_Bimodal_Minor_Peak_Score*sign(Phase_Shuffle_Bimodal_Minor_Peak_Slope);
    Smoothed_Bimodal_Minor_Shuffle_Scores(Shuffle,2)=Position_Shuffle_Bimodal_Minor_Peak_Score*sign(Position_Shuffle_Bimodal_Minor_Peak_Slope);
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-0.15:0.001:0.15,hist(Smoothed_Unimodal_Major_Shuffle_Correlations(:,2),-0.15:0.001:0.15),'r','LineWidth',4);
plot(-0.15:0.001:0.15,hist(Smoothed_Unimodal_Major_Shuffle_Correlations(:,1),-0.15:0.001:0.15),'b','LineWidth',4);
set(gca,'XLim',[-0.15 0.05]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
plot([Smoothed_All_Unimodal_Major_Peak_Correlation,Smoothed_All_Unimodal_Major_Peak_Correlation],[0 Y_Lim(2)],'k','LineWidth',10)
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3C_Unimodal_Major_Peak(X=-0.15to0.05)(Y=0to%d).jpg'');',Y_Lim(2)));
close;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-0.15:0.001:0.15,hist(Smoothed_Unimodal_Minor_Shuffle_Correlations(:,2),-0.15:0.001:0.15),'r','LineWidth',4);
plot(-0.15:0.001:0.15,hist(Smoothed_Unimodal_Minor_Shuffle_Correlations(:,1),-0.15:0.001:0.15),'b','LineWidth',4);
set(gca,'XLim',[-0.05 0.1]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
plot([Smoothed_All_Unimodal_Minor_Peak_Correlation,Smoothed_All_Unimodal_Minor_Peak_Correlation],[0 Y_Lim(2)],'k','LineWidth',10)
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3C_Unimodal_Minor_Peak(X=-0.05to0.1)(Y=0to%d).jpg'');',Y_Lim(2)));
close;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-0.15:0.001:0.15,hist(Smoothed_Bimodal_Major_Shuffle_Correlations(:,2),-0.15:0.001:0.15),'r','LineWidth',4);
plot(-0.15:0.001:0.15,hist(Smoothed_Bimodal_Major_Shuffle_Correlations(:,1),-0.15:0.001:0.15),'b','LineWidth',4);
set(gca,'XLim',[-0.15 0.05]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
plot([Smoothed_All_Bimodal_Major_Peak_Correlation,Smoothed_All_Bimodal_Major_Peak_Correlation],[0 Y_Lim(2)],'k','LineWidth',10)
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3C_Bimodal_Major_Peak(X=-0.15to0.05)(Y=0to%d).jpg'');',Y_Lim(2)));
close;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(-0.15:0.001:0.15,hist(Smoothed_Bimodal_Minor_Shuffle_Correlations(:,2),-0.15:0.001:0.15),'r','LineWidth',4);
plot(-0.15:0.001:0.15,hist(Smoothed_Bimodal_Minor_Shuffle_Correlations(:,1),-0.15:0.001:0.15),'b','LineWidth',4);
set(gca,'XLim',[-0.05 0.1]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
plot([Smoothed_All_Bimodal_Minor_Peak_Correlation,Smoothed_All_Bimodal_Minor_Peak_Correlation],[0 Y_Lim(2)],'k','LineWidth',10)
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_3C_Bimodal_Minor_Peak(X=-0.05to0.1)(Y=0to%d).jpg'');',Y_Lim(2)));
close;

cd ..
cd ..
cd ..

end