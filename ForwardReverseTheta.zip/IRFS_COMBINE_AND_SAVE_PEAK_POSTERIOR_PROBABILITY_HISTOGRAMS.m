function IRFS_COMBINE_AND_SAVE_PEAK_POSTERIOR_PROBABILITY_HISTOGRAMS(Initial_Variables)

Bin_Range=round(60/Initial_Variables.Bin_Size);
Number_Of_Theta_Bins=ceil(360/Initial_Variables.Phase_Bin);

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
        
        %This loads the raw data
        load('Decoding_Time_Info','Decoding_Time_Info','Decoding_Window_Index');
        load('Decoded_Data_And_Sequences','Decoded_Data');
        load('Average_Theta_Sequence_And_Posterior_Dists','Dist_Of_Peak_Post_By_Minor_Peak_Thirds','Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds');
        
        %This is the midpoint of the decoded data so all sessions can be similarly truncated and combined 
        Midpoint=ceil(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2);
        Decoded_Data=Decoded_Data((Midpoint-Bin_Range):(Midpoint+Bin_Range),:);
        Dist_Of_Peak_Post_By_Minor_Peak_Thirds=Dist_Of_Peak_Post_By_Minor_Peak_Thirds((Midpoint-Bin_Range):(Midpoint+Bin_Range),:,3);
        Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds((Midpoint-Bin_Range):(Midpoint+Bin_Range),:,3);
        
        %This trims the data to only decoding windows 
        Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
        Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
        
        %This finds the theta oscillations with the highest firing in the Minor Window
        Dist_Of_Spike_Counts_In_Minor_Peak=zeros(max(Trimmed_Decoding_Time_Info(:,14)),1);
        Minor_Peak_Order_By_Thirds=zeros(ceil(max(Trimmed_Decoding_Time_Info(:,14))/3),3);
        for N=1:max(Trimmed_Decoding_Time_Info(:,14))
            Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
            if ~isempty(Current_Oscillation_Decoding_Time_Info) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,9)==0,1)) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,10)==0,1))
                Dist_Of_Spike_Counts_In_Minor_Peak(N,1)=mode(Current_Oscillation_Decoding_Time_Info(:,13));
            else
                Dist_Of_Spike_Counts_In_Minor_Peak(N,1)=-1;
            end
        end
        clear N;
        clear Current_Oscillation_Decoding_Time_Info
        [Ordered_Data,Rank_Order_Index]=sortrows(Dist_Of_Spike_Counts_In_Minor_Peak(:,1));
        Rank_Order_Index=Rank_Order_Index(Ordered_Data>=0);
        clear Ordered_Data;
        for N=1:3
            Current_Third_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/3)+1):round((N*length(Rank_Order_Index))/3));
            Minor_Peak_Order_By_Thirds(1:length(Current_Third_Index),N)=Current_Third_Index;
            clear Current_Third_Index;
        end
        clear N;
        Current_Line=1;
        while max(Minor_Peak_Order_By_Thirds(Current_Line,:))>0 && Current_Line<=length(Minor_Peak_Order_By_Thirds)
            Current_Line=Current_Line+1;
        end
        Minor_Peak_Order_By_Thirds=Minor_Peak_Order_By_Thirds(1:(Current_Line-1),:);
        clear Current_Line;
        clear Rank_Order_Index;
        Theta_Oscillations_To_Use=Minor_Peak_Order_By_Thirds(Minor_Peak_Order_By_Thirds(:,3)>0,3); %These are the third of theta oscillations with highest firing rate in the minor window
        
        %This takes the raw phases and randomizes them
        Shuffled_Phases=zeros(size(Trimmed_Decoding_Time_Info,1),Initial_Variables.Number_Of_Shuffles);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffled_Phases(:,Shuffle)=Trimmed_Decoding_Time_Info(:,6)+((rand(size(Trimmed_Decoding_Time_Info,1),1)*360)-180);
            Shuffled_Phases(Shuffled_Phases(:,Shuffle)<=0,Shuffle)=Shuffled_Phases(Shuffled_Phases(:,Shuffle)<=0,Shuffle)+360;
            Shuffled_Phases(Shuffled_Phases(:,Shuffle)>360,Shuffle)=Shuffled_Phases(Shuffled_Phases(:,Shuffle)>360,Shuffle)-360;
        end
        
        %This makes an index for the decoding windows associated with each theta oscillation for more rapid analysis 
        Theta_Oscillation_Index=zeros(100,max(Trimmed_Decoding_Time_Info(:,14)));
        Max=1;
        for N=1:max(Trimmed_Decoding_Time_Info(:,14))
            Index=find(Trimmed_Decoding_Time_Info(:,14)==N);
            if sum(Trimmed_Decoding_Time_Info(Index,9)==0)==0 && sum(Trimmed_Decoding_Time_Info(Index,10)==0)==0
                Theta_Oscillation_Index(1:length(Index),N)=Index;
                Max=max([Max,length(Index)]);
            end
        end
        Theta_Oscillation_Index=Theta_Oscillation_Index(1:Max,:);
        clear Max;
        clear Index;
        clear N;
        
        cd Shuffles
        if exist('Shuffle_Dist_Of_Peak_Post_Minor_Peak_Third.mat','file')==2
            load Shuffle_Dist_Of_Peak_Post_Minor_Peak_Third
        else
            Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1),Number_Of_Theta_Bins,Initial_Variables.Number_Of_Shuffles);
            for Current_Line=1:length(Theta_Oscillations_To_Use)
                N=Theta_Oscillations_To_Use(Current_Line);
                if sum(Theta_Oscillation_Index(:,N)>0)>2
                    Current_Oscillation_Index=Theta_Oscillation_Index(Theta_Oscillation_Index(:,N)>0,N);
                    Current_Oscillation_Decoded_Data=Decoded_Data(:,Current_Oscillation_Index);
                    Current_Oscillation_Phase_Bins=ceil(Shuffled_Phases(Current_Oscillation_Index,:)/Initial_Variables.Phase_Bin);
                    [Maxes,Max_Index]=max(Current_Oscillation_Decoded_Data');
                    Max_Phase_Index=Current_Oscillation_Phase_Bins(Max_Index(Maxes>=Minimum_Max),:);
                    Max_Position_Index=1:size(Current_Oscillation_Decoded_Data,1);
                    Max_Position_Index=Max_Position_Index(Maxes>=Minimum_Max);
                    for Shuffle=1:Initial_Variables.Number_Of_Shuffles
                        for M=1:length(Max_Position_Index)
                            Phase_Shuffle_Dist_Of_Peak_Post(Max_Position_Index(M),Max_Phase_Index(M,Shuffle),Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post(Max_Position_Index(M),Max_Phase_Index(M,Shuffle),Shuffle)+1;
                        end
                    end
                end
            end
            clear Current_Line;
            Norm_Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post,1),size(Phase_Shuffle_Dist_Of_Peak_Post,2),Initial_Variables.Number_Of_Shuffles);
            for Shuffle=1:Initial_Variables.Number_Of_Shuffles
                for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post,2)
                    Norm_Phase_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle)/sum(Phase_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle));
                end
            end
            Cell_ID_Shuffle_Dist_Of_Peak_Post=zeros(size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1),Number_Of_Theta_Bins,Initial_Variables.Number_Of_Shuffles);
            for Shuffle=1:Initial_Variables.Number_Of_Shuffles
                eval(sprintf('load(''Shuffle_Data_%d'',''Decoded_Shuffle_Data'')',Shuffle));
                if length(Trimmed_Decoding_Time_Info)~=length(Decoded_Shuffle_Data)
                    error('Trimmed_Decoding_Time_Info is not the same length as Decoded_Shuffle_Data!')
                end
                Decoded_Shuffle_Data=Decoded_Shuffle_Data((Midpoint-Bin_Range):(Midpoint+Bin_Range),:);
                
                for Current_Line=1:length(Theta_Oscillations_To_Use)
                    N=Theta_Oscillations_To_Use(Current_Line);
                    if sum(Theta_Oscillation_Index(:,N)>0)>2
                        Current_Oscillation_Index=Theta_Oscillation_Index(Theta_Oscillation_Index(:,N)>0,N);
                        Current_Oscillation_Decoded_Data=Decoded_Shuffle_Data(:,Current_Oscillation_Index);
                        Current_Oscillation_Phase_Bins=ceil(Trimmed_Decoding_Time_Info(Current_Oscillation_Index,6)/Initial_Variables.Phase_Bin);
                        [Maxes,Max_Index]=max(Current_Oscillation_Decoded_Data');
                        Max_Phase_Index=Current_Oscillation_Phase_Bins(Max_Index(Maxes>=Minimum_Max));
                        Max_Position_Index=1:size(Current_Oscillation_Decoded_Data,1);
                        Max_Position_Index=Max_Position_Index(Maxes>=Minimum_Max);
                        for M=1:length(Max_Position_Index)
                            Cell_ID_Shuffle_Dist_Of_Peak_Post(Max_Position_Index(M),Max_Phase_Index(M),Shuffle)=Cell_ID_Shuffle_Dist_Of_Peak_Post(Max_Position_Index(M),Max_Phase_Index(M),Shuffle)+1;
                        end
                    end
                end
                clear Current_Line;
            end
            Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post=zeros(size(Cell_ID_Shuffle_Dist_Of_Peak_Post,1),size(Cell_ID_Shuffle_Dist_Of_Peak_Post,2),Initial_Variables.Number_Of_Shuffles);
            for Shuffle=1:Initial_Variables.Number_Of_Shuffles
                for N=1:size(Cell_ID_Shuffle_Dist_Of_Peak_Post,2)
                    Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle)=Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle)/sum(Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N,Shuffle));
                end
            end
            
            save('Shuffle_Dist_Of_Peak_Post_Minor_Peak_Third','Cell_ID_Shuffle_Dist_Of_Peak_Post','Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post','Phase_Shuffle_Dist_Of_Peak_Post','Norm_Phase_Shuffle_Dist_Of_Peak_Post')
            
            clear Decoding_Time_Info;
            clear Decoding_Window_Index;
            clear Trimmed_Decoding_Time_Info;
            clear Theta_Oscillation_Index;
            clear Shuffle;
            clear Decoded_Shuffle_Data;
            clear N;
            clear Current_Oscillation_Index;
            clear Current_Oscillation_Decoded_Data;
            clear Current_Oscilation_Phase_Bins;
            clear Maxes;
            clear Max_Phase_Index;
            clear Max_Index;
            clear Max_Position_Index;
            clear M;
            clear Theta_Oscillation_Index;
        end
        eval(sprintf('%s_%s_Norm_Dist=Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds;',Rat_Name,Directory_Name))
        eval(sprintf('%s_%s_Raw_Dist=Dist_Of_Peak_Post_By_Minor_Peak_Thirds;',Rat_Name,Directory_Name))
        eval(sprintf('%s_%s_Norm_Cell_ID_Shuffle_Dist=Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post;',Rat_Name,Directory_Name))
        eval(sprintf('%s_%s_Raw_Cell_ID_Shuffle_Dist=Cell_ID_Shuffle_Dist_Of_Peak_Post;',Rat_Name,Directory_Name))
        eval(sprintf('%s_%s_Norm_Phase_Shuffle_Dist=Norm_Phase_Shuffle_Dist_Of_Peak_Post;',Rat_Name,Directory_Name))
        eval(sprintf('%s_%s_Raw_Phase_Shuffle_Dist=Phase_Shuffle_Dist_Of_Peak_Post;',Rat_Name,Directory_Name))
        if exist('All_Dist_Of_Peak_Post','var')
            All_Dist_Of_Peak_Post=All_Dist_Of_Peak_Post+Dist_Of_Peak_Post_By_Minor_Peak_Thirds;
            All_Raw_Cell_ID_Shuffle_Dist=All_Raw_Cell_ID_Shuffle_Dist+Cell_ID_Shuffle_Dist_Of_Peak_Post;
            All_Raw_Phase_Shuffle_Dist=All_Raw_Phase_Shuffle_Dist+Phase_Shuffle_Dist_Of_Peak_Post;
        else
            All_Dist_Of_Peak_Post=Dist_Of_Peak_Post_By_Minor_Peak_Thirds;
            All_Raw_Cell_ID_Shuffle_Dist=Cell_ID_Shuffle_Dist_Of_Peak_Post;
            All_Raw_Phase_Shuffle_Dist=Phase_Shuffle_Dist_Of_Peak_Post;
        end
            
        clear Shuffle_Dist_Of_Peak_Post
        clear Dist_Of_Peak_Post
        clear Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post
        clear Cell_ID_Shuffle_Dist_Of_Peak_Post
        clear Norm_Phase_Shuffle_Dist_Of_Peak_Post
        clear Phase_Shuffle_Dist_Of_Peak_Post
        
        cd ..
        cd ..
        fprintf('Finished %s %s.\n',Rat_Name,Directory_Name);
    end
    clear Directory
    cd ..
    
end

Norm_All_Dist_Of_Peak_Post=zeros(size(All_Dist_Of_Peak_Post,1),size(All_Dist_Of_Peak_Post,2));
for N=1:size(All_Dist_Of_Peak_Post,2)
    Norm_All_Dist_Of_Peak_Post(:,N)=All_Dist_Of_Peak_Post(:,N)/sum(All_Dist_Of_Peak_Post(:,N));
end
Norm_All_Cell_ID_Shuffle_Dist=zeros(size(All_Raw_Cell_ID_Shuffle_Dist,1),size(All_Raw_Cell_ID_Shuffle_Dist,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Raw_Cell_ID_Shuffle_Dist,2)
        Norm_All_Cell_ID_Shuffle_Dist(:,N,Shuffle)=All_Raw_Cell_ID_Shuffle_Dist(:,N,Shuffle)/sum(All_Raw_Cell_ID_Shuffle_Dist(:,N,Shuffle));
    end
end
Norm_All_Phase_Shuffle_Dist=zeros(size(All_Raw_Phase_Shuffle_Dist,1),size(All_Raw_Phase_Shuffle_Dist,2),Initial_Variables.Number_Of_Shuffles);
for Shuffle=1:Initial_Variables.Number_Of_Shuffles
    for N=1:size(All_Raw_Phase_Shuffle_Dist,2)
        Norm_All_Phase_Shuffle_Dist(:,N,Shuffle)=All_Raw_Phase_Shuffle_Dist(:,N,Shuffle)/sum(All_Raw_Phase_Shuffle_Dist(:,N,Shuffle));
    end
end
clear Number_Of_Theta_Bins
clear Bin_Range
clear N
clear Shuffle
clear Rat
clear Experiment
clear Rats

cd AllRatsCombined
save('Combined_Peak_Posterior_Distributions_Minor_Peak_Third','*_Norm_Dist','*_Raw_Dist','*_Shuffle_Dist','All_Dist_Of_Peak_Post','Norm_All_Dist_Of_Peak_Post');

cd ..

end