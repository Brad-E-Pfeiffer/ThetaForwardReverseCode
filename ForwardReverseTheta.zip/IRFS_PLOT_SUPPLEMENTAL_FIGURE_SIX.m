function IRFS_PLOT_SUPPLEMENTAL_FIGURE_SIX(Initial_Variables)

load Bimodal_Analysis_Windows
Phase_Bin=Initial_Variables.Phase_Bin;
Position_Bin=Initial_Variables.Bin_Size;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Session=0;
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        Session=Session+1;
        
        load('Average_Theta_Sequence_And_Posterior_Dists','Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds','Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths','Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds','Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths')
        Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(isnan(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds))=0;
        Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(isnan(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths))=0;
        Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(isnan(Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds))=0;
        Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(isnan(Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths))=0;
        Midpoint=ceil(size(Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds,1)/2);
        
        if exist('Minor_Thirds','var')==1
            Minor_Thirds=Minor_Thirds+[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        else
            Minor_Thirds=[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        end
        if exist('Major_Thirds','var')==1
            Major_Thirds=Major_Thirds+[Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        else
            Major_Thirds=[Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        end
        if exist('Minor_Tenths','var')==1
            Minor_Tenths(:,:,:,Session)=[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        else
            Minor_Tenths=[Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        end
        if exist('Major_Tenths','var')==1
            Major_Tenths(:,:,:,Session)=[Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        else
            Major_Tenths=[Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:),Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(((Midpoint-round(60/Position_Bin)):(Midpoint+round(60/Position_Bin))),:,:)];
        end
        cd ..
    end
    clear Directory
    cd ..
end
Minor_Thirds=Minor_Thirds/16;  %Divide by 16 sessions to make it a mean rather than a sum
Major_Thirds=Major_Thirds/16;  %Divide by 16 sessions to make it a mean rather than a sum
clear Rat
clear Experiment
clear Rats
clear Session
cd AllRatsCombined
cd _Figures_For_Paper
if exist('SupplementalFigure6','dir')==7
    cd SupplementalFigure6
else
    mkdir SupplementalFigure6
    cd SupplementalFigure6
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Major_Thirds(:,:,1));
colormap('hot');
set(gca,'XLim',[1 size(Major_Thirds,2)]);
set(gca,'YLim',[1 size(Major_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Left(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,1))),max(max(Major_Thirds(:,:,1)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Left_With_Lines(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,1))),max(max(Major_Thirds(:,:,1)))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Major_Thirds(:,:,2));
colormap('hot');
set(gca,'XLim',[1 size(Major_Thirds,2)]);
set(gca,'YLim',[1 size(Major_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Middle(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,2))),max(max(Major_Thirds(:,:,2)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Middle_With_Lines(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,2))),max(max(Major_Thirds(:,:,2)))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Major_Thirds(:,:,3));
colormap('hot');
set(gca,'XLim',[1 size(Major_Thirds,2)]);
set(gca,'YLim',[1 size(Major_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Right(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,3))),max(max(Major_Thirds(:,:,3)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Major_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6A_Right_With_Lines(Z=%dto%d).jpg'');',min(min(Major_Thirds(:,:,3))),max(max(Major_Thirds(:,:,3)))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Minor_Thirds(:,:,1));
colormap('hot');
set(gca,'XLim',[1 size(Minor_Thirds,2)]);
set(gca,'YLim',[1 size(Minor_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Left(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,1))),max(max(Minor_Thirds(:,:,1)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Left_With_Lines(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,1))),max(max(Minor_Thirds(:,:,1)))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Minor_Thirds(:,:,2));
colormap('hot');
set(gca,'XLim',[1 size(Minor_Thirds,2)]);
set(gca,'YLim',[1 size(Minor_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Middle(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,2))),max(max(Minor_Thirds(:,:,2)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Middle_With_Lines(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,2))),max(max(Minor_Thirds(:,:,2)))));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Minor_Thirds(:,:,3));
colormap('hot');
set(gca,'XLim',[1 size(Minor_Thirds,2)]);
set(gca,'YLim',[1 size(Minor_Thirds,1)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Right(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,3))),max(max(Minor_Thirds(:,:,3)))));
plot([70/Phase_Bin 70/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([240/Phase_Bin 240/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([430/Phase_Bin 430/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
plot([600/Phase_Bin 600/Phase_Bin],[1 size(Minor_Thirds,1)],'--w','LineWidth',2);
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6B_Right_With_Lines(Z=%dto%d).jpg'');',min(min(Minor_Thirds(:,:,3))),max(max(Minor_Thirds(:,:,3)))));
close

Major_Rank_Forward_Window=zeros(10,16);
Major_Rank_Reverse_Window=zeros(10,16);
Minor_Rank_Forward_Window=zeros(10,16);
Minor_Rank_Reverse_Window=zeros(10,16);

for Rank=1:10
    for Session=1:16
%         % This analyzes all decoding bins, which could produce a confound from 'resetting' of the previous theta cycle 
%         Major_Rank_Forward_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Major_Tenths(:,round((Forward_Window(1):(Forward_Window(2)+360))/Phase_Bin),Rank,Session));
%         Major_Rank_Reverse_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Major_Tenths(:,round((Reverse_Window(1):Reverse_Window(2))/Phase_Bin),Rank,Session));
%         Minor_Rank_Forward_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Minor_Tenths(:,round((Forward_Window(1):(Forward_Window(2)+360))/Phase_Bin),Rank,Session));
%         Minor_Rank_Reverse_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Minor_Tenths(:,round((Reverse_Window(1):Reverse_Window(2))/Phase_Bin),Rank,Session));
        % This specifically restricts the analysis to ONLY the forward or reverse windows (starting 15 cm ahead or behind the animal, respectively), thereby removing the 'resetting' confound  
        Midpoint=ceil(size(Major_Tenths,1)/2);
        Bin_Size=Initial_Variables.Bin_Size;
        Major_Rank_Forward_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Major_Tenths((Midpoint+round(15/Bin_Size)):size(Major_Tenths,1),round((Forward_Window(1):(Forward_Window(2)+360))/Phase_Bin),Rank,Session));
        Major_Rank_Reverse_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Major_Tenths((Midpoint+round(15/Bin_Size)):size(Major_Tenths,1),round((Reverse_Window(1):Reverse_Window(2))/Phase_Bin),Rank,Session));
        Minor_Rank_Forward_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Minor_Tenths(1:(Midpoint-round(15/Bin_Size)),round((Forward_Window(1):(Forward_Window(2)+360))/Phase_Bin),Rank,Session));
        Minor_Rank_Reverse_Window(Rank,Session)=IRFS_WEIGHTED_CORRELATION(Minor_Tenths(1:(Midpoint-round(15/Bin_Size)),round((Reverse_Window(1):Reverse_Window(2))/Phase_Bin),Rank,Session));
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
errorbar(1:10,mean(Major_Rank_Forward_Window'),std(Major_Rank_Forward_Window')/sqrt(16),'b','LineWidth',4)
errorbar(1:10,mean(Minor_Rank_Forward_Window'),std(Minor_Rank_Forward_Window')/sqrt(16),'r','LineWidth',4)
set(gca,'XLim',[0 11]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6C_Left(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
errorbar(1:10,mean(Major_Rank_Reverse_Window'),std(Major_Rank_Reverse_Window')/sqrt(16),'b','LineWidth',4)
errorbar(1:10,mean(Minor_Rank_Reverse_Window'),std(Minor_Rank_Reverse_Window')/sqrt(16),'r','LineWidth',4)
set(gca,'XLim',[0 11]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_6C_Left(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close;

%Repeated Measures Correlation statistics performed using the rmcorr package
%developed for R by Bakdash and Marusich (Front. Psych., 2017).













cd ..
cd ..
cd ..



end