% This makes all of the example theta sequence figures for Figure 1a and
% Supplemental Figures 1 and 2

cd Janni
cd Open2
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;
load Field_Data
load LFP_Left
load LFP_Left_Theta
load('Decoding_Time_Info','Decoding_Window_Index','Decoding_Times','Decoding_Time_Info')
load('Decoded_Data_And_Sequences','Decoded_Data','Decoded_X_Data','Decoded_Y_Data')

cd ..
cd ..
cd AllRatsCombined
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end
if exist('Figure1','dir')==7
    cd Figure1
else
    mkdir('Figure1')
    cd Figure1
end

Start=34096.478;
End=34096.94;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Left_Example_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Left_Example_All_Three_Decoding.jpg');
close


Start=34522.42;
End=34522.577;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Middle_Example_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Middle_Example_All_Three_Decoding.jpg');
close


cd ..
if exist('SupplementalFigure1','dir')==7
    cd SupplementalFigure1
else
    mkdir('SupplementalFigure1')
    cd SupplementalFigure1
end

Start=34699.055;
End=34699.79;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_6_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_6_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_6_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_6_Spike_Data.jpg');
close

Start=34481.51;
End=34482.51;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_7_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_7_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_7_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_7_Spike_Data.jpg');
close

Start=34096.478;
End=34096.94;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_8_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_8_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_8_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_8_Spike_Data.jpg');
close

Start=34522.42;
End=34522.577;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_9_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_9_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_9_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_9_Spike_Data.jpg');
close

Start=36153.02;
End=36153.15;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_10_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_10_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_10_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_10_Spike_Data.jpg');
close

cd ..
cd ..
cd ..

cd Janni
cd Open1
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;
load Field_Data
load LFP_Left
load LFP_Left_Theta
load('Decoding_Time_Info','Decoding_Window_Index','Decoding_Times','Decoding_Time_Info')
load('Decoded_Data_And_Sequences','Decoded_Data','Decoded_X_Data','Decoded_Y_Data')

cd ..
cd ..
cd AllRatsCombined
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end
if exist('Figure1','dir')==7
    cd Figure1
else
    mkdir('Figure1')
    cd Figure1
end

Start=3448.202;
End=3448.327;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Right_Example_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Figure_1A_Right_Example_All_Three_Decoding.jpg');
close

cd ..

if exist('SupplementalFigure1','dir')==7
    cd SupplementalFigure1
else
    mkdir('SupplementalFigure1')
    cd SupplementalFigure1
end

Start=3224.797;
End=3225.717;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_1_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_1_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_1_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_1_Spike_Data.jpg');
close

Start=3513.007;
End=3513.952;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_2_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_2_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_2_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_2_Spike_Data.jpg');
close

Start=2866.437;
End=2867.252;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_3_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_3_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_3_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_3_Spike_Data.jpg');
close

Start=3448.202;
End=3448.327;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_4_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_4_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_4_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_4_Spike_Data.jpg');
close

Start=3022.117;
End=3022.247;
X_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,1)/Initial_Variables.Bin_Size;
Y_Location=Decoding_Time_Info(Decoding_Times>=Start & Decoding_Times<=End,2)/Initial_Variables.Bin_Size;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_X_Data=Decoded_X_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_Y_Data=Decoded_Y_Data(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)/length(Y_Location):size(Subset_Decoded_Y_Data,2)],Y_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
plot([size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)/length(X_Location):size(Subset_Decoded_X_Data,2)],X_Location,'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_5_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(Subset_Decoded_Y_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(Subset_Decoded_X_Data,[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_5_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_5_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_1_Example_5_Spike_Data.jpg');
close

cd ..
cd ..
cd ..

cd Harpy
cd Linear2
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;
load Field_Data
%load CSC70
%load Theta_CSC70
load LFP_Left
load LFP_Left_Theta
load('Decoding_Time_Info','Decoding_Window_Index','Decoding_Times','Decoding_Time_Info')
load('Decoded_Linear_Data_And_Sequences','Decoded_Data_Linear','Decoded_Data_Linear_In','Decoded_Data_Linear_Out')

cd ..
cd ..
cd AllRatsCombined
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end
if exist('SupplementalFigure2','dir')==7
    cd SupplementalFigure2
else
    mkdir('SupplementalFigure2')
    cd SupplementalFigure2
end

Start=19470.175;
End=19470.94;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
%Subset_LFP=CSC70(CSC70(:,1)>=Start & CSC70(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
%Subset_Theta=Theta_CSC70(Theta_CSC70(:,1)>=Start & Theta_CSC70(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_1_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_1_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_1_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_1_Spike_Data.jpg');
close

Start=20287.575;
End=20288.35;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
%Subset_LFP=CSC70(CSC70(:,1)>=Start & CSC70(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
%Subset_Theta=Theta_CSC70(Theta_CSC70(:,1)>=Start & Theta_CSC70(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_3_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_3_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_3_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_3_Spike_Data.jpg');
close

Start=20202.45;
End=20203.01;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
%Subset_LFP=CSC70(CSC70(:,1)>=Start & CSC70(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
%Subset_Theta=Theta_CSC70(Theta_CSC70(:,1)>=Start & Theta_CSC70(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_6_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_6_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_6_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_6_Spike_Data.jpg');
close

Start=19554.613;
End=19554.745;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
%Subset_LFP=CSC70(CSC70(:,1)>=Start & CSC70(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
%Subset_Theta=Theta_CSC70(Theta_CSC70(:,1)>=Start & Theta_CSC70(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_8_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_8_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_8_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_8_Spike_Data.jpg');
close

cd ..
cd ..
cd ..

cd Janni
cd Linear3
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;
load Field_Data
load LFP_Left
load LFP_Left_Theta
load('Decoding_Time_Info','Decoding_Window_Index','Decoding_Times','Decoding_Time_Info')
load('Decoded_Linear_Data_And_Sequences','Decoded_Data_Linear','Decoded_Data_Linear_In','Decoded_Data_Linear_Out')

cd ..
cd ..
cd AllRatsCombined
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end
if exist('SupplementalFigure2','dir')==7
    cd SupplementalFigure2
else
    mkdir('SupplementalFigure2')
    cd SupplementalFigure2
end

Start=20505.436;
End=20505.89;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_2_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_2_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_2_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_2_Spike_Data.jpg');
close

Start=20876.506;
End=20876.686;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_4_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_4_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_4_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_4_Spike_Data.jpg');
close

cd ..
cd ..
cd ..

cd Janni
cd Linear5
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
clear N;
load Field_Data
load LFP_Left
load LFP_Left_Theta
load('Decoding_Time_Info','Decoding_Window_Index','Decoding_Times','Decoding_Time_Info')
load('Decoded_Linear_Data_And_Sequences','Decoded_Data_Linear','Decoded_Data_Linear_In','Decoded_Data_Linear_Out')

cd ..
cd ..
cd AllRatsCombined
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end
if exist('SupplementalFigure2','dir')==7
    cd SupplementalFigure2
else
    mkdir('SupplementalFigure2')
    cd SupplementalFigure2
end

Start=15919.796;
End=15920.616;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_5_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_5_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_5_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_5_Spike_Data.jpg');
close

Start=16176.261;
End=16176.511;
Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start & Spike_Data(:,1)<=End,:);
Subset_LFP=LFP_Left(LFP_Left(:,1)>=Start & LFP_Left(:,1)<=End,:);
Subset_Theta=LFP_Left_Theta(LFP_Left_Theta(:,1)>=Start & LFP_Left_Theta(:,1)<=End,:);
Subset_Decoded_Data=Decoded_Data_Linear(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_IN_Data=Decoded_Data_Linear_In(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Subset_Decoded_OUT_Data=Decoded_Data_Linear_Out(:,Decoding_Times(Decoding_Window_Index)>=Start & Decoding_Times(Decoding_Window_Index)<=End);
Crossings=0;
for N=2:size(Subset_Theta,1)
    if Subset_Theta((N-1),4)<=70 && Subset_Theta(N,4)>70
        Crossings(end+1,1)=N;
    end
end
clear N;
Crossings=Crossings(2:end,:);

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_Data,2)],[ceil(size(Subset_Decoded_Data,1)/2) ceil(size(Subset_Decoded_Data,1)/2)],'c','LineWidth',5);
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_IN_Data,2)],[ceil(size(Subset_Decoded_IN_Data,1)/2) ceil(size(Subset_Decoded_IN_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
plot([1 size(Subset_Decoded_OUT_Data,2)],[ceil(size(Subset_Decoded_OUT_Data,1)/2) ceil(size(Subset_Decoded_OUT_Data,1)/2)],'c','LineWidth',5);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
for N=1:length(Crossings)
    plot([Crossings(N) Crossings(N)],[Y_Min Y_Max],'k--','LineWidth',5);
end
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_7_All_Three_Decoding_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 0.3]);
imagesc(flipud(Subset_Decoded_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'YLim',[ceil(size(Subset_Decoded_Data,1)/2)-30 ceil(size(Subset_Decoded_Data,1)/2)+30])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.3 1 0.3]);
imagesc(flipud(Subset_Decoded_IN_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.6 1 0.3]);
imagesc(flipud(Subset_Decoded_OUT_Data),[0 0.25]);
colormap('hot');
hold on;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
subplot('Position',[0 0.9 1 0.1]);
hold on;
plot(1:size(Subset_LFP,1),Subset_LFP(:,2),'Color',[0.5 0.5 0.5],'LineWidth',3);
plot(1:size(Subset_Theta,1),Subset_Theta(:,2),'k','LineWidth',4);
Y_Min=min([Subset_LFP(:,2);Subset_Theta(:,2)]);
Y_Max=max([Subset_LFP(:,2);Subset_Theta(:,2)]);
set(gca,'XLim',[1 size(Subset_LFP,1)]);
set(gca,'YLim',[Y_Min-((Y_Max-Y_Min)/20) Y_Max+((Y_Max-Y_Min)/20)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_7_All_Three_Decoding.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    plot([End End],[1 max(Spike_Data(:,2))],'k--');
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_7_Spike_Data_With_Lines.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
plot(Subset_Spike_Data(:,1),Subset_Spike_Data(:,2),'.k','MarkerSize',6);
set(gca,'XLim',[Start End]);
if End-Start<1
    set(gca,'XLim',[Start End+(1-(End-Start))]);  %This makes all of the spike plots the same size (1 second) so the dots aren't stretched when I need to scale things.
end
set(gca,'YLim',[0 max(Spike_Data(:,2))+1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Sup_Fig_2_Example_7_Spike_Data.jpg');
close

cd ..
cd ..
cd ..

clearvars -except Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name


