function IRFS_IDENTIFY_THETA_SEQUENCE_ANALYSIS_WINDOWS(Initial_Variables)

% This function pulls up the average bimodal firing rates and the average
% posterior probability histograms and calculates the Forward/Reverse and
% Major/Minor Peak Window boundaries (in theta phase).

Phase_Bin=Initial_Variables.Phase_Bin;
cd AllRatsCombined
load('Cell_Modality_Information','All_Bimodal_Firing_Rate_Per_Phase');
load('Combined_Theta_Sequences','All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds');

Bimodal_Firing_Rate=[mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1),mean(All_Bimodal_Firing_Rate_Per_Phase(:,:,3),1)];
Decoding_Probabilities=[mean(All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds(:,:,3,:),4),mean(All_Norm_Dist_Of_Peak_Post_Minor_Window_Thirds(:,:,3,:),4)];
Decoding_Probability_Maxes=filtfilt(fspecial('gaussian',[7,1],1),1,max(Decoding_Probabilities));

[~,Firing_Rate_Troughs]=findpeaks(-Bimodal_Firing_Rate);
[~,Decoding_Troughs]=findpeaks(-Decoding_Probability_Maxes);

Firing_Rate_Troughs=Firing_Rate_Troughs*Phase_Bin;
Decoding_Troughs=Decoding_Troughs*Phase_Bin;

Firing_Rate_Troughs=Firing_Rate_Troughs(1:2);
Decoding_Troughs=Decoding_Troughs(1:2);

Major_Peak_Window=[Firing_Rate_Troughs(2)+Phase_Bin,Firing_Rate_Troughs(1)-Phase_Bin];
Minor_Peak_Window=[Firing_Rate_Troughs(1),Firing_Rate_Troughs(2)];
Forward_Window=[Decoding_Troughs(2)+Phase_Bin,Decoding_Troughs(1)-Phase_Bin];
Reverse_Window=[Decoding_Troughs(1)+Phase_Bin,Decoding_Troughs(2)-Phase_Bin];

cd ..

end
