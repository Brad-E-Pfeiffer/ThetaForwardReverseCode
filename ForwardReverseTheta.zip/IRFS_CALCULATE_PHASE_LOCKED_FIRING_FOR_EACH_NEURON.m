function Firing_Rate_Per_Phase=IRFS_CALCULATE_PHASE_LOCKED_FIRING_FOR_EACH_NEURON(Spike_Data,Spike_Information,Velocity_Cutoff,Phase_Bin,Gaussian_Smoothing_Sigma,Total_Duration,Minimum_Spike_Count,Theta_Length_Min_Max,Limit_Analysis_By_Theta_Length)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the amount of phase-locked firing for each
% neuron relative to the theta oscillation
% 
% Firing_Rate_Per_Phase
% Each row is a cell, each column is a phase bin (from 0-360 degrees).
% Page 1 is the raw firing rate per phase. 
% Page 2 is the smoothed firing rate per phase.
% Page 3 is the Firing Rate Index per phase (based on the smoothed firing rate per phase). 
% Page 4 is the raw total number of spikes per phase.
% Page 5 is smoothed total number of spikes per phase.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Spike_Data(Spike_Data(:,3)==0,3)=360;  %Just to make sure that the method below doesn't skip over any spikes
Firing_Rate_Per_Phase=zeros(max(Spike_Data(:,2)),ceil(360/Phase_Bin),5);
Smoothing_Filter=fspecial('gaussian',[1,7],Gaussian_Smoothing_Sigma/Phase_Bin);  %A gaussian filter with a sigma defined above that extends 7 bins (3 in either direction)

%Other filter settings that I tried that I felt didn't quite capture the true shape of the raw histogram  
%Smoothing_Filter=fspecial('gaussian',[1,7],1);  %A gaussian filter with a sigma of 1 bin that extends 7 bins (3 in either direction)
%Smoothing_Filter=fspecial('gaussian',[1,9],1.5);  %A gaussian filter with a sigma of 1.5 bins that extends 9 bins (4 in either direction)
%Smoothing_Filter=fspecial('gaussian',[1,8],1.2);  %A gaussian filter with a sigma of 1.2 bins that extends 8 bins (4 in either direction)
%Smoothing_Filter=fspecial('average',[1,7]);  %A box (average) filter that extends 7 bins (3 in either direction)
%Smoothing_Filter=fspecial('average',[1,3]);  %A box (average) filter that extends 3 bins (1 in either direction)
%Smoothing_Filter=fspecial('average',[1,5]);  %A box (average) filter that extends 5 bins (2 in either direction)
%Smoothing_Filter=fspecial('gaussian',[1,9],2);  %A gaussian filter with a sigma of 2 bins that extends 9 bins (4 in either direction)

for N=1:max(Spike_Data(:,2))
    SD=Spike_Data(Spike_Data(:,2)==N & Spike_Information(:,4)>=Velocity_Cutoff,:);
    if size(SD,1)>=Minimum_Spike_Count
        for M=1:size(Firing_Rate_Per_Phase,2)
            if Limit_Analysis_By_Theta_Length==1
                Firing_Rate_Per_Phase(N,M,4)=sum(SD(:,3)>((Phase_Bin*M)-Phase_Bin) & SD(:,3)<=(Phase_Bin*M) & SD(:,4)>=Theta_Length_Min_Max(1,1) & SD(:,4)<=Theta_Length_Min_Max(1,2) & SD(:,5)==1);
            else
                Firing_Rate_Per_Phase(N,M,4)=sum(SD(:,3)>((Phase_Bin*M)-Phase_Bin) & SD(:,3)<=(Phase_Bin*M));
            end
            Firing_Rate_Per_Phase(N,M,1)=Firing_Rate_Per_Phase(N,M,4)/Total_Duration;
        end
        clear M;
        % This smooths the phase-locked firing histograms
        S=filtfilt(Smoothing_Filter,1,[Firing_Rate_Per_Phase(N,:,1),Firing_Rate_Per_Phase(N,:,1)]);
        Firing_Rate_Per_Phase(N,:,2)=[S((size(Firing_Rate_Per_Phase,2)+1):(size(Firing_Rate_Per_Phase,2)+round(180/Phase_Bin))),S((round(180/Phase_Bin)+1):round(360/Phase_Bin))];
        SS=filtfilt(Smoothing_Filter,1,[Firing_Rate_Per_Phase(N,:,4),Firing_Rate_Per_Phase(N,:,4)]);
        Firing_Rate_Per_Phase(N,:,5)=[SS((size(Firing_Rate_Per_Phase,2)+1):(size(Firing_Rate_Per_Phase,2)+round(180/Phase_Bin))),SS((round(180/Phase_Bin)+1):round(360/Phase_Bin))];
        Firing_Rate_Per_Phase(N,:,3)=(Firing_Rate_Per_Phase(N,:,2)-min(Firing_Rate_Per_Phase(N,:,2)))/max(Firing_Rate_Per_Phase(N,:,2));  %This is the true Firing Rate Index, which normalizes from 0 to up to 1 (but can be less than 1).
        clear S;
        clear SS
    end
    clear SD;
end
clear N;
clear Smoothing_Filter;
save('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase')

end

