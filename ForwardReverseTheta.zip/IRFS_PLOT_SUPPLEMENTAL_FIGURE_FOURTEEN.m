function IRFS_PLOT_SUPPLEMENTAL_FIGURE_FOURTEEN

cd Janni
cd Linear2
Orientation=2;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[70  1 1
          127  1 1
           91  1 1
           80  1 1
           88 -1 1
          199 -1 2
          142  1 2
           82 -1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear2_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear2_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear2_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear2_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear2_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..



cd Janni
cd Linear3
Orientation=2;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[ 2  1 1
           45  1 1
          115  1 1
          133 -1 2
          128 -1 2
          126  1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear3_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear3_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear3_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear3_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear3_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Janni
cd Linear4
Orientation=1;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[158  1 2
            83 -1 2
            42 -1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear4_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear4_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear4_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear4_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear4_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Janni
cd Linear5
Orientation=1;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[37 -1 1
          102  1 1
           16 -1 1
          129  1 2
          127  1 2
           78  1 2
            1  1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear5_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear5_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear5_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear5_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear5_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Janni
cd Linear6
Orientation=1;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[38 -1 1
          100 -1 1
           86  1 1
           71  1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear6_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear6_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear6_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear6_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Linear6_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Harpy
cd Linear1
Orientation=2;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[59 -1 1
          117 -1 2
           24 -1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Linear1_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Linear1_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Linear1_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Linear1_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Linear1_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Imp
cd Linear1
Orientation=2;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[66 -1 1
            4  1 1
           31 -1 2
           45 -1 2
            9  1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear1_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear1_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear1_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear1_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear1_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Imp
cd Linear2
Orientation=1;
load Spike_Data_With_Linear_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[32  1 1
           21 -1 1
            3 -1 1
            5 -1 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,3)==1
        Modality='Unimodal';
    elseif Cell_List(N,3)==2
        Modality='Bimodal';
    end
    
    SD=Restricted_Spike_Data(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    SI=Restricted_Spike_Information(Restricted_Spike_Data(:,2)==Current_Cell & Restricted_Spike_Information(:,4)>=10 & Restricted_Spike_Data(:,7)==Direction,:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SI(:,Orientation);SI(:,Orientation)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[min([0 180*Direction]) max([0 180*Direction])]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear2_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear2_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        bar(Field_Data_Linear_Out(:,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_Out,1)+0.5]);
    else
        bar(Field_Data_Linear_In(end:-1:1,Current_Cell),'k')
        set(gca,'XLim',[0.5 size(Field_Data_Linear_In,1)+0.5]);
    end
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear2_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        imagesc(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        imagesc(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear2_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    if Direction==1
        contour(Out_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(Out_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(Out_Smoothed_Position_Phase_Histograms,1)]);
    else
        contour(In_Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
        set(gca,'XLim',[1 size(In_Smoothed_Position_Phase_Histograms,2)]);
        set(gca,'YLim',[1 size(In_Smoothed_Position_Phase_Histograms,1)]);
    end
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Linear2_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..


cd Janni
cd Open1
load Spike_Data_With_Relative_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[27 1
           36 1
           37 1
           40 1
           43 1
           61 1
           76 1
            6 2
           11 2
           13 2
           28 2
           88 2
          131 2
          158 2
          195 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,2)==1
        Modality='Unimodal';
    elseif Cell_List(N,2)==2
        Modality='Bimodal';
    end
    
    SD=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=10 & ~isnan(Spike_Data(:,7)),:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SD(:,7);SD(:,7)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[-1 1]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open1_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open1_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Field_Data(:,:,Current_Cell));
    colormap('gray');
    set(gca,'YLim',[1 size(Field_Data,1)]);
    set(gca,'XLim',[1 size(Field_Data,2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open1_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open1_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    contour(Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open1_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..



cd Janni
cd Open2
load Spike_Data_With_Relative_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[29 1
           72 1
           14 2
           15 2
           99 2
           105 2
           109 2
           152 2
           176 2
           178 2
           192 2
           226 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,2)==1
        Modality='Unimodal';
    elseif Cell_List(N,2)==2
        Modality='Bimodal';
    end
    
    SD=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=10 & ~isnan(Spike_Data(:,7)),:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SD(:,7);SD(:,7)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[-1 1]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open2_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open2_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Field_Data(:,:,Current_Cell));
    colormap('gray');
    set(gca,'YLim',[1 size(Field_Data,1)]);
    set(gca,'XLim',[1 size(Field_Data,2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open2_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open2_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    contour(Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat1_Open2_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..





cd Harpy
cd Open1
load Spike_Data_With_Relative_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[131 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,2)==1
        Modality='Unimodal';
    elseif Cell_List(N,2)==2
        Modality='Bimodal';
    end
    
    SD=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=10 & ~isnan(Spike_Data(:,7)),:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SD(:,7);SD(:,7)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[-1 1]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Open1_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Open1_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Field_Data(:,:,Current_Cell));
    colormap('gray');
    set(gca,'YLim',[1 size(Field_Data,1)]);
    set(gca,'XLim',[1 size(Field_Data,2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Open1_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Open1_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    contour(Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat2_Open1_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..




cd Imp
cd Open1
load Spike_Data_With_Relative_Position;
load Field_Data;
load('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase');
Cell_List=[20 1
           63 1
           65 1
            5 2];
cd ..
cd ..

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure14','dir')==7
    cd SupplementalFigure14
else
    mkdir SupplementalFigure14
    cd SupplementalFigure14
end

for N=1:size(Cell_List,1)
    Current_Cell=Cell_List(N,1);
    Direction=Cell_List(N,2);
    if Cell_List(N,2)==1
        Modality='Unimodal';
    elseif Cell_List(N,2)==2
        Modality='Bimodal';
    end
    
    SD=Spike_Data(Spike_Data(:,2)==Current_Cell & Spike_Information(:,4)>=10 & ~isnan(Spike_Data(:,7)),:);
    figure;subplot('Position',[0 0 1 1]);hold on;
    plot([SD(:,7);SD(:,7)]*Direction,[SD(:,3);SD(:,3)+360],'.k','MarkerSize',10);
    set(gca,'XLim',[-1 1]);
    set(gca,'YLim',[0 720]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Open1_%s_Cell%d_Spikes.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    bar(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,4),Firing_Rate_Per_Phase(Current_Cell,:,4)],'k');
    plot(1:72,[Firing_Rate_Per_Phase(Current_Cell,:,5),Firing_Rate_Per_Phase(Current_Cell,:,5)],'r','LineWidth',8);
    Y_Lim=ylim;
    set(gca,'YLim',[0 Y_Lim(2)]);
    set(gca,'XLim',[0.5 72.5]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Open1_%s_Cell%d_Spikes_Per_Phase(Y=0to%d).jpg'');',Modality,Current_Cell,Y_Lim(2)));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Field_Data(:,:,Current_Cell));
    colormap('gray');
    set(gca,'YLim',[1 size(Field_Data,1)]);
    set(gca,'XLim',[1 size(Field_Data,2)]);
    set(gca,'XTick',[]);
    set(gca,'XTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Open1_%s_Cell%d_PlaceField.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    imagesc(Smoothed_Position_Phase_Histograms(:,:,Current_Cell));colormap('jet');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Open1_%s_Cell%d_Phase_Position_Heatmap.jpg'');',Modality,Current_Cell));
    close
    
    figure;subplot('Position',[0 0 1 1]);hold on;
    contour(Smoothed_Position_Phase_Histograms(:,:,Current_Cell),'k');
    set(gca,'XLim',[1 size(Smoothed_Position_Phase_Histograms,2)]);
    set(gca,'YLim',[1 size(Smoothed_Position_Phase_Histograms,1)]);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''Figure_S14_Rat3_Open1_%s_Cell%d_Phase_Position_Contour_Map.jpg'');',Modality,Current_Cell));
    close
end

cd ..
cd ..
cd ..

cd AllRatsCombined
load Combined_Single_Cell_Phase_Position_Significances
cd _Figures_For_Paper
cd SupplementalFigure14

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 1 1]);
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-1:0.1:1,Histogram/sum(Histogram),'k')
set(gca,'XLim',[-1 1]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 1 1]);
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-1:0.1:1,Histogram/sum(Histogram),'k')
set(gca,'XLim',[-1 1]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);



Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)<0),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Unimodal_Major_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)<0),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)<0),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Unimodal_Minor_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)<0),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)<0),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Bimodal_Major_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)<0),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level & All_Sig_Restricted(:,1)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)<0),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Bimodal_Minor_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)<0),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level & All_Sig_Restricted(:,3)>0)));
%close

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)<0),sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,2)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Unimodal_Major_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)<0),sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)<0),sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,4)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Unimodal_Minor_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)<0),sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)<0),sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,2)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Bimodal_Major_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)<0),sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level & All_Sig(:,1)>0)));
%close

figure;
hold on;
subplot('Position',[0 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)<0),sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)>0)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('jet')
subplot('Position',[0.5 0 0.5 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,4)>Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
%eval(sprintf('print(''-djpeg'',''Figure S14B_Bimodal_Minor_Window(Neg=%d,Pos=%d).jpg'');',sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)<0),sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level & All_Sig(:,3)>0)));
%close


cd ..
cd ..
cd ..




end

