function IRFS_PROCESS_PHASE_PRECESSION_VS_PROCESSION(Initial_Variables,Timepoints_To_Remove)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function uses the previously processed data and calculates the
% relationship between theta phase and location within a place field for
% Unimodal and Bimodal cells.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if 1%exist('Completed_Process_Phase_Precession_Vs_Procession.mat','file')~=2
            
            disp('--------------------------------------------------------------------------');
            disp(sprintf('Starting Quantification of Phase Precession and Procession for Rat: %s, Session: %s.',Rat_Name,Directory_Name));

            Spike_Position_Integration_Minimum_Time_Difference=Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference;
            Bin_Size=Initial_Variables.Bin_Size;
            Place_Field_Velocity_Cutoff=Initial_Variables.Place_Field_Velocity_Cutoff;
            Place_Field_Firing_Rate_Cutoff=Initial_Variables.Place_Field_Firing_Rate_Cutoff;
            Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
            Limit_Analysis_By_Theta_Length=Initial_Variables.Limit_Analysis_By_Theta_Length;
            Theta_Length_Min_Max=Initial_Variables.Theta_Length_Min_Max;
            Number_Of_Shuffles=Initial_Variables.Number_Of_Shuffles;
            Phase_Bin=Initial_Variables.Phase_Bin;
            Gaussian_Smoothing_Sigma=Initial_Variables.Gaussian_Smoothing_Sigma;
            Rayleigh_Test_P_Value_Cutoff=Initial_Variables.Rayleigh_Test_P_Value_Cutoff;
            Minimum_Place_Field_Firing_Rate_Fraction=Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction;
            Minimum_Contiguous_Place_Field_Bins=Initial_Variables.Minimum_Contiguous_Place_Field_Bins;
            Velocity_Cutoff=Initial_Variables.Velocity_Cutoff;
            Minimum_Spike_Count=Initial_Variables.Minimum_Spike_Count;
            Decoding_Time_Window=Initial_Variables.Decoding_Time_Window;
            Decoding_Time_Advance=Initial_Variables.Decoding_Time_Advance;
            Use_Maximum_Posterior_Probability=Initial_Variables.Use_Maximum_Posterior_Probability;
            
            Janni_Open2_To_Remove=Timepoints_To_Remove.Janni_Open2_To_Remove;
            Janni_Linear2_To_Remove=Timepoints_To_Remove.Janni_Linear2_To_Remove;
            Janni_Linear3_To_Remove=Timepoints_To_Remove.Janni_Linear3_To_Remove;
            Harpy_Linear1_To_Remove=Timepoints_To_Remove.Harpy_Linear1_To_Remove;
            Harpy_Linear2_To_Remove=Timepoints_To_Remove.Harpy_Linear2_To_Remove;
            Harpy_Linear3_To_Remove=Timepoints_To_Remove.Harpy_Linear3_To_Remove;
            Harpy_Open1_To_Remove=Timepoints_To_Remove.Harpy_Open1_To_Remove;
            Harpy_Open2_To_Remove=Timepoints_To_Remove.Harpy_Open2_To_Remove;
            Imp_Linear1_To_Remove=Timepoints_To_Remove.Imp_Linear1_To_Remove;
            Imp_Open1_To_Remove=Timepoints_To_Remove.Imp_Open1_To_Remove;
            Imp_Open2_To_Remove=Timepoints_To_Remove.Imp_Open2_To_Remove;
            
            disp('Loading Data.')
            IRFS_LOAD_DATA_FOR_PHASE_PRECESSION_PROCESSION_QUANTIFICATION;
            
            disp('Removing Identified Noisy Segments From Analysis.');
            % This removes noisy sections of the experiment and calculates the total duration of this experiment
            IRFS_REMOVE_NOISE_AND_CLEAN_DATA_FOR_ANALYSIS;
            
            disp('Calculating Phase-Position Relationship For Each Place Cell.')
            if strcmp(Directory_Name(1),'O')
                IRFS_CALCULATE_PHASE_POSITION_RELATIONSHIP(Spike_Data,Spike_Information,Modality,Position_Data,Field_Data,Initial_Variables);
            elseif strcmp(Directory_Name(1),'L')
                IRFS_CALCULATE_LINEAR_PHASE_POSITION_RELATIONSHIP(Spike_Data,Spike_Information,Position_Data,Field_Data_Linear_In,Field_Data_Linear_Out,Initial_Variables,Major_Peak_Window,Minor_Peak_Window);
            end
            
            disp('Quantifying Significance of Phase Pre-/Procession.')
            if strcmp(Directory_Name(1),'O')
                IRFS_CALCULATE_PHASE_POSITION_SIGNIFICANCE(Modality,Initial_Variables,Major_Peak_Window,Minor_Peak_Window);
            elseif strcmp(Directory_Name(1),'L')
                IRFS_CALCULATE_LINEAR_PHASE_POSITION_SIGNIFICANCE(Modality,Initial_Variables,Major_Peak_Window,Minor_Peak_Window);
            end
            
            Completed_Process_Phase_Precession_Vs_Procession=1;
            save('Completed_Process_Phase_Precession_Vs_Procession','Completed_Process_Phase_Precession_Vs_Procession');
            
            clearvars -except Rat Experiment Initial_Variables Timepoints_To_Remove Rats Directory Rat_Name Directory_Name Major_Peak_Window Minor_Peak_Window Forward_Window Reverse_Window
            
            disp(sprintf('Finished Quantification of Phase Precession and Procession for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            disp('--------------------------------------------------------------------------');
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

clear Rat
clear Experiment
clear Rats

disp('Combining and Saving Linear Track Phase Precession/Procession Quantification Across Rats and Sessions.')
IRFS_COMBINE_AND_SAVE_LINEAR_PHASE_PRE_PROCESSION(Initial_Variables,Major_Peak_Window,Minor_Peak_Window);
IRFS_COMBINE_AND_SAVE_OPENFIELD_PHASE_PRE_PROCESSION(Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

disp('Combining and Saving Individual Cell Phase Precession/Procession Significances.')
IRFS_COMBINE_AND_SAVE_INDIVIDUAL_CELL_SIGNIFICANCES;

if 1
    disp('Plotting Phase Precession/Procession Information Across Rats and Sessions.')
    IRFS_PLOT_FIGURE_THREE(Initial_Variables,Major_Peak_Window,Minor_Peak_Window);
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_FOURTEEN; %Currently plots more examples than used in the paper
end

if 1
    IRFS_PLOT_SUPPLEMENTAL_FIGURE_FIFTEEN;
end


clearvars -except Initial_Variables Timepoints_To_Remove

end

