function IRFS_QUANTIFY_THETA_PHASE_FOR_EVERY_SPIKE(Spike_Data,LFP_Theta)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the theta phase of each spike in the recording.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% This calculates the theta phase for every spike based on a single reference tetrode that is used for all spikes (this can take a long time)
LFP_Theta=LFP_Theta(LFP_Theta(:,1)>=min(Spike_Data(:,1)),:);
LFP_Theta=LFP_Theta(LFP_Theta(:,1)<=max(Spike_Data(:,1)),:);
Spike_Data(:,3:6)=0;
Spike_Data_Addition=zeros(size(Spike_Data,1),4);
if 1  %This is the MUCH slower method
    parfor N=1:size(Spike_Data,1)
        Index=abs(LFP_Theta(:,1)-Spike_Data(N,1))==min(abs(LFP_Theta(:,1)-Spike_Data(N,1)));
        if sum(Index)==1
            Spike_Data_Addition(N,:)=LFP_Theta(Index,[4,5,6,1]);
        else
            Spike_Data_Addition(N,:)=LFP_Theta(find(abs(LFP_Theta(:,1)-Spike_Data(N,1))==min(abs(LFP_Theta(:,1)-Spike_Data(N,1))),1,'first'),[4,5,6,1]);
        end
    end
    clear Index;
else  %This is the MUCH faster method
    Histogram=histc(LFP_Theta(:,1),Spike_Data(:,1));
    Temp_Spike_Times_In_LFP_Time=cumsum(Histogram(1:end),1);
    Temp_Spike_Times_In_LFP_Time(Temp_Spike_Times_In_LFP_Time==0)=1;
    Index=Temp_Spike_Times_In_LFP_Time;
    for N=1:size(Spike_Data,1)
        LT=LFP_Theta(max([1,(Index(N)-1000)]):min([size(LFP_Theta,1),(Index(N)+1000)]),:);
        Spike_Data_Addition(N,:)=LT(find(abs(LT-Spike_Data(N,1))==min(abs(LT-Spike_Data(N,1))),1,'first'),[4,5,6,1]);
    end
    clear N;
    clear LT;
    clear Histogram;
    clear Temp_Spike_Times_In_LFP_Time;
    clear Index;
end
Spike_Data(:,3:6)=Spike_Data_Addition;
clear Spike_Data_Addition;
save('Spike_Data_With_Theta_Phase','Spike_Data');


end

