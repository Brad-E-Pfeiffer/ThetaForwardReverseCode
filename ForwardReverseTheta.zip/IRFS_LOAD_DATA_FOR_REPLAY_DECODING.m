% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script loads the necessary files (many produced by the
% PROCESS_RAW_DATA and PROCESS_UNIMODAL_VS_BIMODAL_FIRING functions) for
% Bayesian decoding and analysis of the content of theta sequences.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Spike_Data
load Spike_Information
load Position_Data_Processed
load Field_Data
load Modality
load Ripple_Events



