% This makes all example figures and pie chart figures for Supplemental
% Figure S9.

Phase_Bin=Initial_Variables.Phase_Bin;

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Spike_Properties
        load Modality
        load Spike_Data
        All_Modality(:,3)=1;
        for N=1:length(Inhibitory_Neurons)
            All_Modality(All_Modality(:,2)==Inhibitory_Neurons(N),3)=0;
        end
        
        if exist('Unimodal_Spike_Properties','var')
            Unimodal_Spike_Properties=[Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
            Bimodal_Spike_Properties=[Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
            Inhibitory_Spike_Properties=[Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
        else
            Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
            Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
            Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
        end
        
        if strcmp(Directory_Name(1),'L')
            if exist('Linear_Unimodal_Spike_Properties','var')
                Linear_Unimodal_Spike_Properties=[Linear_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                Linear_Bimodal_Spike_Properties=[Linear_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                Linear_Inhibitory_Spike_Properties=[Linear_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                Linear_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                Linear_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                Linear_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        else
            if exist('OpenField_Unimodal_Spike_Properties','var')
                OpenField_Unimodal_Spike_Properties=[OpenField_Unimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Bimodal_Spike_Properties=[OpenField_Bimodal_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:)];
                OpenField_Inhibitory_Spike_Properties=[OpenField_Inhibitory_Spike_Properties;Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:)];
            else
                OpenField_Unimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==1 & All_Modality(:,3)==1,2),:,:);
                OpenField_Bimodal_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,1)==2 & All_Modality(:,3)==1,2),:,:);
                OpenField_Inhibitory_Spike_Properties=Average_Spike_Properties_Per_Cell(All_Modality(All_Modality(:,3)==0,2),:,:);
            end
        end
        
        cd ..
        
    end
    clear Directory
    cd ..
    
end

cd AllRatsCombined
load Cell_Modality_Information
if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir('_Figures_For_Paper')
    cd _Figures_For_Paper
end

if exist('SupplementalFigure9','dir')==7
    cd SupplementalFigure9
else
    mkdir('SupplementalFigure9')
    cd SupplementalFigure9
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Open1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Open1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Open1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Open1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Open2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Open2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Open2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Open2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear3_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear3_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear3_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear3_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear4_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear4_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear4_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear4_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear5_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear5_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear5_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear5_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Janni_Linear6_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Janni_Linear6_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Janni_Linear6_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_Linear6_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Harpy_Open1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Harpy_Open1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Harpy_Open1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_Open1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Harpy_Open2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Harpy_Open2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Harpy_Open2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_Open2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Harpy_Linear1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Harpy_Linear1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Harpy_Linear1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_Linear1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Harpy_Linear2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Harpy_Linear2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Harpy_Linear2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_Linear2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Imp_Open1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Imp_Open1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Imp_Open1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_Open1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Imp_Open2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Imp_Open2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Imp_Open2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_Open2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Imp_Linear1_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Imp_Linear1_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Imp_Linear1_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_Linear1_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Unimodal_Cell_Count=length(find(Imp_Linear2_Modality(:,1)==1));
Bimodal_Cell_Count=length(find(Imp_Linear2_Modality(:,1)==2));
Multimodal_Cell_Count=length(find(Imp_Linear2_Modality(:,1)==3));
Pie_Chart=pie([Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count]);
set(Pie_Chart(1),'FaceColor','r')
set(Pie_Chart(3),'FaceColor','b')
if Multimodal_Cell_Count>0
    set(Pie_Chart(5),'FaceColor','w')
end
set(gca,'XTick',[]);
set(gca,'YTick',[]);
delete(findobj(Pie_Chart,'Type','text'));
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_Linear2_(Unimodal=%d;Bimodal=%d,Multimodal=%d).jpg'');',Unimodal_Cell_Count,Bimodal_Cell_Count,Multimodal_Cell_Count));
close
clear Unimodal_Cell_Count;
clear Bimodal_Cell_Count;
clear Multimodal_Cell_Count;
clear Low_Spike_Cell_Count;
clear Pie_Chart;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(37,:,4),Janni_Open2_Firing_Rate_Per_Phase(37,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(37,:,5),Janni_Open2_Firing_Rate_Per_Phase(37,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell38_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(58,:,4),Janni_Open2_Firing_Rate_Per_Phase(58,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(58,:,5),Janni_Open2_Firing_Rate_Per_Phase(58,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell59_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(127,:,4),Janni_Open2_Firing_Rate_Per_Phase(127,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(127,:,5),Janni_Open2_Firing_Rate_Per_Phase(127,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell129_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(15,:,4),Janni_Open2_Firing_Rate_Per_Phase(15,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(15,:,5),Janni_Open2_Firing_Rate_Per_Phase(15,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell15_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(154,:,4),Janni_Open2_Firing_Rate_Per_Phase(154,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(154,:,5),Janni_Open2_Firing_Rate_Per_Phase(154,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell158_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Open2_Firing_Rate_Per_Phase(180,:,4),Janni_Open2_Firing_Rate_Per_Phase(180,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Open2_Firing_Rate_Per_Phase(180,:,5),Janni_Open2_Firing_Rate_Per_Phase(180,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_OpenField_Cell186_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(74,:,4),Janni_Linear2_Firing_Rate_Per_Phase(74,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(74,:,5),Janni_Linear2_Firing_Rate_Per_Phase(74,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell75_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(108,:,4),Janni_Linear2_Firing_Rate_Per_Phase(108,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(108,:,5),Janni_Linear2_Firing_Rate_Per_Phase(108,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell109_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(119,:,4),Janni_Linear2_Firing_Rate_Per_Phase(119,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(119,:,5),Janni_Linear2_Firing_Rate_Per_Phase(119,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell1120_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(30,:,4),Janni_Linear2_Firing_Rate_Per_Phase(30,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(30,:,5),Janni_Linear2_Firing_Rate_Per_Phase(30,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell30_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(163,:,4),Janni_Linear2_Firing_Rate_Per_Phase(163,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(163,:,5),Janni_Linear2_Firing_Rate_Per_Phase(163,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell165_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Janni_Linear2_Firing_Rate_Per_Phase(197,:,4),Janni_Linear2_Firing_Rate_Per_Phase(197,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Janni_Linear2_Firing_Rate_Per_Phase(197,:,5),Janni_Linear2_Firing_Rate_Per_Phase(197,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat1_LinearTrack_Cell200_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(74,:,4),Harpy_Open1_Firing_Rate_Per_Phase(74,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(74,:,5),Harpy_Open1_Firing_Rate_Per_Phase(74,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell75_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(137,:,4),Harpy_Open1_Firing_Rate_Per_Phase(137,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(137,:,5),Harpy_Open1_Firing_Rate_Per_Phase(137,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell142_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(148,:,4),Harpy_Open1_Firing_Rate_Per_Phase(148,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(148,:,5),Harpy_Open1_Firing_Rate_Per_Phase(148,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell154_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(86,:,4),Harpy_Open1_Firing_Rate_Per_Phase(86,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(86,:,5),Harpy_Open1_Firing_Rate_Per_Phase(86,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell87_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(117,:,4),Harpy_Open1_Firing_Rate_Per_Phase(117,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(117,:,5),Harpy_Open1_Firing_Rate_Per_Phase(117,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell120_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Open1_Firing_Rate_Per_Phase(174,:,4),Harpy_Open1_Firing_Rate_Per_Phase(174,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Open1_Firing_Rate_Per_Phase(174,:,5),Harpy_Open1_Firing_Rate_Per_Phase(174,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_OpenField_Cell181_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(29,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(29,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(29,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(29,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell30_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(116,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(116,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(116,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(116,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell121_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(123,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(123,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(123,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(123,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell129_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(20,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(20,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(20,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(20,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell20_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(92,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(92,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(92,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(92,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell95_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Harpy_Linear1_Firing_Rate_Per_Phase(112,:,4),Harpy_Linear1_Firing_Rate_Per_Phase(112,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Harpy_Linear1_Firing_Rate_Per_Phase(112,:,5),Harpy_Linear1_Firing_Rate_Per_Phase(112,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat2_LinearTrack_Cell117_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(17,:,4),Imp_Open2_Firing_Rate_Per_Phase(17,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(17,:,5),Imp_Open2_Firing_Rate_Per_Phase(17,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell17_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(68,:,4),Imp_Open2_Firing_Rate_Per_Phase(68,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(68,:,5),Imp_Open2_Firing_Rate_Per_Phase(68,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell69_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(71,:,4),Imp_Open2_Firing_Rate_Per_Phase(71,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(71,:,5),Imp_Open2_Firing_Rate_Per_Phase(71,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell72_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(4,:,4),Imp_Open2_Firing_Rate_Per_Phase(4,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(4,:,5),Imp_Open2_Firing_Rate_Per_Phase(4,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell4_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(15,:,4),Imp_Open2_Firing_Rate_Per_Phase(15,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(15,:,5),Imp_Open2_Firing_Rate_Per_Phase(15,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell15_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Open2_Firing_Rate_Per_Phase(59,:,4),Imp_Open2_Firing_Rate_Per_Phase(59,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Open2_Firing_Rate_Per_Phase(59,:,5),Imp_Open2_Firing_Rate_Per_Phase(59,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_OpenField_Cell60_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(5,:,4),Imp_Linear1_Firing_Rate_Per_Phase(5,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(5,:,5),Imp_Linear1_Firing_Rate_Per_Phase(5,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell6_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(54,:,4),Imp_Linear1_Firing_Rate_Per_Phase(54,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(54,:,5),Imp_Linear1_Firing_Rate_Per_Phase(54,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell60_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(55,:,4),Imp_Linear1_Firing_Rate_Per_Phase(55,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(55,:,5),Imp_Linear1_Firing_Rate_Per_Phase(55,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell61_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(8,:,4),Imp_Linear1_Firing_Rate_Per_Phase(8,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(8,:,5),Imp_Linear1_Firing_Rate_Per_Phase(8,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell9_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(31,:,4),Imp_Linear1_Firing_Rate_Per_Phase(31,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(31,:,5),Imp_Linear1_Firing_Rate_Per_Phase(31,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell35_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Data=[Imp_Linear1_Firing_Rate_Per_Phase(32,:,4),Imp_Linear1_Firing_Rate_Per_Phase(32,:,4)];
bar(Phase_Bin:Phase_Bin:Phase_Bin*length(Data),Data,'k')
Line=[Imp_Linear1_Firing_Rate_Per_Phase(32,:,5),Imp_Linear1_Firing_Rate_Per_Phase(32,:,5)];
plot(Phase_Bin:Phase_Bin:Phase_Bin*length(Line),Line,'r','LineWidth',8)
set(gca,'XLim',[Phase_Bin-(Phase_Bin/2) Phase_Bin*length(Line)+(Phase_Bin/2)]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''FigureS9B_Rat3_LinearTrack_Cell36_(X=0to720)(Y=0to%d).jpg'');',Y_Lim(2)));
close;
clear Data;
clear Line;
clear Y_Lim;

cd ..
cd ..
cd ..

