load L_Ratios
load Spike_Data;
if exist('Position_Data_Processed.mat','file')==2
    load Position_Data_Processed;
else
    load Position_Data
    Position_Data(:,2)=Position_Data(:,2)-min(Position_Data(:,2))+0.001;
    Position_Data(:,3)=Position_Data(:,3)-min(Position_Data(:,3))+0.001;
    % Calculate the rat's velocity across Position_Data
    Position_Data(:,5)=IRFS_CALCULATE_VELOCITY(Position_Data);
    %Calculate the movement direction
    Position_Data(:,6)=0;
    for N=2:size(Position_Data,1)
        X_Diff=Position_Data(N,2)-Position_Data((N-1),2);
        Y_Diff=Position_Data(N,3)-Position_Data((N-1),3);
        if Y_Diff==0 && X_Diff>0
            Angle=270;
        elseif Y_Diff==0 && X_Diff<0
            Angle=90;
        elseif X_Diff==0 && Y_Diff>0
            Angle=180;
        elseif X_Diff==0 && Y_Diff<0
            Angle=360;
        elseif X_Diff>0 && Y_Diff>0
            Angle=180+atand(abs(X_Diff)/abs(Y_Diff));
        elseif X_Diff>0 && Y_Diff<0
            Angle=270+abs(atand(abs(Y_Diff)/abs(X_Diff)));
        elseif X_Diff<0 && Y_Diff>0
            Angle=90+abs(atand(abs(Y_Diff)/abs(X_Diff)));
        elseif X_Diff<0 && Y_Diff<0
            Angle=atand(abs(X_Diff)/abs(Y_Diff));
        else
            Angle=0;
        end
        %Angle=Angle+180;  %This makes the head direction and movement direction 180 degrees off for most of the recording for troubleshooting purposes.
        if Angle>360
            Angle=Angle-360;
        end
        Position_Data(N,6)=Angle;
    end
    Position_Data(1,6)=Position_Data(2,6);
    % Calculate the time steps across adjacent Position_Data data points (for quantifying total experiment duration)
    Position_Data(2:end,7)=diff(Position_Data(:,1));
    Position_Data(1,7)=Position_Data(2,7);
    Position_Data(Position_Data(:,7)>60,7)=0; %This makes the program not count large gaps (such as between multiple sessions in the same recording) as counting toward the total experiment duration
    clear N;
    clear X_Diff;
    clear Y_Diff;
    clear Angle;
    save('Position_Data_Processed','Position_Data');
end