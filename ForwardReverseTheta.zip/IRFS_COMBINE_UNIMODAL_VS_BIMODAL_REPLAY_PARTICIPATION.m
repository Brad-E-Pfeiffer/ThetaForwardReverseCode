function IRFS_COMBINE_UNIMODAL_VS_BIMODAL_REPLAY_PARTICIPATION(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads up the previously processed and saved unimodal and
% bimodal data as it relates to ripple/replay stats and combines it.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Ripple_Spike_Correlations
        
        eval(sprintf('%s_%s_Ripple_Spike_Ratios=Bimodal_Unimodal_All_Ripples_Overall_Ratios;',Rats(Rat).name,Directory_Name));
        
        if exist('All_Ripple_Spike_Ratios','var')==1
            All_Ripple_Spike_Ratios=[All_Ripple_Spike_Ratios;Bimodal_Unimodal_All_Ripples_Overall_Ratios];
        else
            All_Ripple_Spike_Ratios=Bimodal_Unimodal_All_Ripples_Overall_Ratios;
        end
        
        if strcmp(Directory_Name(1),'L')
            eval(sprintf('%s_%s_Replay_Spike_Ratios=Bimodal_Unimodal_All_Replay_Overall_Ratios;',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Forward_Replay_Spike_Ratios=Bimodal_Unimodal_Forward_Replay_Overall_Ratios;',Rats(Rat).name,Directory_Name));
            eval(sprintf('%s_%s_Reverse_Replay_Spike_Ratios=Bimodal_Unimodal_Reverse_Replay_Overall_Ratios;',Rats(Rat).name,Directory_Name));
            if exist('All_Replay_Spike_Ratios','var')==1
                All_Replay_Spike_Ratios=[All_Replay_Spike_Ratios;Bimodal_Unimodal_All_Replay_Overall_Ratios];
                All_Forward_Replay_Spike_Ratios=[All_Forward_Replay_Spike_Ratios;Bimodal_Unimodal_Forward_Replay_Overall_Ratios];
                All_Reverse_Replay_Spike_Ratios=[All_Reverse_Replay_Spike_Ratios;Bimodal_Unimodal_Reverse_Replay_Overall_Ratios];
            else
                All_Replay_Spike_Ratios=Bimodal_Unimodal_All_Replay_Overall_Ratios;
                All_Forward_Replay_Spike_Ratios=Bimodal_Unimodal_Forward_Replay_Overall_Ratios;
                All_Reverse_Replay_Spike_Ratios=Bimodal_Unimodal_Reverse_Replay_Overall_Ratios;
            end
        end
        cd ..
    end
    cd ..
    clear Directory
end
clear Rat;
clear Rat_Name;
clear Experiment;

clearvars -except Initial_Variables Timepoints_To_Remove Janni_* Harpy_* Imp_* All_*

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

save('Unimodal_Bimodal_Ripple_Replay_Participation');

cd ..
        
        
