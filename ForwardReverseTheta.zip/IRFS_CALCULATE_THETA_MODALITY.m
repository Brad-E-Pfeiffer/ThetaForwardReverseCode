% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This script quantifies whether a neuron's firing rate relative to the
% theta oscillation is unimodal, bimodal, non-modal, or multimodal.  It
% first performs a Rayleigh test for circular uniformity.  If the neuron is
% not uniform, then the program makes a histogram of spikes as a function
% of theta phase, filters that, and looks for meaningful peaks in that
% smoothed histogram.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Modality
% |     1    |    2    |
% | Modality | Cell ID |
% Modality lists whether a cell is Unimodal (1), Bimodal (2), Multi-modal (3), or Non-Modal (-1), or Too Few Spikes To Classify (0)
% 
% Modality_Peaks -- Each row is a neuron, each column is a quantified peak in firing, page 1 is the Peak Value, page 2 is the phase of the peak firing

Neuron_List=zeros(max(Spike_Data(:,2)),1);
Neuron_List(Excitatory_Neurons(Excitatory_Neurons<=length(Neuron_List)),1)=1;
Rayleigh_Test=zeros(max(Spike_Data(:,2)),2);
Modality=zeros(max(Spike_Data(:,2)),2);
Modality(:,2)=1:max(Spike_Data(:,2));
Modality_Peaks=zeros(max(Spike_Data(:,2)),1,2);
for N=1:max(Spike_Data(:,2))
    if sum(Spike_Data(:,2)==N)>=1
        [Rayleigh_Test(N,1),Rayleigh_Test(N,2)]=circ_rtest(deg2rad(Spike_Data(Spike_Data(:,2)==N,3)));
    else
        Rayleigh_Test(N,:)=[1,1000];
    end
    F=[Firing_Rate_Per_Phase(N,:,3),Firing_Rate_Per_Phase(N,:,3)];
    [Peaks,Peak_Phases]=findpeaks(F,'MinPeakHeight',max(F)/10,'MinPeakDistance',round(50/Phase_Bin),'MinPeakProminence',0.05,'MinPeakWidth',round(30/Phase_Bin),'WidthReference','halfheight');
    Peak_Phases(Peak_Phases>round(360/Phase_Bin))=Peak_Phases(Peak_Phases>round(360/Phase_Bin))-round(360/Phase_Bin);
    Peak_Phases=Peak_Phases*Phase_Bin;
    Peak_Data=[Peaks',Peak_Phases'];
    [~,Index,~]=unique(Peak_Data(:,2));
    Peak_Data=Peak_Data(Index,:);
    Peak_Data=flipud(sortrows(Peak_Data,1));
    if size(Peak_Data,1)==1 && Rayleigh_Test(N,1)<=Rayleigh_Test_P_Value_Cutoff
        Modality(N,1)=1;
        Modality_Peaks(N,1,1)=Peak_Data(1,1);
        Modality_Peaks(N,1,2)=Peak_Data(1,2);
    elseif size(Peak_Data,1)==2 && Rayleigh_Test(N,1)<=Rayleigh_Test_P_Value_Cutoff
        Modality(N,1)=2;
        Modality_Peaks(N,1:size(Peak_Data,1),1)=(Peak_Data(:,1))';
        Modality_Peaks(N,1:size(Peak_Data,1),2)=(Peak_Data(:,2))';
    elseif size(Peak_Data,1)>2 && Rayleigh_Test(N,1)<=Rayleigh_Test_P_Value_Cutoff
        Modality(N,1)=3;
    elseif max(F)==0
        Modality(N,1)=0;
    else
        Modality(N,1)=-1;
    end
    clear F;
    clear Index;
    clear Peaks;
    clear Peak_Data;
    clear Peak_Phases;
end
clear N;

% This calculates the phase-locked firing for the population
% Row 1 is raw firing rate; row 2 is smoothed firing rate; row 3 is Firing Rate Index 
% First page is mean of all neurons, second page is SEM

%"All" means all excitatory neurons
Mean_Firing_Rate_Per_Phase_All=zeros(3,size(Firing_Rate_Per_Phase,2),2);
Mean_Firing_Rate_Per_Phase_All(1,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==1,:,1),1);
Mean_Firing_Rate_Per_Phase_All(2,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==1,:,2),1);
Mean_Firing_Rate_Per_Phase_All(3,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==1,:,3),1);
if length(find(Neuron_List==1))>1
    Mean_Firing_Rate_Per_Phase_All(1,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==1,:,1))/sqrt(length(find(Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_All(2,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==1,:,2))/sqrt(length(find(Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_All(3,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==1,:,3))/sqrt(length(find(Neuron_List==1)));
end
Mean_Firing_Rate_Per_Phase_Unimodal=zeros(3,size(Firing_Rate_Per_Phase,2),2);
Mean_Firing_Rate_Per_Phase_Unimodal(1,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,1),1);
Mean_Firing_Rate_Per_Phase_Unimodal(2,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,2),1);
Mean_Firing_Rate_Per_Phase_Unimodal(3,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,3),1);
if length(find(Modality(:,1)==1 & Neuron_List==1))>1
    Mean_Firing_Rate_Per_Phase_Unimodal(1,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,1))/sqrt(length(find(Modality(:,1)==1 & Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_Unimodal(2,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,2))/sqrt(length(find(Modality(:,1)==1 & Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_Unimodal(3,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==1 & Neuron_List==1,:,3))/sqrt(length(find(Modality(:,1)==1 & Neuron_List==1)));
end
Mean_Firing_Rate_Per_Phase_Bimodal=zeros(3,size(Firing_Rate_Per_Phase,2),2);
Mean_Firing_Rate_Per_Phase_Bimodal(1,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,1),1);
Mean_Firing_Rate_Per_Phase_Bimodal(2,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,2),1);
Mean_Firing_Rate_Per_Phase_Bimodal(3,:,1)=mean(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,3),1);
if length(find(Modality(:,1)==2 & Neuron_List==1))>1
    Mean_Firing_Rate_Per_Phase_Bimodal(1,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,1))/sqrt(length(find(Modality(:,1)==2 & Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_Bimodal(2,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,2))/sqrt(length(find(Modality(:,1)==2 & Neuron_List==1)));
    Mean_Firing_Rate_Per_Phase_Bimodal(3,:,2)=std(Firing_Rate_Per_Phase(Modality(:,1)==2 & Neuron_List==1,:,3))/sqrt(length(find(Modality(:,1)==2 & Neuron_List==1)));
end
Mean_Firing_Rate_Per_Phase_Inhibitory=zeros(3,size(Firing_Rate_Per_Phase,2),2);
Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==0,:,1),1);
Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==0,:,2),1);
Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,1)=mean(Firing_Rate_Per_Phase(Neuron_List==0,:,3),1);
if length(find(Neuron_List==0))>1
    Mean_Firing_Rate_Per_Phase_Inhibitory(1,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==0,:,1))/sqrt(length(find(Neuron_List==0)));
    Mean_Firing_Rate_Per_Phase_Inhibitory(2,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==0,:,2))/sqrt(length(find(Neuron_List==0)));
    Mean_Firing_Rate_Per_Phase_Inhibitory(3,:,2)=std(Firing_Rate_Per_Phase(Neuron_List==0,:,3))/sqrt(length(find(Neuron_List==0)));
end

Unimodal_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase(Neuron_List==1 & Modality(:,1)==1,:,:);
Bimodal_Firing_Rate_Per_Phase=Firing_Rate_Per_Phase(Neuron_List==1 & Modality(:,1)==2,:,:);

save('Modality','Modality','Rayleigh_Test','Neuron_List','Modality_Peaks')
save('Firing_Rate_Per_Phase','Firing_Rate_Per_Phase','Mean_Firing_Rate_Per_Phase_All','Mean_Firing_Rate_Per_Phase_Unimodal','Mean_Firing_Rate_Per_Phase_Bimodal','Mean_Firing_Rate_Per_Phase_Inhibitory','Unimodal_Firing_Rate_Per_Phase','Bimodal_Firing_Rate_Per_Phase')

