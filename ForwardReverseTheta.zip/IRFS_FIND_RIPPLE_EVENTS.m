function SEQDEV_FIND_RIPPLE_EVENTS(Initial_Variables,Timepoints_To_Remove,Rat_Name,Directory_Name,Tetrode_Cell_IDs,Position_Data,Spike_Data,Inhibitory_Neurons)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the raw LFP data, filters it in the ripple frequency
% band, and finds the average ripple power across all tetrodes with
% identified units.  It then identifies changes in the ripple power that
% meet the criteria for a ripple.
%
% Ripple_Events
% |     1      |    2     |     3     |
% | Start Time | End Time | Peak Time | 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% First, I define electrodes that are 'bad'.  The spike data from these
% electrodes is fine, but I didn't set the LFP bounds correctly and a
% resonably large number of datapoints are max'd or min'd out and so we
% won't use them to quantify ripples.
Bad_Electrodes.Janni_Open1=[81,85,89,93,117,129,133,137,141,145,149,153];
Bad_Electrodes.Janni_Open2=[5,13,65,74,77,81,85,89,93,117,129,133,137,141,145,149,153];
Bad_Electrodes.Harpy_Open1=[2,10,33,46,63,65,75,78,81,85,96,99,102,106,109,113,117,121,125,139,142,145,155,160];
Bad_Electrodes.Harpy_Open2=[2,10,21,33,42,46,52,63,90,96,99,102,106,117,160];
Bad_Electrodes.Imp_Open1=[22,33,40,50,53,77,89,93,113,146,152];
Bad_Electrodes.Imp_Open2=[6,22,26,29,33,40,43,48,50,53,65,72,75,77,89,113,146,152,154,159];

% This identifies which tetrodes had excitatory neurons recorded on that
% tetrode -- I will only use these tetrodes to identify ripples since I
% know those are in the hippocampal pyramidal layer.
disp('Loading each LFP and filtering in ripple frequency band.');
for N=1:length(Inhibitory_Neurons)
    Tetrode_Cell_IDs=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,2)~=Inhibitory_Neurons(N),:);
end
Tetrodes_To_Use=unique(Tetrode_Cell_IDs(:,1));  %These are the tetrodes with excitatory cells recorded on them

Current_Working_Directory=pwd;
eval(sprintf('Raw_LFP_Directory=''%s\\%s\\%s'';',Initial_Variables.Raw_LFP_Root_Directory,Rat_Name,Directory_Name));
cd(Raw_LFP_Directory)

%This finds the electrode numbers for all the raw LFP traces to use
Directory_List=dir;
for N=1:size(Directory_List,1)
    for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if you have more channels, increase this number accordingly
        Comparison_String=sprintf('CSC%d.ncs',M);
        if strcmp(Directory_List(N).name,Comparison_String) && sum(Tetrodes_To_Use==ceil(M/4))>0  %Only include tetrodes that had excitatory cells recorded on them
            if exist('LFP_Electrodes','var')
                LFP_Electrodes=[LFP_Electrodes;M];
            else
                LFP_Electrodes=M;
            end
        end
        clear Comparison_String;
    end
end
if ~exist('LFP_Electrodes','var')
    error('ERROR! No CSC files were identified in the listed load directory.')
end
LFP_Electrodes=unique(LFP_Electrodes);

%This prepares the ripple filter
LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);
clear M;
clear N;
clear Directory_List;
clear LFP_Filename;
Ripple_Stop_Low=130;
Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
Ripple_Pass_High=250;
Ripple_Stop_High=275;
Stop_Band_Attenuation_One=60;    % This was the default, I think.
Pass_Band=1;                     % This was the default, I think.
Stop_Band_Attenuation_Two=80;    % This was the default, I think.
Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

%Due to technical issues, some electrodes skipped data points during the recording -- this ensures that all tetrodes used have the same number of data points
%(Another option would be to try to specifically align each tetrode, but that would be very challenging with little benefit.) 
LFP_Lengths=zeros(length(LFP_Electrodes),1);
for Current_Electrode=1:length(LFP_Electrodes)
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(Current_Electrode));
    LFP_Lengths(Current_Electrode,1)=length(Nlx2MatCSC(LFP_Filename,[1 0 0 0 0],0,1));
end
LFP_Length=max(LFP_Lengths);
%This loads each raw LFP and filters it in the ripple frequency band
Number_Of_Used_Electrodes=0;
for Current_Electrode=1:length(LFP_Electrodes)
    if eval(sprintf('sum(Bad_Electrodes.%s_%s==LFP_Electrodes(Current_Electrode))==0',Rat_Name,Directory_Name))
        Electrode_Name=sprintf('CSC%d.ncs',LFP_Electrodes(Current_Electrode));
        LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
        for Header_Line=1:length(LFP_Header)
            Header_Info=cell2mat(LFP_Header(Header_Line));
            if length(Header_Info)>12
                if strcmp(Header_Info(1:11),'-ADMaxValue')
                    Max_Value=str2double(Header_Info(13:end));
                end
                if strcmp(Header_Info(1:11),'-InputRange')
                    Max_Range=str2double(Header_Info(13:end));
                end
            end
        end
        LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
        if length(LFP_Times)==LFP_Length
            Number_Of_Used_Electrodes=Number_Of_Used_Electrodes+1;
            Times=zeros(512,size(LFP_Times,2));
            for B=1:length(LFP_Times)-1
                Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
            end
            Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
            clear B;
            clear LFP_Times;
            Times=Times(:);
            LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
            LFP_Samples=LFP_Samples(:);
            LFP_Data=[Times,LFP_Samples];
            LFP_Data=LFP_Data(LFP_Data(:,1)>=(max([min(Position_Data(:,1)),min(Spike_Data(:,1))])-100) & LFP_Data(:,1)<=(min([max(Position_Data(:,1)),max(Spike_Data(:,1))])+100),:);  %This restricts ripple analysis to only the run portion of the recording
            LFP_Data(:,2)=LFP_Data(:,2)*(Max_Range/Max_Value);  %Converts from bits to volts
            eval(sprintf('LFP%d=LFP_Data;',LFP_Electrodes(Current_Electrode)));
            clear Times;
            clear LFP_Samples;
            clear Max_Range;
            clear Max_Value;
            Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
            Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
            Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
            Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
            Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
            Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
            Ripple_Filtered_LFP_Data(:,3)=hilbert(Ripple_Filtered_LFP_Data(:,2));
            Ripple_Filtered_LFP_Data(:,4)=(angle(Ripple_Filtered_LFP_Data(:,3))*180/pi)+180;
            Ripple_Filtered_LFP_Data(:,3)=abs(Ripple_Filtered_LFP_Data(:,3));
            Ripple_Gaussian_Filter=fspecial('gaussian',[round(7*(12.5/((1/LFP_Frequency)*1000))),1],round(12.5/((1/LFP_Frequency)*1000)));  %sigma of 12.5 ms
            Ripple_Filtered_LFP_Data(:,3)=filtfilt(Ripple_Gaussian_Filter,1,Ripple_Filtered_LFP_Data(:,3));
            eval(sprintf('Ripple%d=Ripple_Filtered_LFP_Data;',LFP_Electrodes(Current_Electrode)));
            clear Ripple_Gaussian_Filter;
            %This adds the ripple power of each trace together
            if exist('Ripple_LFP','var')
                Ripple_LFP(:,2)=Ripple_LFP(:,2)+Ripple_Filtered_LFP_Data(:,3);
            else
                Ripple_LFP=Ripple_Filtered_LFP_Data(:,[1,3]);
            end
            clear LFP_Data;
            clear Ripple_Filtered_LFP_Data;
        end
    end
end

%This removes noisy sections
if eval(sprintf('isfield(Timepoints_To_Remove,''%s_%s_To_Remove'')',Rat_Name,Directory_Name))
    eval(sprintf('Sections_To_Remove=Timepoints_To_Remove.%s_%s_To_Remove;',Rat_Name,Directory_Name));
    for Section=1:size(Sections_To_Remove,1)
        Ripple_LFP=Ripple_LFP(Ripple_LFP(:,1)<Sections_To_Remove(Section,1) | Ripple_LFP(:,1)>Sections_To_Remove(Section,2),:);
    end
    clear Section
end
clear Sections_To_Remove

%This normalizes the ripple power by the number of electrodes used
Ripple_Amplitude=Ripple_LFP(:,2)/Number_Of_Used_Electrodes;

%This finds the rat's velocity at every LFP timepoint
Ripple_Amplitude(:,2)=0;
parfor N=1:size(Ripple_Amplitude,1)
    Index=abs(Position_Data(:,1)-Ripple_LFP(N,1))==min(abs(Position_Data(:,1)-Ripple_LFP(N,1)));
    if sum(Index)>1
        Index=find(abs(Position_Data(:,1)-Ripple_LFP(N,1))==min(abs(Position_Data(:,1)-Ripple_LFP(N,1))),1,'first');
    end
    Ripple_Amplitude(N,2)=Position_Data(Index,5);
end

%This finds the mean and std of the ripple power only during periods of immobility
Mean_Ripple_Amplitude=mean(Ripple_Amplitude(Ripple_Amplitude(:,2)<Initial_Variables.Place_Field_Velocity_Cutoff,1));
STD_Ripple_Amplitude=std(Ripple_Amplitude(Ripple_Amplitude(:,2)<Initial_Variables.Place_Field_Velocity_Cutoff,1));
[~,Locations]=findpeaks(Ripple_Amplitude(:,1),'minpeakheight',Mean_Ripple_Amplitude+(STD_Ripple_Amplitude*3));  %Finds all ripple amplitude peaks 3 StDevs above the mean
Locations=Locations(Ripple_Amplitude(Locations,2)<Initial_Variables.Place_Field_Velocity_Cutoff);  %Eliminates ripple power peaks that occurred when the rat was moving

% This finds the start and end timepoints for each event.

% Ripple_Events
% |     1      |    2     |     3     |
% | Start Time | End Time | Peak Time | 

Ripple_Events=zeros(length(Locations),3);
Ripple_Events(:,3)=Ripple_LFP(Locations,1);
for N=1:size(Ripple_Events,1)
    L=Locations(N);
    while Ripple_Amplitude(L)>Mean_Ripple_Amplitude && L>1 %this finds the closest timepoint prior to the current peak that crosses the mean
        L=L-1;
    end
    Ripple_Events(N,1)=Ripple_LFP(L,1);
    L=Locations(N);
    while Ripple_Amplitude(L)>Mean_Ripple_Amplitude && L<length(Ripple_Amplitude) %this finds the closest timepoint after the current peak that crosses the mean
        L=L+1;
    end
    Ripple_Events(N,2)=Ripple_LFP(L,1);
end
for N=2:size(Ripple_Events,1)
    if Ripple_Events(N,3)-Ripple_Events(N-1,3)<=0.1  %Combine ripples with peaks less than 100 ms apart
        Ripple_Events(N,1)=Ripple_Events(N-1,1);
        Ripple_Events(N-1,1)=0;
    end
end
Ripple_Events=Ripple_Events(Ripple_Events(:,1)>0,:);
Ripple_Events=Ripple_Events((Ripple_Events(:,2)-Ripple_Events(:,1))<=1 & (Ripple_Events(:,2)-Ripple_Events(:,1))>=0.05,:); %Remove all ripples longer than 1 seconds or shorter than 50 ms
Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=min(Position_Data(:,1)),:);
Ripple_Events=Ripple_Events(Ripple_Events(:,2)<=max(Position_Data(:,1)),:);

cd(Current_Working_Directory)
save('Ripple_Events','Ripple_Events')

end