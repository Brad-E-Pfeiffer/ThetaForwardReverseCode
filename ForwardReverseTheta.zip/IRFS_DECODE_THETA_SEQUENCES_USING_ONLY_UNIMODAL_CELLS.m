
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function decodes every theta oscillation as with
% IRFS_DECODE_THETA_SEQUENCES, but here it uses only Unimodal cells
% to do the decoding.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%tic;

% This removes all spikes from Spike_Decoding_Index that are not Unimodal
% cells and then removes decoding timepoints with zero remaining spikes.
Unimodal_Decoding_Spike_Index=Decoding_Spike_Index;
Temp_Index=zeros(size(Decoding_Spike_Index));
for N=1:size(Modality,1)
    if Modality(N,1)==1
        Temp_Index(Decoding_Spike_Index==Modality(N,2))=1;
    end
end
Unimodal_Decoding_Spike_Index(Temp_Index==0)=0;
Unimodal_Decoding_Window_Index=Decoding_Window_Index(max(Unimodal_Decoding_Spike_Index)>0);
Unimodal_Decoding_Spike_Index=Unimodal_Decoding_Spike_Index(:,max(Unimodal_Decoding_Spike_Index)>0);
clear N;
clear Temp_Index;

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data2=Field_Data;
for N=1:size(Field_Data2,3)
    Field=Field_Data2(:,:,N);
    Minimum=min(min(Field(Field>0)));
    if ~isempty(Minimum)
        if Minimum/10>0
            Field(Field<=0)=Minimum/10;
        else
            Field(Field<=0)=Minimum;
        end
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data2(:,:,N)=Field;
    clear Minimum;
    clear Field;
end
clear N;

Mid_X=round(size(Field_Data,2)/2);   %This defines the size of the canvas for translation and rotation analysis
Mid_Y=round(size(Field_Data,1)/2);   %This defines the size of the canvas for translation and rotation analysis

Unimodal_Decoded_Sequence=zeros(3,length(Unimodal_Decoding_Window_Index));
%Unimodal_Decoded_Sequence
%|                           1                         |                    2                  |                     3                  ||
%|        Location of Max Posterior Probability        | Location of Max Posterior Probability |  Location of Max Posterior Probability ||
%|            Relative to Movement Direction           |    of X location (for open field)     |     of Y location (for open field)     ||
%| (for both open field and bidirectional linear track)| or for In direction (for linear track)| or for Out Direction (for linear track)||

Unimodal_Decoded_Data=zeros((max([Mid_X,Mid_Y])*2)+1,length(Unimodal_Decoding_Window_Index));
Decoded_Data_Size=size(Unimodal_Decoded_Data,1);
%Unimodal_Decoded_Data is the full posterior probabilities, collapsed across one dimension so it is encoding just the rat's current movement direction

parfor Current_Decoding_Window=1:length(Unimodal_Decoding_Window_Index)
    
    %Pulls up relevant spikes for this decoding window
    Subset_Spike_Data=Unimodal_Decoding_Spike_Index(:,Current_Decoding_Window);
    Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
        
    %This does the actual decoding for this window
    Decoded_Matrix=prod(Field_Data2(:,:,Subset_Spike_Data),3).*exp(-Decoding_Time_Window*sum(Field_Data,3));
    if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
        Divider=1;
        while isinf(max(max(Decoded_Matrix)))
            Decoded_Matrix=prod((Field_Data2(:,:,Subset_Spike_Data)/(2^Divider)),3).*exp(-Decoding_Time_Window*sum((Field_Data/(2^Divider)),3));
            Divider=Divider+1;
        end
    end
    Decoded_Matrix(Decoded_Matrix<0)=0;
    if max(max(Decoded_Matrix))>0
        Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
    end
    
    %Here is where the decoded data gets relocated to rat's current location
    X=Decoding_Time_Info(Unimodal_Decoding_Window_Index(Current_Decoding_Window),1)/Bin_Size;
    Y=Decoding_Time_Info(Unimodal_Decoding_Window_Index(Current_Decoding_Window),2)/Bin_Size;
    Translated_Image=imtranslate(Decoded_Matrix,[Mid_X-X,Mid_Y-Y],'FillValues',0);
        
    %Here is where the translated data is rotated to the rat's current movement direction (pull the data from column 3 instead of 5 for the rat's head direction)
    Angle_Movement=Decoding_Time_Info(Unimodal_Decoding_Window_Index(Current_Decoding_Window),5);
    Rotated_Image=imrotate(Translated_Image,-(Angle_Movement+180),'bilinear');
    if size(Rotated_Image,1)<Decoded_Data_Size
        Size_Difference=Decoded_Data_Size-size(Rotated_Image,1);
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Rotated_Image=padarray(Rotated_Image,[Size_Difference/2,0],0,'both');
        else
            Rotated_Image=padarray(Rotated_Image,[ceil(Size_Difference/2),0],0,'pre');
            Rotated_Image=padarray(Rotated_Image,[floor(Size_Difference/2),0],0,'post');
        end
    end
    if size(Rotated_Image,1)>Decoded_Data_Size
        Size_Difference=size(Rotated_Image,1)-Decoded_Data_Size;
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Rotated_Image=Rotated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
        elseif Size_Difference==1
            Rotated_Image=Rotated_Image(1:(end-1),:);
        else
            Rotated_Image=Rotated_Image(ceil(Size_Difference/2):(end-ceil(Size_Difference/2)),:);
        end
    end
    
    %Here it sums across the direction perpendicular to the rat's movement direction
    Rotated_Image=sum(Rotated_Image,2);
    
    %Add to the rest of the decoded frames
    Unimodal_Decoded_Data(:,Current_Decoding_Window)=Rotated_Image;
        
    %Quantify the single point likely represented by this decoded frame
    if Use_Maximum_Posterior_Probability %(This uses the max posterior probability as the single point)
        if max(max(Rotated_Image))>0
            Max_Position=find(Rotated_Image==max(Rotated_Image),1,'first');
        else
            Max_Position=0;
        end
    else %(This uses the weighted mean as the single point)
        if max(max(Rotated_Image))>0
            Position_Matrix=zeros(length(Rotated_Image),2);
            Position_Matrix(:,1)=(1:length(Rotated_Image))';
            Position_Matrix(:,2)=Rotated_Image;
            Max_Position=sum(Position_Matrix(:,1).*Position_Matrix(:,2))/sum(Position_Matrix(:,2));
        else
            Max_Position=0;
        end
    end
    
    %Here it collapses across X and Y decoded locations for open field experiments (rather than the movement direction, in case this is valuable for later analyses)
    if size(Translated_Image,1)<Decoded_Data_Size
        Size_Difference=Decoded_Data_Size-size(Translated_Image,1);
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Translated_Image=padarray(Translated_Image,[Size_Difference/2,0],0,'both');
        else
            Translated_Image=padarray(Translated_Image,[ceil(Size_Difference/2),0],0,'pre');
            Translated_Image=padarray(Translated_Image,[floor(Size_Difference/2),0],0,'post');
        end
    end
    if size(Translated_Image,1)>Decoded_Data_Size
        Size_Difference=size(Translated_Image,1)-Decoded_Data_Size;
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Translated_Image=Translated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
        elseif Size_Difference==1
            Translated_Image=Translated_Image(1:(end-1),:);
        else
            Translated_Image=Translated_Image((ceil(Size_Difference/2)+1):(end-ceil(Size_Difference/2)),:);
        end
    end
    if size(Translated_Image,2)<Decoded_Data_Size
        Size_Difference=Decoded_Data_Size-size(Translated_Image,2);
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Translated_Image=padarray(Translated_Image,[0,Size_Difference/2],0,'both');
        else
            Translated_Image=padarray(Translated_Image,[0,ceil(Size_Difference/2)],0,'pre');
            Translated_Image=padarray(Translated_Image,[0,floor(Size_Difference/2)],0,'post');
        end
    end
    if size(Translated_Image,2)>Decoded_Data_Size
        Size_Difference=size(Translated_Image,2)-Decoded_Data_Size;
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Translated_Image=Translated_Image(:,((Size_Difference/2)+1):(end-(Size_Difference/2)));
        elseif Size_Difference==1
            Translated_Image=Translated_Image(1:(end-1),:);
        else
            Translated_Image=Translated_Image(:,(ceil(Size_Difference/2)+1):(end-ceil(Size_Difference/2)));
        end
    end
    X_Image=(sum(Translated_Image,1))';
    Y_Image=sum(Translated_Image,2);
    if Use_Maximum_Posterior_Probability %(This uses the max posterior probability as the single point)
        if max(max(Translated_Image))>0
            Max_X_Position=find(X_Image==max(X_Image),1,'first');
            Max_Y_Position=find(Y_Image==max(Y_Image),1,'first');
        else
            Max_X_Position=0;
            Max_Y_Position=0;
        end
    else %(This uses the weighted mean as the single point)
        if max(max(Translated_Image))>0
            X_Position_Matrix=zeros(length(Max_X_Position),2);
            X_Position_Matrix(:,1)=(1:length(Max_X_Position))';
            X_Position_Matrix(:,2)=Max_X_Position;
            Max_X_Position=sum(X_Position_Matrix(:,1).*X_Position_Matrix(:,2))/sum(X_Position_Matrix(:,2));
            Y_Position_Matrix=zeros(length(Max_Y_Position),2);
            Y_Position_Matrix(:,1)=(1:length(Max_Y_Position))';
            Y_Position_Matrix(:,2)=Max_Y_Position;
            Max_Y_Position=sum(Y_Position_Matrix(:,1).*Y_Position_Matrix(:,2))/sum(Y_Position_Matrix(:,2));
        else
            Max_X_Position=0;
            Max_Y_Position=0;
        end
    end
    Unimodal_Decoded_Sequence(:,Current_Decoding_Window)=[Max_Position;Max_X_Position;Max_Y_Position];
    
end
clear Subset_Spike_Data;
clear Divider;
clear X;
clear Y;
clear Angle_Movement;
clear Translated_Image;
clear Rotated_Image;
clear Size_Difference;
clear Max_Position;
clear Position_Matrx;
clear Size_Difference;
clear X_Image;
clear Y_Image;
clear Max_X_Position;
clear Max_Y_Position;
clear X_Position_Matrix;
clear Y_Position_Matrix;
clear Decoded_Matrix;
clear In_Decoded_Matrix;
clear Out_Decoded_Matrix;
clear Mid;
clear Pos;
clear Field_Data2;
clear Decoded_Data_Size;
save('Decoded_Data_And_Sequences_With_Unimodal_Cells','Unimodal_Decoded_Sequence','Unimodal_Decoded_Dat*','Use_Maximum_Posterior_Probability','Decoding_Time_Window','Decoding_Time_Advance','Unimodal_Decoding_Window_Index','Unimodal_Decoding_Spike_Index','-v7.3');

%This decodes for linear track experiments
if strcmp(Directory_Name(1),'L')  
    
    Field_Data_Linear2=Field_Data_Linear;
    Field_Data_Linear_In2=Field_Data_Linear_In;
    Field_Data_Linear_Out2=Field_Data_Linear_Out;
    for N=1:size(Field_Data_Linear,2)
        Field=Field_Data_Linear2(:,N);
        Field_In=Field_Data_Linear_In2(:,N);
        Field_Out=Field_Data_Linear_Out2(:,N);
        Minimum=min(Field(Field>0));
        Minimum_In=min(Field_In(Field_In>0));
        Minimum_Out=min(Field_Out(Field_Out>0));
        if ~isempty(Minimum)
            Field(Field<=0)=Minimum/10;
        else
            Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_In)
            Field_In(Field_In<=0)=Minimum_In/10;
        else
            Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_Out)
            Field_Out(Field_Out<=0)=Minimum_Out/10;
        else
            Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        Field_Data_Linear2(:,N)=Field;
        Field_Data_Linear_In2(:,N)=Field_In;
        Field_Data_Linear_Out2(:,N)=Field_Out;
        clear Minimum;
        clear Minimum_In;
        clear Minimum_Out;
        clear Field;
        clear Field_In;
        clear Field_Out;
    end
    clear N;
    
    %This finds the long axis of the linear track and uses the appropriate position and movement direction data
    if max(Position_Data(:,2))-min(Position_Data(:,2))>max(Position_Data(:,3))-min(Position_Data(:,3))
        Position_Column=1;
    else
        Position_Column=2;
    end
    Movement_Direction=diff(Decoding_Time_Info(:,Position_Column));
    Movement_Direction(end+1,1)=Movement_Direction(end,1);
    if Movement_Direction(1,1)==0
        Movement_Direction(1,1)=Movement_Direction(find(Movement_Direction>0,1,'first'));
    end
    for N=2:length(Movement_Direction)
        if Movement_Direction(N,1)==0
            Movement_Direction(N,1)=Movement_Direction(N-1,1);
        end
    end
    Movement_Direction(Movement_Direction>=0)=1;
    Movement_Direction(Movement_Direction<0)=-1;
    
    Mid_Point=round(size(Field_Data_Linear2,1)/2);   %This defines the size of the canvas for translation analysis
    
    Unimodal_Decoded_Data_Linear_Raw=zeros(size(Field_Data_Linear,1),length(Unimodal_Decoding_Window_Index),3);  %Page 1 is bi-directional fields, Page 2 is In fields, Page 3 is Out fields
    Unimodal_Decoded_Data_Linear=zeros(size(Field_Data_Linear,1),length(Unimodal_Decoding_Window_Index));
    Unimodal_Decoded_Data_Linear_In=zeros(size(Field_Data_Linear,1),length(Unimodal_Decoding_Window_Index));
    Unimodal_Decoded_Data_Linear_Out=zeros(size(Field_Data_Linear,1),length(Unimodal_Decoding_Window_Index));
    
    parfor Current_Decoding_Window=1:length(Unimodal_Decoding_Window_Index)
        
        %Pulls up relevant spikes for this decoding window
        Subset_Spike_Data=Unimodal_Decoding_Spike_Index(:,Current_Decoding_Window);
        Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
        
        %This does the actual decoding for this window
        Decoded_Matrix=prod(Field_Data_Linear2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear,2));
        if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
            Divider=1;
            while isinf(max(max(Decoded_Matrix)))
                Decoded_Matrix=prod((Field_Data_Linear2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                Divider=Divider+1;
            end
        end
        Decoded_Matrix(Decoded_Matrix<0)=0;
        if max(max(Decoded_Matrix))>0
            Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
        end
        
        Decoded_Matrix_In=prod(Field_Data_Linear_In2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_In,2));
        Decoded_Matrix_Out=prod(Field_Data_Linear_Out2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_Out,2));
        if isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
            Divider=1;
            while isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out)))
                Decoded_Matrix_In=prod((Field_Data_Linear_In2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_In/(2^Divider)),2));
                Decoded_Matrix_Out=prod((Field_Data_Linear_Out2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_Out/(2^Divider)),2));
                Divider=Divider+1;
            end
        end
        Decoded_Matrix_In(Decoded_Matrix_In<0)=0;
        Decoded_Matrix_Out(Decoded_Matrix_Out<0)=0;
        if max(max(Decoded_Matrix_In))>0 && max(max(Decoded_Matrix_Out))>0
            Sum=sum(Decoded_Matrix_In+Decoded_Matrix_Out);
            Decoded_Matrix_In=Decoded_Matrix_In/Sum;
            Decoded_Matrix_Out=Decoded_Matrix_Out/Sum;
        end
        
        %Here is where the decoded data gets relocated to rat's current location
        Location=min([size(Field_Data_Linear,1),max([1,round(Decoding_Time_Info(Unimodal_Decoding_Window_Index(Current_Decoding_Window),Position_Column)/Bin_Size)])]);
        Direction=Movement_Direction(Unimodal_Decoding_Window_Index(Current_Decoding_Window),1);
        Translated_Image=imtranslate(Decoded_Matrix,[0,Mid_Point-Location],'FillValues',0);
        Translated_Image_In=imtranslate(Decoded_Matrix_In,[0,Mid_Point-Location],'FillValues',0);
        Translated_Image_Out=imtranslate(Decoded_Matrix_Out,[0,Mid_Point-Location],'FillValues',0);
        if Direction==-1
            Translated_Image=Translated_Image(end:-1:1,:);
            Translated_Image_In=Translated_Image_In(end:-1:1,:);
            Translated_Image_Out=Translated_Image_Out(end:-1:1,:);
        end
        
        %Add to the rest of the decoded frames
        Unimodal_Decoded_Data_Linear(:,Current_Decoding_Window)=Translated_Image;
        Unimodal_Decoded_Data_Linear_In(:,Current_Decoding_Window)=Translated_Image_In;
        Unimodal_Decoded_Data_Linear_Out(:,Current_Decoding_Window)=Translated_Image_Out;
        Unimodal_Decoded_Data_Linear_Raw(:,Current_Decoding_Window,:)=permute([Decoded_Matrix,Decoded_Matrix_In,Decoded_Matrix_Out],[1,3,2]);
        
    end
    
    Unimodal_Decoded_Data_Linear_In_Moving_Up=Unimodal_Decoded_Data_Linear_In(:,Movement_Direction(Unimodal_Decoding_Window_Index,1)==1);
    Unimodal_Decoded_Data_Linear_In_Moving_Down=Unimodal_Decoded_Data_Linear_In(:,Movement_Direction(Unimodal_Decoding_Window_Index,1)==-1);
    Unimodal_Decoded_Data_Linear_Out_Moving_Up=Unimodal_Decoded_Data_Linear_Out(:,Movement_Direction(Unimodal_Decoding_Window_Index,1)==1);
    Unimodal_Decoded_Data_Linear_Out_Moving_Down=Unimodal_Decoded_Data_Linear_Out(:,Movement_Direction(Unimodal_Decoding_Window_Index,1)==-1);
    
    clear Current_Decoding_Window;
    clear Subset_Spike_Data;
    clear Divider;
    clear Location;
    clear Direction;
    clear Translated_Image;
    clear Translated_Image_In;
    clear Translated_Image_Out;
    clear Decoded_Matrix;
    clear In_Decoded_Matrix;
    clear Out_Decoded_Matrix;
    clear Mid_Point;
    clear Field_Data_Linear2;
    clear Field_Data_Linear_In2;
    clear Field_Data_Linear_Out2;
    clear Position_Column;
    clear Decoded_Matrix;
    clear Decoded_Matrix_In;
    clear Decoded_Matrix_Out;
    clear Sum;
    save('Decoded_Linear_Data_And_Sequences_With_Unimodal_Cells','Movement_Direction','Unimodal_Decoded_Data_Lin*','Use_Maximum_Posterior_Probability','Decoding_Time_Window','Decoding_Time_Advance','Unimodal_Decoding_Window_Index','Unimodal_Decoding_Spike_Index','-v7.3');
    clear Movement_Direction;
    
end


%T=toc;
%eval(sprintf('disp(''Took %d minutes.'');',T/60));
%clear T;


