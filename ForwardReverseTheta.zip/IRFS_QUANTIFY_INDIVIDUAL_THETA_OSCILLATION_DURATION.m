% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script quantifies the duration (trough-to-trough) (in seconds) for
% each theta oscillation and also determines if the phase increases
% continuously throughout the entirety of the oscillation.  This may be
% used later for exclusion of rare, unusual theta oscillations from
% analysis.
% 
% I tried using findpeaks to identify troughs, but found that when I used
% the difference in phases, I was more easily able to obtain a true phase
% reset (from 360 back to 0) that would be associated with the trough of
% theta.  The findpeaks function would probably give very similar results.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% LFP_Theta
% |     1    |            2         |       3     |       4     |                     5                      |                        6                     ||
% | Time (s) | Filtered Theta Trace | Theta Power | Theta Phase | Cycle Duration (Seconds, Trough-to-Trough) | Monotonically Increasing Cycle? (1=yes;0=no) ||

LFP_Theta(:,5:6)=0;
Phase_Difference=diff(LFP_Theta(:,4));
Troughs=find(Phase_Difference<-345);
Troughs=Troughs+1;
Monotonic_Increasing=zeros(length(Troughs),1);
for N=1:(length(Troughs)-1)
    if all(diff(LFP_Theta(Troughs(N):(Troughs(N+1)-1),4))>0)
        Monotonic_Increasing(N,1)=1;
    end
end
clear N;
Cycle_Durations=zeros(length(Troughs),1);
for N=1:(length(Troughs)-1)
    Cycle_Durations(N,1)=LFP_Theta((Troughs(N+1)-1),1)-LFP_Theta(Troughs(N),1);
end
clear N;
for N=1:(length(Troughs)-1)
    LFP_Theta(Troughs(N):(Troughs(N+1)-1),5:6)=ones(length(LFP_Theta(Troughs(N):(Troughs(N+1)-1),1)),2).*[Cycle_Durations(N),Monotonic_Increasing(N)];
end
clear N;
clear Monotonic_Increasing;
clear Cycle_Durations;
clear Troughs;
clear Phase_Difference;
LFP_Left_Theta=LFP_Theta;
save('LFP_Left_Theta','LFP_Left_Theta','-v7.3');
clear LFP_Left_Theta;