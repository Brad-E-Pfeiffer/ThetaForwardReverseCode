function IRFS_DECODE_AND_IDENTIFY_REPLAY_EVENTS(Ripple_Events,Spike_Data,Field_Data,Inhibitory_Neurons)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script decodes each ripple event and determines if it meets the
% criteria to be considered a replay event.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data2=Field_Data;
for N=1:size(Field_Data2,3)
    Field=Field_Data2(:,:,N);
    Minimum=min(min(Field(Field>0)));
    if ~isempty(Minimum)
        if Minimum/10>0
            Field(Field<=0)=Minimum/10;
        else
            Field(Field<=0)=Minimum;
        end
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data2(:,:,N)=Field;
    clear Minimum;
    clear Field;
end
clear N;

Number_Of_Ripple_Shuffles=1000;

%First, we find all the spikes for each decoding window
if exist('Ripple_Spike_Data_Matrix.mat','file')==2
    load Ripple_Spike_Data_Matrix
else
    Total_Number_Of_Ripple_Decoding_Bins=0;
    Ripple_Decoding_Index=zeros(size(Ripple_Events,1),2);
    for Current_Ripple=1:size(Ripple_Events,1)
        Number_Of_Bins_In_This_Ripple=length((Ripple_Events(Current_Ripple,1)+(Decoding_Time_Window/2)):Decoding_Time_Advance:(Ripple_Events(Current_Ripple,2)-(Decoding_Time_Window/2)));
        Ripple_Decoding_Index(Current_Ripple,:)=[(Total_Number_Of_Ripple_Decoding_Bins+1),(Total_Number_Of_Ripple_Decoding_Bins+Number_Of_Bins_In_This_Ripple)];
        Total_Number_Of_Ripple_Decoding_Bins=Total_Number_Of_Ripple_Decoding_Bins+Number_Of_Bins_In_This_Ripple;
    end
    Max_Number_Of_Spikes_Per_Decoding_Window=200;        %Make sure this is larger than you will ever get -- if you're wrong, you'll get an error and the program will crash.
    Ripple_Spike_Data_Matrix=zeros(Max_Number_Of_Spikes_Per_Decoding_Window,Total_Number_Of_Ripple_Decoding_Bins);
    Ripple_Spike_Data_Matrix_With_Inhibitory_Neurons=zeros(Max_Number_Of_Spikes_Per_Decoding_Window,Total_Number_Of_Ripple_Decoding_Bins);
    % Ripple_Spike_Data_Matrix is a list of the cell IDs for all spikes that fire in each decoding window for faster decoding in the future
    
    Excitatory_Spike_Data=Spike_Data;
    for N=1:length(Inhibitory_Neurons)
        Excitatory_Spike_Data=Excitatory_Spike_Data(Excitatory_Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
    end
    Bin=0;
    for Current_Ripple=1:size(Ripple_Events,1)
        for Start_Time=(Ripple_Events(Current_Ripple,1)+(Decoding_Time_Window/2)):Decoding_Time_Advance:(Ripple_Events(Current_Ripple,2)-(Decoding_Time_Window/2))
            Bin=Bin+1;
            Participating_Spikes=Excitatory_Spike_Data(Excitatory_Spike_Data(:,1)>=(Start_Time-(Decoding_Time_Window/2)) & Excitatory_Spike_Data(:,1)<=(Start_Time+(Decoding_Time_Window/2)),2);
            Participating_Spikes_With_Inhibitory_Neurons=Spike_Data(Spike_Data(:,1)>=(Start_Time-(Decoding_Time_Window/2)) & Spike_Data(:,1)<=(Start_Time+(Decoding_Time_Window/2)),2);
            if size(Participating_Spikes,1)<Max_Number_Of_Spikes_Per_Decoding_Window
                Participating_Spikes(end+1:Max_Number_Of_Spikes_Per_Decoding_Window,:)=0;
            elseif size(Participating_Spikes,1)>Max_Number_Of_Spikes_Per_Decoding_Window
                error('Too many spikes detected.  Change Max_Number_Of_Spikes_Per_Decoding_Window in IRFS_DECODE_AND_IDENTIFY_REPLAY_EVENTS to a larger value!')
            end
            if size(Participating_Spikes_With_Inhibitory_Neurons,1)<Max_Number_Of_Spikes_Per_Decoding_Window
                Participating_Spikes_With_Inhibitory_Neurons(end+1:Max_Number_Of_Spikes_Per_Decoding_Window,:)=0;
            elseif size(Participating_Spikes_With_Inhibitory_Neurons,1)>Max_Number_Of_Spikes_Per_Decoding_Window
                error('Too many spikes detected.  Change Max_Number_Of_Spikes_Per_Decoding_Window in IRFS_DECODE_AND_IDENTIFY_REPLAY_EVENTS to a larger value!')
            end
            Ripple_Spike_Data_Matrix(:,Bin)=Participating_Spikes;
            Ripple_Spike_Data_Matrix_With_Inhibitory_Neurons(:,Bin)=Participating_Spikes_With_Inhibitory_Neurons;
        end
    end
    clear Participating_Spikes;
    clear N;
    clear Excitatory_Spike_Data;
    clear Bin;
    clear Current_Ripple;
    clear Start_Time;
    clear Max_Number_Of_Spikes_Per_Decoding_Window;
    save('Ripple_Spike_Data_Matrix','Ripple_Spike_Data_Matrix','Ripple_Spike_Data_Matrix_With_Inhibitory_Neurons','Ripple_Decoding_Index')
end

if 0 %Not currently analyzing 2-D replays
    
    % Because the decoding algorithm multiplies fields together for a
    % part of the calculation, any field with a value of 0 prevents the
    % algorithm from ever representing that location.  Therefore, I need to go
    % through and replace all values of 0 with a very low, non-zero number.
    Field_Data2=Field_Data;
    for N=1:size(Field_Data2,3)
        Field=Field_Data2(:,:,N);
        Minimum=min(min(Field(Field>0)));
        if ~isempty(Minimum)
            if Minimum/10>0
                Field(Field<=0)=Minimum/10;
            else
                Field(Field<=0)=Minimum;
            end
        else
            Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        Field_Data2(:,:,N)=Field;
        clear Minimum;
        clear Field;
    end
    clear N;
    for Current_Ripple=1:size(Ripple_Events,1)
        
        Number_Of_Steps_In_This_Ripple=length(Ripple_Decoding_Index(Current_Ripple,1):Ripple_Decoding_Index(Current_Ripple,2));
        Current_Ripple_Spike_Data_Matrix=Ripple_Spike_Data_Matrix(:,Ripple_Decoding_Index(Current_Ripple,1):Ripple_Decoding_Index(Current_Ripple,2));
        Decoded_Ripple_Data=zeros(size(Field_Data,1),size(Field_Data,2),Number_Of_Steps_In_This_Ripple);
        Decoded_Ripple_Sequence=zeros(Number_Of_Steps_In_This_Ripple,3);
        
        for Step=1:size(Current_Ripple_Spike_Data_Matrix,2)
            
            %Pulls up the relevant spiks for this decoding window
            Subset_Spike_Data=Current_Ripple_Spike_Data_Matrix(:,Step);
            Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
            
            %This does the actual decoding
            Decoded_Matrix=prod(Field_Data2(:,:,Subset_Spike_Data),3).*exp(-Decoding_Time_Window*sum(Field_Data,3));
            if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix)))
                    Decoded_Matrix=prod((Field_Data2(:,:,Subset_Spike_Data)/(2^Divider)),3).*exp(-Decoding_Time_Window*sum((Field_Data/(2^Divider)),3));
                    Divider=Divider+1;
                end
            end
            clear Divider;
            Decoded_Matrix(Decoded_Matrix<0)=0;
            if max(max(Decoded_Matrix))>0
                Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
            end
            
            %Quantify the single point likely represented by this decoded frame (this uses the weighted mean posterior probability, not the maximum -- will have to re-code to use maximum)
            if max(max(Decoded_Matrix))>0
                Position_Matrix=zeros(size(Decoded_Matrix,1)*size(Decoded_Matrix,2),3);
                Matrix_Line=1;
                for L=1:size(Decoded_Matrix,1)
                    for K=1:size(Decoded_Matrix,2)
                        Position_Matrix(Matrix_Line,:)=[K,L,Decoded_Matrix(L,K)];
                        Matrix_Line=Matrix_Line+1;
                    end
                end
                clear Matrix_Line;
                Max_X_Position=sum(Position_Matrix(:,1).*Position_Matrix(:,3))/sum(Position_Matrix(:,3));
                Max_Y_Position=sum(Position_Matrix(:,2).*Position_Matrix(:,3))/sum(Position_Matrix(:,3));
            else
                Max_Y_Position=0;
                Max_X_Position=0;
            end
            Decoded_Ripple_Data(:,:,(Step))=Decoded_Matrix;
            Decoded_Ripple_Sequence((Step),:)=[Max_Position_X,Max_Position_Y,max(max(Decoded_Matrix))];
            clear Max_Position_X;
            clear Max_Position_Y;
            clear Decoded_Matrix;
            clear Position_Matrix;
        end
        
        % This measures the weighted correlation of the entire candidate event
        Weighted_Position_Correlation=IRFS_CALCULATE_WEIGHTED_POSITION_CORRELATION(Decoded_Ripple_Data);
        
        % Now, the function analyzes information about the path encoded by the event
        [Best_Sequence_Data,Best_Sequence]=IRFS_ANALYZE_EVENT_PATH_INFORMATION(Decoded_Ripple_Sequence,25,10,40); %Minimum Step Size = 25 bins; Minimum Step Number = 10; Total Distance = 40 bins
        
        %This pulls out the decoded data corresponding to the best sequence
        if Best_Sequence_Data(1,1)>0
            Best_Decoded_Data=Decoded_Ripple_Data(:,:,Best_Sequence_Data(1,1):Best_Sequence_Data(1,2));
            Best_Weighted_Position_Correlation=IRFS_CALCULATE_WEIGHTED_POSITION_CORRELATION(Best_Decoded_Data);
        else
            Best_Weighted_Position_Correlation=[0,0];
        end
        
        
        %More to do here to get 2D replays properly analyzed, including step sizes, total distance covered, etc...
        
        
    end
end
    
% Below is for linear track (directional) replay
if strcmp(Directory_Name(1),'L') && exist('Linear_Replay_Stats.mat','file')~=2
    % Because the decoding algorithm multiplies fields together for a
    % part of the calculation, any field with a value of 0 prevents the
    % algorithm from ever representing that location.  Therefore, I need to go
    % through and replace all values of 0 with a very low, non-zero number.
    Field_Data_Linear2=Field_Data_Linear;
    Field_Data_Linear_In2=Field_Data_Linear_In;
    Field_Data_Linear_Out2=Field_Data_Linear_Out;
    for N=1:size(Field_Data_Linear,2)
        Field=Field_Data_Linear2(:,N);
        Field_In=Field_Data_Linear_In2(:,N);
        Field_Out=Field_Data_Linear_Out2(:,N);
        Minimum=min(Field(Field>0));
        Minimum_In=min(Field_In(Field_In>0));
        Minimum_Out=min(Field_Out(Field_Out>0));
        if ~isempty(Minimum)
            Field(Field<=0)=Minimum/10;
        else
            Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_In)
            Field_In(Field_In<=0)=Minimum_In/10;
        else
            Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_Out)
            Field_Out(Field_Out<=0)=Minimum_Out/10;
        else
            Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        Field_Data_Linear2(:,N)=Field;
        Field_Data_Linear_In2(:,N)=Field_In;
        Field_Data_Linear_Out2(:,N)=Field_Out;
        clear Minimum;
        clear Minimum_In;
        clear Minimum_Out;
        clear Field;
        clear Field_In;
        clear Field_Out;
    end
    clear N;
    
    % Linear_Replay_Stats
    % |       1       |             2        |                3             |            4         ||
    % | Replay Number | Weighted Correlation | Weighted Correlation P-Value | Downward Probability ||
    Linear_Replay_Stats=zeros(size(Ripple_Events,1),4);
    
    tic;
    for Current_Ripple=1:size(Ripple_Events,1)
        
        Number_Of_Steps_In_This_Ripple=length(Ripple_Decoding_Index(Current_Ripple,1):Ripple_Decoding_Index(Current_Ripple,2));
        Current_Ripple_Spike_Data_Matrix=Ripple_Spike_Data_Matrix(:,Ripple_Decoding_Index(Current_Ripple,1):Ripple_Decoding_Index(Current_Ripple,2));
        Decoded_Ripple_Linear_Data=zeros(size(Field_Data_Linear,1),Number_Of_Steps_In_This_Ripple);
        Decoded_Ripple_In_Data=zeros(size(Field_Data_Linear_In,1),Number_Of_Steps_In_This_Ripple);
        Decoded_Ripple_Out_Data=zeros(size(Field_Data_Linear_Out,1),Number_Of_Steps_In_This_Ripple);

        for Step=1:size(Current_Ripple_Spike_Data_Matrix,2)
            
            %Pulls up the relevant spiks for this decoding window
            Subset_Spike_Data=Current_Ripple_Spike_Data_Matrix(:,Step);
            Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
            
            %This does the actual decoding
            Decoded_Matrix_Linear=prod(Field_Data_Linear2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear,2));
            if isinf(max(max(Decoded_Matrix_Linear))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix_Linear)))
                    Decoded_Matrix_Linear=prod((Field_Data_Linear2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                    Divider=Divider+1;
                end
            end
            Decoded_Matrix_Linear(Decoded_Matrix_Linear<0)=0;
            if max(max(Decoded_Matrix_Linear))>0
                Decoded_Matrix_Linear=Decoded_Matrix_Linear/sum(Decoded_Matrix_Linear);
            end
            clear Divider;

            %This does direction (In vs. Out) decoding
            Decoded_Matrix_In=prod(Field_Data_Linear_In2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_In,2));
            Decoded_Matrix_Out=prod(Field_Data_Linear_Out2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_Out,2));
            if isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out)))
                    Decoded_Matrix_In=prod((Field_Data_Linear_In2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_In/(2^Divider)),2));
                    Decoded_Matrix_Out=prod((Field_Data_Linear_Out2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_Out/(2^Divider)),2));
                    Divider=Divider+1;
                end
            end
            Decoded_Matrix_In(Decoded_Matrix_In<0)=0;
            Decoded_Matrix_Out(Decoded_Matrix_Out<0)=0;
            if max(max(Decoded_Matrix_In))>0 && max(max(Decoded_Matrix_Out))>0
                Sum=sum(Decoded_Matrix_In+Decoded_Matrix_Out);
                Decoded_Matrix_In=Decoded_Matrix_In/Sum;
                Decoded_Matrix_Out=Decoded_Matrix_Out/Sum;
            end
            clear Sum;
            
            Decoded_Ripple_Linear_Data(:,Step)=Decoded_Matrix_Linear;
            Decoded_Ripple_In_Data(:,Step)=Decoded_Matrix_In;
            Decoded_Ripple_Out_Data(:,Step)=Decoded_Matrix_Out;
        end
        
        %This calculates the weighted correlation of the decoded data for both the In and Out
        Weighted_Correlation_Linear=IRFS_WEIGHTED_CORRELATION(Decoded_Ripple_Linear_Data);
        Weighted_Correlation_In=IRFS_WEIGHTED_CORRELATION(Decoded_Ripple_In_Data);
        Weighted_Correlation_Out=IRFS_WEIGHTED_CORRELATION(Decoded_Ripple_Out_Data);
        
        %This runs Cell ID shuffles on each ripple and recalculates the Weighted Correlation for each to calculate a Monte-Carlo p-value for the overall weighted correlation
        Weighted_Correlation_Shuffle_Values=zeros(Number_Of_Ripple_Shuffles,1);
        parfor Shuffle=1:Number_Of_Ripple_Shuffles
            %This shuffles the cell IDs in the Current_Ripple_Spike_Data_Matrix
            Shuffled_Spike_Index=zeros(size(Current_Ripple_Spike_Data_Matrix));
            Shuffled_Spike_IDs=Excitatory_Neurons(randperm(length(Excitatory_Neurons)));
            for Current_Shuffled_Cell=1:length(Excitatory_Neurons)
                Shuffled_Spike_Index(Current_Ripple_Spike_Data_Matrix==Excitatory_Neurons(Current_Shuffled_Cell))=Shuffled_Spike_IDs(Current_Shuffled_Cell);
            end
            Shuffle_Decoded_Data=zeros(size(Field_Data_Linear,1),size(Shuffled_Spike_Index,2));
            for Shuffle_Step=1:size(Shuffled_Spike_Index,2)
                Shuffle_Subset_Spike_Data=Shuffled_Spike_Index(:,Shuffle_Step);
                Shuffle_Subset_Spike_Data=Shuffle_Subset_Spike_Data(Shuffle_Subset_Spike_Data>0);
                Shuffle_Decoded_Matrix_Linear=prod(Field_Data_Linear2(:,Shuffle_Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear,2));
                if isinf(max(max(Shuffle_Decoded_Matrix_Linear))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                    Divider=1;
                    while isinf(max(max(Shuffle_Decoded_Matrix_Linear)))
                        Shuffle_Decoded_Matrix_Linear=prod((Field_Data_Linear2(:,Shuffle_Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                        Divider=Divider+1;
                    end
                end
                Shuffle_Decoded_Matrix_Linear(Shuffle_Decoded_Matrix_Linear<0)=0;
                if max(max(Shuffle_Decoded_Matrix_Linear))>0
                    Shuffle_Decoded_Matrix_Linear=Shuffle_Decoded_Matrix_Linear/sum(Shuffle_Decoded_Matrix_Linear);
                end
                Shuffle_Decoded_Data(:,Shuffle_Step)=Shuffle_Decoded_Matrix_Linear;
            end
            Shuffle_Weighted_Correlation=IRFS_WEIGHTED_CORRELATION(Shuffle_Decoded_Data);
            Weighted_Correlation_Shuffle_Values(Shuffle,1)=Shuffle_Weighted_Correlation;
        end
        clear Shuffled_Spike_Index;
        clear Shuffled_Spike_IDs;
        clear Current_Shuffled_Cell;
        clear Shuffle_Decoded_Data;
        clear Shuffle_Step;
        clear Shuffle_Subset_Spike_Data;
        clear Shuffle_Decoded_Matrix_Linear;
        clear Divider;
        clear Shuffle_Weighted_Correlation;
        Weighted_Correlation_P_Value=(length(find(abs(Weighted_Correlation_Shuffle_Values)>=abs(Weighted_Correlation_Linear)))+1)/(Number_Of_Ripple_Shuffles+1);
        
        %This calculates the "Downward Probability", which is just determing whether the replay uses more In or Out representation
        Downward_Probability=sum(sum(Decoded_Ripple_In_Data))/(sum(sum(Decoded_Ripple_In_Data))+sum(sum(Decoded_Ripple_Out_Data)));
        
        Linear_Replay_Stats(Current_Ripple,:)=[Current_Ripple,Weighted_Correlation_Linear,Weighted_Correlation_P_Value,Downward_Probability];
        
        if Current_Ripple/20==round(Current_Ripple/20)
            Tock=toc;
            eval(sprintf('disp(''Completed decoding and shuffle analysis for Ripple %d to %d (of %d).  Took %d minutes for last 20 ripples.'');',Current_Ripple-19,Current_Ripple,size(Ripple_Events,1),Tock/60));
            clear Tock;
            tic
        end
        
    end
    
    save('Linear_Replay_Stats','Linear_Replay_Stats','Number_Of_Ripple_Shuffles');
    
elseif strcmp(Directory_Name(1),'L')
    load Linear_Replay_Stats

end
    
    

