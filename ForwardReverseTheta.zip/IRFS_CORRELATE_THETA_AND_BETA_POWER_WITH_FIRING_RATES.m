
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script calculates the correlation between theta or beta power and
% spike counts in the Major Peak or Minor Peak Windows.
% 
% It then bins each theta oscillation by the theta power or beta power and
% then caculates the FRI for each neuron using spikes from those bins.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% This loads the analysis windows that we will use for quantification
cd ..
cd ..
load Bimodal_Analysis_Windows
eval(sprintf('cd %s',Rat_Name));
eval(sprintf('cd %s',Directory_Name));
Phase_Reset=Major_Peak_Window(2);  %This is the 'start/end' of a theta oscillation

% This loads the rest of the relevant data
load Spike_Data_With_Theta_Phase
load('Spike_Data','Inhibitory_Neurons','Excitatory_Neurons');
Spike_Data(Spike_Data(:,3)==0,3)=360;  %Just to make sure that the method below doesn't skip over any spikes
load('Modality','Modality')
load Firing_Rate_Per_Phase
load LFP_Left_Theta
LFP_Theta=LFP_Left_Theta;
clear LFP_Left_Theta;
load LFP_Left_Beta
LFP_Beta=LFP_Left_Beta;
clear LFP_Left_Beta;
if eval(sprintf('isfield(Timepoints_To_Remove,''%s_%s_To_Remove'')',Rat_Name,Directory_Name))
    eval(sprintf('Sections_To_Remove=Timepoints_To_Remove.%s_%s_To_Remove;',Rat_Name,Directory_Name));
    for Section=1:size(Sections_To_Remove,1)
        LFP_Beta=LFP_Beta(LFP_Beta(:,1)<Sections_To_Remove(Section,1) | LFP_Beta(:,1)>Sections_To_Remove(Section,2),:);
    end
    clear Section
end
clear Sections_To_Remove
load Decoding_Time_Info
% Decoding_Time_Info
% |       1         |         2       |          3          |        4      |            5            |      6      |           7        |        8          |                             9                           |                                      10                                    |      11     |               12             |              13              |               14            ||
% | Real X Pos (cm) | Real Y Pos (cm) | Real Head Direction | Real Velocity | Real Movement Direction | Theta Phase | Spikes In This Bin | Cells In This Bin | Velocity Above Threshold for Both Flanking Oscillation? | Current Theta Oscillaton Meets Duration and Monotonic Increasing Criteria? | Theta Power | Total Spikes In Major Window | Total Spikes in Minor Window | Theta Oscillation ID Number ||

% This finds the start and end times (in seconds) for each theta
% oscillation, determined by when the phase of the oscillation crosses 
% Phase_Reset (70 degrees), which is the end of the Major Peak Window.
Theta_Oscillation_Start_End_Times=zeros(max(Decoding_Time_Info(:,14)),2);
Decoding_Oscillation_ID_Numbers=Decoding_Time_Info(:,14);
LFP_Times=LFP_Theta(:,1);
LFP_Phases=LFP_Theta(:,4);
parfor Current_Oscillation=1:max(Decoding_Time_Info(:,14))
    Subset_Decoding_Times=Decoding_Times(Decoding_Oscillation_ID_Numbers==Current_Oscillation);
    if Current_Oscillation==max(Decoding_Oscillation_ID_Numbers)
        Next_Subset_Start_Time=max(LFP_Times);
    else
        Next_Subset_Start_Time=min(Decoding_Times(Decoding_Oscillation_ID_Numbers==(Current_Oscillation+1)));
    end
    Oscillation_Start_Time=max(LFP_Times(LFP_Times<=min(Subset_Decoding_Times) & LFP_Phases<=Phase_Reset));
    Oscillation_End_Time=max(LFP_Times(LFP_Times<=Next_Subset_Start_Time & LFP_Phases<=Phase_Reset));
    Theta_Oscillation_Start_End_Times(Current_Oscillation,:)=[Oscillation_Start_Time,Oscillation_End_Time];
end
clear Next_Subset_Start_Time;
clear Subset_Decoding_Times;
clear LFP_Times;
clear LFP_Phases;
clear Decoding_Oscillation_ID_Numbers;
clear Current_Oscillation;

% This finds the average theta and beta power within each theta oscillation.
Theta_ZScore_Power_Per_Theta_Oscillation=zeros(max(Decoding_Time_Info(:,14)),1);
Beta_ZScore_Power_Per_Theta_Oscillation=zeros(max(Decoding_Time_Info(:,14)),1);
parfor Current_Oscillation=1:max(Decoding_Time_Info(:,14))
    Theta_ZScore_Power_Per_Theta_Oscillation(Current_Oscillation,:)=mean(LFP_Theta(LFP_Theta(:,1)>=Theta_Oscillation_Start_End_Times(Current_Oscillation,1) & LFP_Theta(:,1)<Theta_Oscillation_Start_End_Times(Current_Oscillation,2),3));
    Beta_ZScore_Power_Per_Theta_Oscillation(Current_Oscillation,:)=mean(LFP_Beta(LFP_Theta(:,1)>=Theta_Oscillation_Start_End_Times(Current_Oscillation,1) & LFP_Theta(:,1)<Theta_Oscillation_Start_End_Times(Current_Oscillation,2),3));
end
clear Current_Oscillation;

% This finds which oscillations were actually used for theta sequence decoding.
Used_Oscillations=zeros(max(Decoding_Time_Info(:,14)),1);
for Current_Oscillation=1:max(Decoding_Time_Info(:,14))
    Subset_Decoding_Time_Info=Decoding_Time_Info(Decoding_Time_Info(:,14)==Current_Oscillation,:);
    if mode(Subset_Decoding_Time_Info(:,9))==1 && mode(Subset_Decoding_Time_Info(:,10))==1
        Used_Oscillations(Current_Oscillation,1)=1;
    end
end
clear Current_Oscillation;
clear Subset_Decoding_Time_Info;

% This limits analysis to only used theta oscillations and finds the rank
% order for each oscillation in theta power and beta power, split into ten
% evenly sized groups.
Theta_Oscillation_Start_End_Times=Theta_Oscillation_Start_End_Times(Used_Oscillations==1,:);
Theta_ZScore_Power_Per_Theta_Oscillation=Theta_ZScore_Power_Per_Theta_Oscillation(Used_Oscillations==1,:);
Beta_ZScore_Power_Per_Theta_Oscillation=Beta_ZScore_Power_Per_Theta_Oscillation(Used_Oscillations==1,:);
clear Used_Oscillations;
[~,Rank_By_Theta]=sortrows(Theta_ZScore_Power_Per_Theta_Oscillation(:,1));
[~,Rank_By_Beta]=sortrows(Beta_ZScore_Power_Per_Theta_Oscillation(:,1));
Rank_Steps=1:length(Rank_By_Theta)/10:length(Rank_By_Theta);
if Rank_Steps(end)~=length(Rank_By_Theta)
    Rank_Steps(end+1)=length(Rank_By_Theta)+1;
else
    Rank_Steps(end)=length(Rank_By_Theta)+1;
end

% This calculates the firing rate index of each neuron within each rank of
% theta and beta power. It only calculates FRI if there are sufficient
% numbers of spikes (determined in Initial_Variables).  Otherwise, that
% cell is not included in this analysis.
Smoothing_Filter=fspecial('gaussian',[1,7],Gaussian_Smoothing_Sigma/Phase_Bin);  %A gaussian filter with a sigma defined above that extends 7 bins (3 in either direction) (same as used in IRFS_CALCULATE_PHASE_LOCKED_FIRING_FOR_EACH_NEURON)
Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window=zeros(10,2,max(Spike_Data(:,2)));
Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window=zeros(10,2,max(Spike_Data(:,2)));
Theta_ZScore_Power_By_Theta_Rank=zeros(10,1);
Beta_ZScore_Power_By_Beta_Rank=zeros(10,1);
Theta_ZScore_Power_By_Beta_Rank=zeros(10,1);
Beta_ZScore_Power_By_Theta_Rank=zeros(10,1);
LFP_Theta(2:end,7)=diff(LFP_Theta(:,1));
Good_Cells=find(sum(Firing_Rate_Per_Phase(:,:,1),2)>0); %These are the cells that had enough spikes to be included in the Firing Rate Index calculation
for Rank=1:(length(Rank_Steps)-1)
    Theta_Oscillation_Start_End_Times_In_This_Theta_Rank=Theta_Oscillation_Start_End_Times(Rank_By_Theta(round(Rank_Steps(Rank)):(round(Rank_Steps(Rank+1))-1)),:);
    Theta_Oscillation_Start_End_Times_In_This_Beta_Rank=Theta_Oscillation_Start_End_Times(Rank_By_Beta(round(Rank_Steps(Rank)):(round(Rank_Steps(Rank+1))-1)),:);
    %This marks the spikes that fired during the oscillations of this rank 
    Spike_Data(:,7:8)=0;
    LFP_Theta(:,8)=0;
    for Current_Theta_Window=1:size(Theta_Oscillation_Start_End_Times_In_This_Theta_Rank,1)
        Spike_Data(Spike_Data(:,1)>=Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(Current_Theta_Window,1) & Spike_Data(:,1)<=Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(Current_Theta_Window,2),7)=1;
        LFP_Theta(LFP_Theta(:,1)>=Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(Current_Theta_Window,1) & LFP_Theta(:,1)<=Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(Current_Theta_Window,2),8)=1;
    end
    clear Current_Theta_Window;
    Theta_ZScore_Power_By_Theta_Rank(Rank,1)=mean(LFP_Theta(LFP_Theta(:,8)==1,3));
    Beta_ZScore_Power_By_Theta_Rank(Rank,1)=mean(LFP_Beta(LFP_Theta(:,8)==1,3));
    Spikes_In_Current_Theta_Window=Spike_Data(Spike_Data(:,7)==1,:);
    LFP_Beta(:,4)=0;
    for Current_Beta_Window=1:size(Theta_Oscillation_Start_End_Times_In_This_Beta_Rank,1)
        Spike_Data(Spike_Data(:,1)>=Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(Current_Beta_Window,1) & Spike_Data(:,1)<=Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(Current_Beta_Window,2),8)=1;
        LFP_Beta(LFP_Beta(:,1)>=Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(Current_Beta_Window,1) & LFP_Beta(:,1)<=Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(Current_Beta_Window,2),4)=1;
    end
    clear Current_Beta_Window;
    Theta_ZScore_Power_By_Beta_Rank(Rank,1)=mean(LFP_Theta(LFP_Beta(:,4)==1,3));
    Beta_ZScore_Power_By_Beta_Rank(Rank,1)=mean(LFP_Beta(LFP_Beta(:,4)==1,3));
    Spikes_In_Current_Beta_Window=Spike_Data(Spike_Data(:,8)==1,:);
    %This calculates the Firing Rate Index
    Theta_FRI=zeros(max(Spike_Data(:,2)),ceil(360/Initial_Variables.Phase_Bin));
    Beta_FRI=zeros(max(Spike_Data(:,2)),ceil(360/Initial_Variables.Phase_Bin));
    for Current_Cell=1:max(Spike_Data(:,2))
        Current_Cell_Modality=Modality(Modality(:,2)==Current_Cell,1);
        ST=Spikes_In_Current_Theta_Window(Spikes_In_Current_Theta_Window(:,2)==Current_Cell,:);
        if sum(Good_Cells==Current_Cell)==1 %if this cell had enough spikes to be included in the Firing Rate Index calculation
            for M=1:size(Theta_FRI,2)
                Theta_FRI(Current_Cell,M)=sum(ST(:,3)>((Initial_Variables.Phase_Bin*M)-Initial_Variables.Phase_Bin) & ST(:,3)<=(Initial_Variables.Phase_Bin*M));
            end
            clear M;
            % This divides spike counts by duration for firing rates
            Theta_FRI(Current_Cell,:)=Theta_FRI(Current_Cell,:)/(sum(Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(:,2)-Theta_Oscillation_Start_End_Times_In_This_Theta_Rank(:,1))/size(Theta_FRI,2));
            % This smooths the phase-locked firing histograms
            S=filtfilt(Smoothing_Filter,1,[Theta_FRI(Current_Cell,:),Theta_FRI(Current_Cell,:)]);
            Theta_FRI(Current_Cell,:)=[S((size(Theta_FRI,2)+1):(size(Theta_FRI,2)+round(180/Initial_Variables.Phase_Bin))),S((round(180/Initial_Variables.Phase_Bin)+1):round(360/Initial_Variables.Phase_Bin))];
            Theta_FRI(Current_Cell,:)=(Theta_FRI(Current_Cell,:)-min(Theta_FRI(Current_Cell,:)))/max(Theta_FRI(Current_Cell,:));  %This is the true Firing Rate Index, which normalizes from 0 to up to 1 (but can be less than 1).
            clear S;
        else
            Theta_FRI(Current_Cell,:)=NaN;
        end
        clear ST;
        Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
        Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
        Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        if Current_Cell_Modality==1
            Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
            Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
            Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
            Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        elseif Current_Cell_Modality==2
            Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
            Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
            Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Theta_FRI,2)]));
            Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Theta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        end
        SB=Spikes_In_Current_Beta_Window(Spikes_In_Current_Beta_Window(:,2)==Current_Cell,:);
        if size(SB,1)>=Initial_Variables.Minimum_Spike_Count
            for M=1:size(Beta_FRI,2)
                Beta_FRI(Current_Cell,M)=sum(SB(:,3)>((Initial_Variables.Phase_Bin*M)-Initial_Variables.Phase_Bin) & SB(:,3)<=(Initial_Variables.Phase_Bin*M));
            end
            clear M;
            % This divides spike counts by duration for firing rates
            Beta_FRI(Current_Cell,:)=Beta_FRI(Current_Cell,:)/(sum(Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(:,2)-Theta_Oscillation_Start_End_Times_In_This_Beta_Rank(:,1))/size(Beta_FRI,2));
            % This smooths the phase-locked firing histograms
            S=filtfilt(Smoothing_Filter,1,[Beta_FRI(Current_Cell,:),Beta_FRI(Current_Cell,:)]);
            Beta_FRI(Current_Cell,:)=[S((size(Beta_FRI,2)+1):(size(Beta_FRI,2)+round(180/Initial_Variables.Phase_Bin))),S((round(180/Initial_Variables.Phase_Bin)+1):round(360/Initial_Variables.Phase_Bin))];
            Beta_FRI(Current_Cell,:)=(Beta_FRI(Current_Cell,:)-min(Beta_FRI(Current_Cell,:)))/max(Beta_FRI(Current_Cell,:));  %This is the true Firing Rate Index, which normalizes from 0 to up to 1 (but can be less than 1).
            clear S;
        else
            Beta_FRI(Current_Cell,:)=NaN;
        end
        clear SB;
        Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
        Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
        Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        if Current_Cell_Modality==1
            Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
            Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
            Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
            Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        elseif Current_Cell_Modality==2
            Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
            Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,Current_Cell)=mean(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
            Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,[1:round(Major_Peak_Window(2)/Initial_Variables.Phase_Bin),round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):size(Beta_FRI,2)]));
            Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,Current_Cell)=max(Beta_FRI(Current_Cell,round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin)));
        end
    end
    clear Current_Cell;
    clear Theta_FRI;
    clear Beta_FRI;
end
Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(:,:,Modality(:,1)==1);
Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(:,:,Modality(:,1)==1);
Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(:,:,Modality(:,1)==1);
Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(:,:,Modality(:,1)==1);
Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(:,:,Modality(:,1)==2);
Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(:,:,Modality(:,1)==2);
Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(:,:,Modality(:,1)==2);
Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(:,:,Modality(:,1)==2);
clear Rank;
clear Smoothing_Filter;
% Firing_Rate_Index_By_Theta/Beta_Rank_Average_Major/Minor_Window
% (Each row is a rank)
% |                   1                     |                  2                  |                     3                  |                     4              || 
% | Average of Mean Across Qualifying Cells | SEM of Mean Across Qualifying Cells | Average of Max Across Qualifying Cells | SEM of Max Across Qualifying Cells || 
Firing_Rate_Index_By_Theta_Rank_Average_Major_Window=zeros(10,4);
Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window=zeros(10,4);
Firing_Rate_Index_By_Beta_Rank_Average_Major_Window=zeros(10,4);
Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window=zeros(10,4);
Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window=zeros(10,4);
Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window=zeros(10,4);
Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window=zeros(10,4);
Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window=zeros(10,4);
Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window=zeros(10,4);
Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window=zeros(10,4);
Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window=zeros(10,4);
Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window=zeros(10,4);
for Rank=1:10
    Theta_Major_Average_Mean=Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Theta_Major_Average_Mean=Theta_Major_Average_Mean(~isnan(Theta_Major_Average_Mean));
    Theta_Major_Average_Max=Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Theta_Major_Average_Max=Theta_Major_Average_Max(~isnan(Theta_Major_Average_Max));
    Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(Rank,:)=[mean(Theta_Major_Average_Mean(:)),std(Theta_Major_Average_Mean(:))/sqrt(length(Theta_Major_Average_Mean(:))),mean(Theta_Major_Average_Max(:)),std(Theta_Major_Average_Max(:))/sqrt(length(Theta_Major_Average_Max(:)))];
    Theta_Minor_Average_Mean=Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Theta_Minor_Average_Mean=Theta_Minor_Average_Mean(~isnan(Theta_Minor_Average_Mean));
    Theta_Minor_Average_Max=Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Theta_Minor_Average_Max=Theta_Minor_Average_Max(~isnan(Theta_Minor_Average_Max));
    Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(Rank,:)=[mean(Theta_Minor_Average_Mean(:)),std(Theta_Minor_Average_Mean(:))/sqrt(length(Theta_Minor_Average_Mean(:))),mean(Theta_Minor_Average_Max(:)),std(Theta_Minor_Average_Max(:))/sqrt(length(Theta_Minor_Average_Max(:)))];
    Beta_Major_Average_Mean=Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Beta_Major_Average_Mean=Beta_Major_Average_Mean(~isnan(Beta_Major_Average_Mean));
    Beta_Major_Average_Max=Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Beta_Major_Average_Max=Beta_Major_Average_Max(~isnan(Beta_Major_Average_Max));
    Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(Rank,:)=[mean(Beta_Major_Average_Mean(:)),std(Beta_Major_Average_Mean(:))/sqrt(length(Beta_Major_Average_Mean(:))),mean(Beta_Major_Average_Max(:)),std(Beta_Major_Average_Max(:))/sqrt(length(Beta_Major_Average_Max(:)))];
    Beta_Minor_Average_Mean=Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Beta_Minor_Average_Mean=Beta_Minor_Average_Mean(~isnan(Beta_Minor_Average_Mean));
    Beta_Minor_Average_Max=Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Beta_Minor_Average_Max=Beta_Minor_Average_Max(~isnan(Beta_Minor_Average_Max));
    Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(Rank,:)=[mean(Beta_Minor_Average_Mean(:)),std(Beta_Minor_Average_Mean(:))/sqrt(length(Beta_Minor_Average_Mean(:))),mean(Beta_Minor_Average_Max(:)),std(Beta_Minor_Average_Max(:))/sqrt(length(Beta_Minor_Average_Max(:)))];
    
    Unimodal_Theta_Major_Average_Mean=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Unimodal_Theta_Major_Average_Mean=Unimodal_Theta_Major_Average_Mean(~isnan(Unimodal_Theta_Major_Average_Mean));
    Unimodal_Theta_Major_Average_Max=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Unimodal_Theta_Major_Average_Max=Unimodal_Theta_Major_Average_Max(~isnan(Unimodal_Theta_Major_Average_Max));
    Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(Rank,:)=[mean(Unimodal_Theta_Major_Average_Mean(:)),std(Unimodal_Theta_Major_Average_Mean(:))/sqrt(length(Unimodal_Theta_Major_Average_Mean(:))),mean(Unimodal_Theta_Major_Average_Max(:)),std(Unimodal_Theta_Major_Average_Max(:))/sqrt(length(Unimodal_Theta_Major_Average_Max(:)))];
    Unimodal_Theta_Minor_Average_Mean=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Unimodal_Theta_Minor_Average_Mean=Unimodal_Theta_Minor_Average_Mean(~isnan(Unimodal_Theta_Minor_Average_Mean));
    Unimodal_Theta_Minor_Average_Max=Unimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Unimodal_Theta_Minor_Average_Max=Unimodal_Theta_Minor_Average_Max(~isnan(Unimodal_Theta_Minor_Average_Max));
    Unimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(Rank,:)=[mean(Unimodal_Theta_Minor_Average_Mean(:)),std(Unimodal_Theta_Minor_Average_Mean(:))/sqrt(length(Unimodal_Theta_Minor_Average_Mean(:))),mean(Unimodal_Theta_Minor_Average_Max(:)),std(Unimodal_Theta_Minor_Average_Max(:))/sqrt(length(Unimodal_Theta_Minor_Average_Max(:)))];
    Unimodal_Beta_Major_Average_Mean=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Unimodal_Beta_Major_Average_Mean=Unimodal_Beta_Major_Average_Mean(~isnan(Unimodal_Beta_Major_Average_Mean));
    Unimodal_Beta_Major_Average_Max=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Unimodal_Beta_Major_Average_Max=Unimodal_Beta_Major_Average_Max(~isnan(Unimodal_Beta_Major_Average_Max));
    Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(Rank,:)=[mean(Unimodal_Beta_Major_Average_Mean(:)),std(Unimodal_Beta_Major_Average_Mean(:))/sqrt(length(Unimodal_Beta_Major_Average_Mean(:))),mean(Unimodal_Beta_Major_Average_Max(:)),std(Unimodal_Beta_Major_Average_Max(:))/sqrt(length(Unimodal_Beta_Major_Average_Max(:)))];
    Unimodal_Beta_Minor_Average_Mean=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Unimodal_Beta_Minor_Average_Mean=Unimodal_Beta_Minor_Average_Mean(~isnan(Unimodal_Beta_Minor_Average_Mean));
    Unimodal_Beta_Minor_Average_Max=Unimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Unimodal_Beta_Minor_Average_Max=Unimodal_Beta_Minor_Average_Max(~isnan(Unimodal_Beta_Minor_Average_Max));
    Unimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(Rank,:)=[mean(Unimodal_Beta_Minor_Average_Mean(:)),std(Unimodal_Beta_Minor_Average_Mean(:))/sqrt(length(Unimodal_Beta_Minor_Average_Mean(:))),mean(Unimodal_Beta_Minor_Average_Max(:)),std(Unimodal_Beta_Minor_Average_Max(:))/sqrt(length(Unimodal_Beta_Minor_Average_Max(:)))];

    Bimodal_Theta_Major_Average_Mean=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Bimodal_Theta_Major_Average_Mean=Bimodal_Theta_Major_Average_Mean(~isnan(Bimodal_Theta_Major_Average_Mean));
    Bimodal_Theta_Major_Average_Max=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Bimodal_Theta_Major_Average_Max=Bimodal_Theta_Major_Average_Max(~isnan(Bimodal_Theta_Major_Average_Max));
    Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Major_Window(Rank,:)=[mean(Bimodal_Theta_Major_Average_Mean(:)),std(Bimodal_Theta_Major_Average_Mean(:))/sqrt(length(Bimodal_Theta_Major_Average_Mean(:))),mean(Bimodal_Theta_Major_Average_Max(:)),std(Bimodal_Theta_Major_Average_Max(:))/sqrt(length(Bimodal_Theta_Major_Average_Max(:)))];
    Bimodal_Theta_Minor_Average_Mean=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Bimodal_Theta_Minor_Average_Mean=Bimodal_Theta_Minor_Average_Mean(~isnan(Bimodal_Theta_Minor_Average_Mean));
    Bimodal_Theta_Minor_Average_Max=Bimodal_Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Bimodal_Theta_Minor_Average_Max=Bimodal_Theta_Minor_Average_Max(~isnan(Bimodal_Theta_Minor_Average_Max));
    Bimodal_Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window(Rank,:)=[mean(Bimodal_Theta_Minor_Average_Mean(:)),std(Bimodal_Theta_Minor_Average_Mean(:))/sqrt(length(Bimodal_Theta_Minor_Average_Mean(:))),mean(Bimodal_Theta_Minor_Average_Max(:)),std(Bimodal_Theta_Minor_Average_Max(:))/sqrt(length(Bimodal_Theta_Minor_Average_Max(:)))];
    Bimodal_Beta_Major_Average_Mean=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,1,:);
    Bimodal_Beta_Major_Average_Mean=Bimodal_Beta_Major_Average_Mean(~isnan(Bimodal_Beta_Major_Average_Mean));
    Bimodal_Beta_Major_Average_Max=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window(Rank,2,:);
    Bimodal_Beta_Major_Average_Max=Bimodal_Beta_Major_Average_Max(~isnan(Bimodal_Beta_Major_Average_Max));
    Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Major_Window(Rank,:)=[mean(Bimodal_Beta_Major_Average_Mean(:)),std(Bimodal_Beta_Major_Average_Mean(:))/sqrt(length(Bimodal_Beta_Major_Average_Mean(:))),mean(Bimodal_Beta_Major_Average_Max(:)),std(Bimodal_Beta_Major_Average_Max(:))/sqrt(length(Bimodal_Beta_Major_Average_Max(:)))];
    Bimodal_Beta_Minor_Average_Mean=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,1,:);
    Bimodal_Beta_Minor_Average_Mean=Bimodal_Beta_Minor_Average_Mean(~isnan(Bimodal_Beta_Minor_Average_Mean));
    Bimodal_Beta_Minor_Average_Max=Bimodal_Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window(Rank,2,:);
    Bimodal_Beta_Minor_Average_Max=Bimodal_Beta_Minor_Average_Max(~isnan(Bimodal_Beta_Minor_Average_Max));
    Bimodal_Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window(Rank,:)=[mean(Bimodal_Beta_Minor_Average_Mean(:)),std(Bimodal_Beta_Minor_Average_Mean(:))/sqrt(length(Bimodal_Beta_Minor_Average_Mean(:))),mean(Bimodal_Beta_Minor_Average_Max(:)),std(Bimodal_Beta_Minor_Average_Max(:))/sqrt(length(Bimodal_Beta_Minor_Average_Max(:)))];
end
clear Rank;
clear Theta_Major_Average_Mean;
clear Theta_Major_Average_Max;
clear Theta_Minor_Average_Mean;
clear Theta_Minor_Average_Max;
clear Beta_Major_Average_Mean;
clear Beta_Major_Average_Max;
clear Beta_Minor_Average_Mean;
clear Beta_Minor_Average_Max;
Spike_Data=Spike_Data(:,1:6);
LFP_Theta=LFP_Theta(:,1:6);
LFP_Beta=LFP_Beta(:,1:3);

save('Theta_And_Beta_Power_Correlated_To_Firing_Rate_Index','Bimodal_*','Unimodal_*','Firing_Rate_Index_By_Theta_Rank_Each_Cell_Major_Window','Firing_Rate_Index_By_Theta_Rank_Each_Cell_Minor_Window','Firing_Rate_Index_By_Beta_Rank_Each_Cell_Major_Window','Firing_Rate_Index_By_Beta_Rank_Each_Cell_Minor_Window','Theta_ZScore_Power_By_Theta_Rank','Beta_ZScore_Power_By_Beta_Rank','Theta_ZScore_Power_By_Beta_Rank','Beta_ZScore_Power_By_Theta_Rank','Firing_Rate_Index_By_Theta_Rank_Average_Major_Window','Firing_Rate_Index_By_Theta_Rank_Average_Minor_Window','Firing_Rate_Index_By_Beta_Rank_Average_Major_Window','Firing_Rate_Index_By_Beta_Rank_Average_Minor_Window','-v7.3');
    
