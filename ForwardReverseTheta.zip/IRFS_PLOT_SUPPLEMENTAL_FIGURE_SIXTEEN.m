function IRFS_PLOT_SUPPLEMENTAL_FIGURE_SIXTEEN

if exist('AllRatsCombined','dir')==7
    cd AllRatsCombined
else
    mkdir AllRatsCombined
    cd AllRatsCombined
end

load Combined_Theta_And_Beta_Power_Vs_Firing_Rates

if exist('_Figures_For_Paper','dir')==7
    cd _Figures_For_Paper
else
    mkdir _Figures_For_Paper
    cd _Figures_For_Paper
end

if exist('SupplementalFigure11','dir')==7
    cd SupplementalFigure16
else
    mkdir SupplementalFigure16
    cd SupplementalFigure16
end

All_Color_Values=jet;

%This plots Major Peak Window FRI as a function of Theta Power for Unimodal cells for Linear Track sessions 
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_E_Left(Linear_Unimodal_Theta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Beta Power for Unimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_G_Left(Linear_Unimodal_Beta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Theta Power for Unimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_F_Left(Linear_Unimodal_Theta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Beta Power for Unimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_H_Left(Linear_Unimodal_Beta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Theta Power for Bimodal cells for Linear Track sessions 
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_E_Right(Linear_Bimodal_Theta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Beta Power for Bimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_Linear_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_G_Right(Linear_Bimodal_Beta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Theta Power for Bimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_F_Right(Linear_Bimodal_Theta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Beta Power for Bimodal cells for Linear Track sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/10:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_Linear_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_H_Right(Linear_Bimodal_Beta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Theta Power for Unimodal cells for Open Field sessions 
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Unimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_A_Left(OpenField_Unimodal_Theta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Beta Power for Unimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Unimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_C_Left(OpenField_Unimodal_Beta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Theta Power for Unimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Unimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_B_Left(OpenField_Unimodal_Theta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Beta Power for Unimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Unimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_D_Left(OpenField_Unimodal_Beta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Theta Power for Bimodal cells for Open Field sessions 
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1),All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Bimodal_Theta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_A_Right(OpenField_Bimodal_Theta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Major Peak Window FRI as a function of Beta Power for Bimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Major_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1),All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,2),1),[min(All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1));max(All_OpenField_Bimodal_Beta_Power_Vs_Major_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_C_Right(OpenField_Bimodal_Beta_Power_Vs_Major_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Theta Power for Bimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1),All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Bimodal_Theta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_B_Right(OpenField_Bimodal_Theta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close

%This plots Minor Peak Window FRI as a function of Beta Power for Bimodal cells for Open Field sessions  
Color_Values=All_Color_Values(round(1:size(All_Color_Values,1)/6:size(All_Color_Values,1)),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
Current_Color=0;
for Rat=3:-1:1
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        Directory_Name=Directory(Experiment).name;
        Current_Color=Current_Color+1;
        eval(sprintf('plot(%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),''o'',''MarkerSize'',4,''MarkerEdgeColor'',Color_Values(Current_Color,:));',Rat_Name,Directory_Name,Rat_Name,Directory_Name))
        eval(sprintf('Best_Fit_Line=[[%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)],polyval(polyfit(%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(1,1);%s_%s_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(end,1)])];',Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name,Rat_Name,Directory_Name));
        plot(Best_Fit_Line(:,1),Best_Fit_Line(:,2),'LineWidth',2,'Color',Color_Values(Current_Color,:));
    end
    clear Directory
end
All_Best_Fit_Line=[[min(All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))],polyval(polyfit(All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1),All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,2),1),[min(All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1));max(All_OpenField_Bimodal_Beta_Power_Vs_Minor_Peak_FRI(:,1))])];
plot(All_Best_Fit_Line(:,1),All_Best_Fit_Line(:,2),'k','LineWidth',5);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
%[P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data); %Not currently implemented -- currently using R package for this calculation (Bakdash & Marusich, 2017) 
eval(sprintf('print(''-djpeg'',''Supplemental_Figure_16_D_Right(OpenField_Bimodal_Beta_Power_Vs_Minor_FRI)(X=(%d-%d),Y=(%d-%d)).jpg'');',X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
close


cd ..
cd ..
cd ..



end