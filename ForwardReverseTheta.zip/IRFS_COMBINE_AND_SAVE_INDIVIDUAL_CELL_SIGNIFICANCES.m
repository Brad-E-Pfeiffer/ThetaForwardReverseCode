function IRFS_COMBINE_AND_SAVE_INDIVIDUAL_CELL_SIGNIFICANCES

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up all of the linear correlation significance
% quantifications for each session and combines them.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
        Directory(7).name='Open1';
        Directory(8).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Open1';
        Directory(4).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Phase_Position_Significances_Per_Cell;
        
        if strcmp(Directory_Name(1),'O')
            if exist('Open_Sig','var')
                Open_Sig=[Open_Sig;Phase_Position_Significances];
                Open_Sig_Restricted=[Open_Sig_Restricted;Phase_Position_Significances_Restricted_Positions];
            else
                Open_Sig=Phase_Position_Significances;
                Open_Sig_Restricted=Phase_Position_Significances_Restricted_Positions;
            end
            if exist('All_Sig','var')
                All_Sig=[All_Sig;Phase_Position_Significances];
                All_Sig_Restricted=[All_Sig_Restricted;Phase_Position_Significances_Restricted_Positions];
            else
                All_Sig=Phase_Position_Significances;
                All_Sig_Restricted=Phase_Position_Significances_Restricted_Positions;
            end
        else
            if exist('Out_Sig','var')
                Out_Sig=[Out_Sig;Out_Phase_Position_Significances];
                In_Sig=[In_Sig;In_Phase_Position_Significances];
                Out_Sig_Restricted=[Out_Sig_Restricted;Out_Phase_Position_Significances_Restricted_Positions];
                In_Sig_Restricted=[In_Sig_Restricted;In_Phase_Position_Significances_Restricted_Positions];
            else
                Out_Sig=Out_Phase_Position_Significances;
                In_Sig=In_Phase_Position_Significances;
                Out_Sig_Restricted=Out_Phase_Position_Significances_Restricted_Positions;
                In_Sig_Restricted=In_Phase_Position_Significances_Restricted_Positions;
            end
            if exist('All_Sig','var')
                All_Sig=[All_Sig;Out_Phase_Position_Significances;In_Phase_Position_Significances];
                All_Sig_Restricted=[All_Sig_Restricted;Out_Phase_Position_Significances_Restricted_Positions;In_Phase_Position_Significances_Restricted_Positions];
            else
                All_Sig=[Out_Phase_Position_Significances;In_Phase_Position_Significances];
                All_Sig_Restricted=[Out_Phase_Position_Significances_Restricted_Positions;In_Phase_Position_Significances_Restricted_Positions];
            end
        end
        
        cd ..
        
    end
    clear Directory
    clear Directory_Name
    cd ..
    
end

cd AllRatsCombined
save('Combined_Single_Cell_Phase_Position_Significances','Open_Sig*','All_Sig*','Out_Sig*','In_Sig*','-v7.3')
clear Rat
clear Rat_Name
clear Experiment
clear Rats
cd ..


end


