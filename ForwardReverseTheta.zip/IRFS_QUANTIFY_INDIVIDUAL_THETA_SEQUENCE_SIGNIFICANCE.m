function IRFS_QUANTIFY_INDIVIDUAL_THETA_SEQUENCE_SIGNIFICANCE(Decoded_Data,Decoding_Time_Info,Decoding_Window_Index,Decoding_Times,Unimodal_Decoded_Data,Unimodal_Decoding_Window_Index,Bimodal_Decoded_Data,Bimodal_Decoding_Window_Index,Number_Of_Shuffles,Forward_Window,Reverse_Window,Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up the data for each theta oscillation and quantifies
% the sequence score of the Forward and Reverse Window across each shuffle.
% This distribution is then used to quantify the significance of each
% actual theta oscillation.  The sequence score is based on the replay
% score defined in Davidson et al., Neuron, 2009.  
% 
% Two shuffles are used to quantify individual oscillation significance: a
% cell ID shuffle and a posterior probability shuffle.  The cell ID shuffle
% was generated in IRFS_THETA_SEQUENCE_SHUFFLE_GENERATION and the posterior
% probability shuffle is simply a 'rotation' of the posterior probabilities
% of each decoding window of the actual data, and that is performed in this
% function. 
% 
% Two Monte-Carlo p-values are quantified for the two shuffle methods based
% on the number of shuffles that meet or exceed the sequence score of the
% actual decoding of that oscillation.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

warning('off','all') %A large number of shuffles have very poor best-fit lines, and each one gives a warning, so I'm turning this off temporarily
Decoding_Info=Decoding_Time_Info(Decoding_Window_Index,:);
Subset_Decoding_Times=Decoding_Times(Decoding_Window_Index,:);

if exist('Individual_Theta_Sequence_P_Values.mat','file')~=2
    cd Shuffles
    
    % Forward/Reverse_Cell_ID/Probability_Shuffle_Sequence_Scores_Per_Oscillation
    % |      1         |               2                 ||
    % | Sequence Score | Slope of Weighted Best-Fit Line ||
    
    % This calculates the sequence score of the cell ID shuffles
    Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation=zeros(max(Decoding_Time_Info(:,14)),2,Number_Of_Shuffles);
    Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation=zeros(max(Decoding_Time_Info(:,14)),2,Number_Of_Shuffles);
    for Current_Shuffle=1:Number_Of_Shuffles
        eval(sprintf('load(''Shuffle_Data_%d'',''Decoded_Shuffle_Data'',''Decoded_Shuffle_Sequence'');',Current_Shuffle));
        Decoded_Shuffle_Data=Decoded_Shuffle_Data;
        parfor Current_Oscillation=1:max(Decoding_Time_Info(:,14))
            if sum(Decoding_Info(:,14)==Current_Oscillation)>0
                warning('off','all')
                Forward_Sequence_Data=Decoded_Shuffle_Data(:,Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Forward_Window(1) | Decoding_Info(:,6)<=Forward_Window(2)));
                Reverse_Sequence_Data=Decoded_Shuffle_Data(:,Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Reverse_Window(1) & Decoding_Info(:,6)<=Reverse_Window(2)));
                if size(Forward_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                    [Forward_Shuffle_Score,Forward_Shuffle_Slope]=IRFS_SEQUENCE_SCORE(Forward_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                else
                     Forward_Shuffle_Score=0;
                     Forward_Shuffle_Slope=0;
                end
                if size(Reverse_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                    [Reverse_Shuffle_Score,Reverse_Shuffle_Slope]=IRFS_SEQUENCE_SCORE(Reverse_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                else
                     Reverse_Shuffle_Score=0;
                     Reverse_Shuffle_Slope=0;
                end
                Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,:,Current_Shuffle)=[Forward_Shuffle_Score,Forward_Shuffle_Slope];
                Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,:,Current_Shuffle)=[Reverse_Shuffle_Score,Reverse_Shuffle_Slope];
            end
        end
        %disp(sprintf('Finished calculating sequence scores for shuffle %d.',Current_Shuffle))
    end
    cd ..
    
    % Forward/Reverse_Sequence_Scores_Slopes_And_P_Values (a value of -2 indicates that this oscillation wasn't analyzed, typically because the rat wasn't moving) 
    % |        1       |                2                |            3            |                    4                  ||
    % | Sequence Score | Slope of Weighted Best-Fit Line | Cell ID Shuffle P-Value | Posterior Probability Shuffle P-Value ||
    
    Forward_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    Reverse_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    Theta_Cycle_Start_End_Times=-2*ones(max(Decoding_Time_Info(:,14)),2);
    Forward_Start_End_Times=-2*ones(max(Decoding_Time_Info(:,14)),2);
    Reverse_Start_End_Times=-2*ones(max(Decoding_Time_Info(:,14)),2);
    Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation=zeros(max(Decoding_Time_Info(:,14)),2,Number_Of_Shuffles);
    Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation=zeros(max(Decoding_Time_Info(:,14)),2,Number_Of_Shuffles);
    for Current_Oscillation=1:max(Decoding_Time_Info(:,14))
        if sum(Decoding_Info(:,14)==Current_Oscillation)>0
            % This calculates the sequence score of the actual data 
            Theta_Cycle_Start_End_Times(Current_Oscillation,:)=[min(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation)),max(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation))];
            Forward_Sequence_Data=Decoded_Data(:,Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Forward_Window(1) | Decoding_Info(:,6)<=Forward_Window(2)));
            Reverse_Sequence_Data=Decoded_Data(:,Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Reverse_Window(1) & Decoding_Info(:,6)<=Reverse_Window(2)));
            if size(Forward_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                [Forward_Score,Forward_Slope]=IRFS_SEQUENCE_SCORE(Forward_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                Forward_Start_End_Times(Current_Oscillation,:)=[min(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Forward_Window(1) | Decoding_Info(:,6)<=Forward_Window(2)))),max(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Forward_Window(1) | Decoding_Info(:,6)<=Forward_Window(2))))];
            else
                Forward_Score=0;
                Forward_Slope=0;
            end
            if size(Reverse_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                [Reverse_Score,Reverse_Slope]=IRFS_SEQUENCE_SCORE(Reverse_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                Reverse_Start_End_Times(Current_Oscillation,:)=[min(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Reverse_Window(1) & Decoding_Info(:,6)<=Reverse_Window(2)))),max(Subset_Decoding_Times(Decoding_Info(:,14)==Current_Oscillation & (Decoding_Info(:,6)>=Reverse_Window(1) & Decoding_Info(:,6)<=Reverse_Window(2))))];
            else
                Reverse_Score=0;
                Reverse_Slope=0;
            end
            
            %This resets the random number generator
            Current_Time=clock;
            eval(sprintf('rng(round(sqrt(%d%d%d%d%d%d)));',round(Current_Time(6)*1000),Current_Time(5),Current_Time(4),Current_Time(3),Current_Time(2),Current_Time(1)-2000));
            clear Current_Time;
            
            % This calculates the sequence score of the posterior probability shuffles 
            parfor Current_Shuffle=1:Number_Of_Shuffles
                warning('off','all')
                if size(Forward_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                    Forward_Shuffle_Sequence_Data=Forward_Sequence_Data;
                    for N=1:size(Forward_Shuffle_Sequence_Data,2)
                        Forward_Shuffle_Sequence_Data(:,N)=circshift(Forward_Shuffle_Sequence_Data(:,N),ceil(rand(1)*size(Forward_Sequence_Data,1)));
                    end
                    [Forward_Shuffle_Score,Forward_Shuffle_Slope]=IRFS_SEQUENCE_SCORE(Forward_Shuffle_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                else
                    Forward_Shuffle_Score=0;
                    Forward_Shuffle_Slope=0;
                end
                Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,:,Current_Shuffle)=[Forward_Shuffle_Score,Forward_Shuffle_Slope];
                if size(Reverse_Sequence_Data,2)>1 %a very few oscillations don't have sufficient numbers of decoding windows, so we define these as having a score and slope of 0.  
                    Reverse_Shuffle_Sequence_Data=Reverse_Sequence_Data;
                    for N=1:size(Reverse_Shuffle_Sequence_Data,2)
                        Reverse_Shuffle_Sequence_Data(:,N)=circshift(Reverse_Shuffle_Sequence_Data(:,N),ceil(rand(1)*size(Reverse_Sequence_Data,1)));
                    end
                    [Reverse_Shuffle_Score,Reverse_Shuffle_Slope]=IRFS_SEQUENCE_SCORE(Reverse_Shuffle_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
                else
                    Reverse_Shuffle_Score=0;
                    Reverse_Shuffle_Slope=0;
                end
                Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,:,Current_Shuffle)=[Reverse_Shuffle_Score,Reverse_Shuffle_Slope];
            end
            
            % This puts the actual data into an array and calculates the cell ID and probability shuffle p-values 
            Forward_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Forward_Score,Forward_Slope,(sum(sum(sum(abs(Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Forward_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Forward_Score))))+1)/(Number_Of_Shuffles+1)];
            Reverse_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Reverse_Score,Reverse_Slope,(sum(sum(sum(abs(Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Reverse_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Reverse_Score))))+1)/(Number_Of_Shuffles+1)];
            
        end
    end
    
    % This calculates the total number of qualifying theta oscillations
    % with a significant forward sequence, a significant reverse sequence,
    % and the p-value of the percent of oscillations with both significant
    % forward and reverse sequences in the same oscillation
    
    Qualifying_Oscillation_Count=sum(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2);
    Significant_Forward_Sequence_Percent=sum(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Reverse_Sequence_Percent=sum(Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Positive_Forward_Sequence_Percent=sum(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Negative_Forward_Sequence_Percent=sum(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Positive_Reverse_Sequence_Percent=sum(Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Negative_Reverse_Sequence_Percent=sum(Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Significant_Positive_Forward_Negative_Reverse_Sequence_Percent=sum(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05)/Qualifying_Oscillation_Count;
    Forward_And_Reverse_Sequence_In_Same_Oscillation_P_Value=binocdf(Significant_Positive_Forward_Negative_Reverse_Sequence_Percent,Qualifying_Oscillation_Count,Significant_Positive_Forward_Sequence_Percent*Significant_Negative_Reverse_Sequence_Percent);
    
    fprintf('%d%% theta oscillations have a signficant positive forward sequence; %d%% have a significant negative forward sequence.\n',Significant_Positive_Forward_Sequence_Percent*100,Significant_Negative_Forward_Sequence_Percent*100)
    fprintf('%d%% theta oscillations have a signficant negative reverse sequence; %d%% have a significant positive reverse sequence.\n',Significant_Negative_Reverse_Sequence_Percent*100,Significant_Positive_Reverse_Sequence_Percent*100)
    fprintf('%d%% theta oscillation have both a positive forward and negative reverse sequence. P-value is %d.\n',Significant_Positive_Forward_Negative_Reverse_Sequence_Percent*100,Forward_And_Reverse_Sequence_In_Same_Oscillation_P_Value)
    
    save('Individual_Theta_Sequence_P_Values','Forward_Sequence_Scores_Slopes_And_P_Values','Reverse_Sequence_Scores_Slopes_And_P_Values','Theta_Cycle_Start_End_Times','Forward_Start_End_Times','Reverse_Start_End_Times','Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation','Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation','Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation','Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation','Qualifying_Oscillation_Count','*_Percent','*_P_Value');
    
else
    load Individual_Theta_Sequence_P_Values
end
warning('on','all')

% This quantifies the Sequence Scores for every oscillation decoded only
% with unimodal or only with bimodal neurons and compares them to the
% shuffle distributions above.  (It would take months to repeat the cell ID
% shuffles for both bimodal and unimodal cell decoding, so I'm cheating a
% little bit by comparing the Unimodal-Only Sequence Scores and
% Bimodal-Only Sequence Scores to the shuffle sequence scores using all
% cells.  I don't anticipate this will impact the ultimate results.)

if exist('Individual_Bimodal_Theta_Sequence_P_Values.mat','file')~=2
    
    Unimodal_Decoding_Info=Decoding_Time_Info(Unimodal_Decoding_Window_Index,:);
    Bimodal_Decoding_Info=Decoding_Time_Info(Bimodal_Decoding_Window_Index,:);
    
    % Unimodal/Bimodal_Forward/Reverse_Sequence_Scores_Slopes_And_P_Values (a value of -2 indicates that this oscillation wasn't analyzed, typically because the rat wasn't moving) 
    % |        1       |                2                |            3            |                    4                  ||
    % | Sequence Score | Slope of Weighted Best-Fit Line | Cell ID Shuffle P-Value | Posterior Probability Shuffle P-Value ||
    
    Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values=-2*ones(max(Decoding_Time_Info(:,14)),4);
    for Current_Oscillation=1:max(Decoding_Time_Info(:,14))
        if sum(Unimodal_Decoding_Info(:,14)==Current_Oscillation)>0
            % This calculates the sequence score of the actual unimodal data 
            Unimodal_Forward_Sequence_Data=Unimodal_Decoded_Data(:,Unimodal_Decoding_Info(:,14)==Current_Oscillation & (Unimodal_Decoding_Info(:,6)>=Forward_Window(1) | Unimodal_Decoding_Info(:,6)<=Forward_Window(2)));
            Unimodal_Reverse_Sequence_Data=Unimodal_Decoded_Data(:,Unimodal_Decoding_Info(:,14)==Current_Oscillation & (Unimodal_Decoding_Info(:,6)>=Reverse_Window(1) & Unimodal_Decoding_Info(:,6)<=Reverse_Window(2)));
            if size(Unimodal_Forward_Sequence_Data,2)>1
                [Unimodal_Forward_Score,Unimodal_Forward_Slope]=IRFS_SEQUENCE_SCORE(Unimodal_Forward_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
            else
                Unimodal_Forward_Score=-2;
                Unimodal_Forward_Slope=-2;
            end
            if size(Unimodal_Reverse_Sequence_Data,2)>1
                [Unimodal_Reverse_Score,Unimodal_Reverse_Slope]=IRFS_SEQUENCE_SCORE(Unimodal_Reverse_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
            else
                Unimodal_Reverse_Score=-2;
                Unimodal_Reverse_Slope=-2;
            end
            % This calculates the sequence score of the actual bimodal data 
            Bimodal_Forward_Sequence_Data=Bimodal_Decoded_Data(:,Bimodal_Decoding_Info(:,14)==Current_Oscillation & (Bimodal_Decoding_Info(:,6)>=Forward_Window(1) | Bimodal_Decoding_Info(:,6)<=Forward_Window(2)));
            Bimodal_Reverse_Sequence_Data=Bimodal_Decoded_Data(:,Bimodal_Decoding_Info(:,14)==Current_Oscillation & (Bimodal_Decoding_Info(:,6)>=Reverse_Window(1) & Bimodal_Decoding_Info(:,6)<=Reverse_Window(2)));
            if size(Bimodal_Forward_Sequence_Data,2)>1
                [Bimodal_Forward_Score,Bimodal_Forward_Slope]=IRFS_SEQUENCE_SCORE(Bimodal_Forward_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
            else
                Bimodal_Forward_Score=-2;
                Bimodal_Forward_Slope=-2;
            end
            if size(Bimodal_Reverse_Sequence_Data,2)>1
                [Bimodal_Reverse_Score,Bimodal_Reverse_Slope]=IRFS_SEQUENCE_SCORE(Bimodal_Reverse_Sequence_Data,Initial_Variables.Sequence_Score_Distance/Initial_Variables.Bin_Size);
            else
                Bimodal_Reverse_Score=-2;
                Bimodal_Reverse_Slope=-2;
            end
            
            %This resets the random number generator
            Current_Time=clock;
            eval(sprintf('rng(round(sqrt(%d%d%d%d%d%d)));',round(Current_Time(6)*1000),Current_Time(5),Current_Time(4),Current_Time(3),Current_Time(2),Current_Time(1)-2000));
            clear Current_Time;
            
            % This puts the actual data into an array and calculates the cell ID and probability shuffle p-values 
            Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Unimodal_Forward_Score,Unimodal_Forward_Slope,(sum(sum(sum(abs(Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Unimodal_Forward_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Unimodal_Forward_Score))))+1)/(Number_Of_Shuffles+1)];
            Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Unimodal_Reverse_Score,Unimodal_Reverse_Slope,(sum(sum(sum(abs(Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Unimodal_Reverse_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Unimodal_Reverse_Score))))+1)/(Number_Of_Shuffles+1)];
            Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Bimodal_Forward_Score,Bimodal_Forward_Slope,(sum(sum(sum(abs(Forward_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Bimodal_Forward_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Forward_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Bimodal_Forward_Score))))+1)/(Number_Of_Shuffles+1)];
            Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(Current_Oscillation,1:4)=[Bimodal_Reverse_Score,Bimodal_Reverse_Slope,(sum(sum(sum(abs(Reverse_Cell_ID_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Bimodal_Reverse_Score))))+1)/(Number_Of_Shuffles+1),(sum(sum(sum(abs(Reverse_Probability_Shuffle_Sequence_Scores_Per_Oscillation(Current_Oscillation,1,:))>=abs(Bimodal_Reverse_Score))))+1)/(Number_Of_Shuffles+1)];
            
        end
    end
    
    % This calculates the total number of qualifying theta oscillations
    % with a significant forward sequence, a significant reverse sequence,
    % and the p-value of the percent of oscillations with both significant
    % forward and reverse sequences in the same oscillation
    
    Unimodal_Qualifying_Oscillation_Count=sum(Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2);
    Unimodal_Significant_Forward_Sequence_Count=sum(Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Unimodal_Significant_Reverse_Sequence_Count=sum(Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Unimodal_Significant_Positive_Forward_Sequence_Count=sum(Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Unimodal_Significant_Negative_Reverse_Sequence_Count=sum(Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    
    Bimodal_Qualifying_Oscillation_Count=sum(Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2);
    Bimodal_Significant_Forward_Sequence_Count=sum(Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Bimodal_Significant_Reverse_Sequence_Count=sum(Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Bimodal_Significant_Positive_Forward_Sequence_Count=sum(Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    Bimodal_Significant_Negative_Reverse_Sequence_Count=sum(Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05);
    
    save('Individual_Unimodal_Theta_Sequence_P_Values','Unimodal_Forward_Sequence_Scores_Slopes_And_P_Values','Unimodal_Reverse_Sequence_Scores_Slopes_And_P_Values','Unimodal_Qualifying_Oscillation_Count','Unimodal_Significant_Forward_Sequence_Count','Unimodal_Significant_Reverse_Sequence_Count','Unimodal_Significant_Positive_Forward_Sequence_Count','Unimodal_Significant_Negative_Reverse_Sequence_Count');
    save('Individual_Bimodal_Theta_Sequence_P_Values','Bimodal_Forward_Sequence_Scores_Slopes_And_P_Values','Bimodal_Reverse_Sequence_Scores_Slopes_And_P_Values','Bimodal_Qualifying_Oscillation_Count','Bimodal_Significant_Forward_Sequence_Count','Bimodal_Significant_Reverse_Sequence_Count','Bimodal_Significant_Positive_Forward_Sequence_Count','Bimodal_Significant_Negative_Reverse_Sequence_Count');
    
else
    load Individual_Unimodal_Theta_Sequence_P_Values
    load Individual_Bimodal_Theta_Sequence_P_Values
end
warning('on','all')

% This makes a list of the start and end of each theta oscillation with significant sequences in the Forward Window or Reverse Window
Significant_Forward_Start_End_Times=Theta_Cycle_Start_End_Times(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Reverse_Start_End_Times=Theta_Cycle_Start_End_Times(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Positive_Forward_Start_End_Times=Theta_Cycle_Start_End_Times(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Negative_Forward_Start_End_Times=Theta_Cycle_Start_End_Times(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Positive_Reverse_Start_End_Times=Theta_Cycle_Start_End_Times(Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Negative_Reverse_Start_End_Times=Theta_Cycle_Start_End_Times(Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);
Significant_Positive_Forward_Negative_Reverse_Start_End_Times=Theta_Cycle_Start_End_Times(Forward_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Forward_Sequence_Scores_Slopes_And_P_Values(:,2)>0 & Forward_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Forward_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,1)>-2 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,2)<0 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,3)<=0.05 & Reverse_Sequence_Scores_Slopes_And_P_Values(:,4)<=0.05,:);

save('Significant_Individual_Theta_Oscillation_Start_End_Times','*_Start_End_Times');

end

