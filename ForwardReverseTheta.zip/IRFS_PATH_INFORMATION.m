function [Best_Sequence_Data,Best_Sequence,Best_Sequence_Score,Overall_Score]=IRFS_PATH_INFORMATION(Decoded_Sequence,Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function analyzes the path information in the Decoded_Sequence
% (location on each consecutive decoded bin).  This function calculates the
% distance moved on each step and then finds consecutive steps that are
% within a certain number of bins, defined by Minimum_Step_Size.  Then, if
% there are a minimum number of consecutive steps (Minimum_Step_Number) and
% if that path goes a certain distance (Start_To_End_Distance), then this
% is considered a valid sequence. The best (longest) sequence is identified
% and the data from this sequence is sent as output.
% 
% Best_Sequence is a limited version of the input Decoded_Sequence that
% only contains the best sequence.  Best_Sequence_Data has the following
% data:
% 
% Best_Sequence_Data
% |      1      |     2     |        3        |             4              |              5             |
% | Start Index | End Index | Number of Steps | Start-to-End Distance (cm) | Best Sequence Slope (cm/s) |
% 
% If there are no consecutive sequences that meet the Minimum_Step_Number
% and Total_Distance requirements, Best_Sequence and Best_Sequence_Data are
% given values of zero. 
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Maximum_Step_Size=Initial_Variables.Maximum_Step_Size/Initial_Variables.Bin_Size;
Minimum_Step_Number=Initial_Variables.Minimum_Step_Number;
Start_To_End_Distance=Initial_Variables.Start_To_End_Distance/Initial_Variables.Bin_Size;

Decoded_Sequence(:,2:10)=0;

% This measures the distance moved on each decoded frame
Decoded_Sequence(1:end-1,2)=diff(Decoded_Sequence(:,1));

% This identifies periods of time when the movement was less than the Maximum_Step_Size
Decoded_Sequence(abs(Decoded_Sequence(:,2))<=Maximum_Step_Size,3)=1;

% This finds the different stretches of movement, adding up the number
% of consecutive steps (column 4), and the distance-from-the-start (column 5).
if Decoded_Sequence(1,3)==1
    Decoded_Sequence(1,4)=1;
    Start_Index=1;
end
Max_Length=0;
for N=2:size(Decoded_Sequence,1)
    if Decoded_Sequence(N-1,3)==0
        Decoded_Sequence(N,4)=Decoded_Sequence(N,3);
    else
        Decoded_Sequence(N,4)=Decoded_Sequence(N-1,4)+Decoded_Sequence(N,3);
    end
    if Decoded_Sequence(N,4)==Decoded_Sequence(N-1,4) && Decoded_Sequence(N,4)>0
        %Decoded_Sequence(N,4)=Decoded_Sequence(N,4)+1;
    end
    if Decoded_Sequence(N,4)<=1
        Start_Index=N;
        Max_Length=0;
    elseif Decoded_Sequence(N,4)>1
        M=N;
        while Decoded_Sequence(M,4)>1
            if abs(diff(Decoded_Sequence([Start_Index,M],1)))>abs(Max_Length)
                Max_Length=diff(Decoded_Sequence([Start_Index,M],1));  %Could be positive (ahead of the animal) or negative (behind the animal)
            end
            M=M-1;
        end
        Decoded_Sequence(N,5)=Max_Length; 
    end
end

% This finds all the contiguous movement sequences within the event
if size(Decoded_Sequence,1)>=3
    [~,Locations]=findpeaks(Decoded_Sequence(:,5));
    if Decoded_Sequence(end,5)>1
        Locations(end+1,1)=size(Decoded_Sequence,1);
    end
else
    [~,Locations]=max(Decoded_Sequence(:,5));
end

% This pulls up the number of steps, the total distance traveled, and
% the start-to-end distance traveled for every segment.
Sequence_Scores=Decoded_Sequence(Locations,4:5);

% This orders the various epochs of continuous movement, first by the
% number of steps, then (if there's a tie) by the maximum distance moved.
Sequence_Scores=sortrows(abs(Sequence_Scores),[-1,-2]);

Good_Sequences=Sequence_Scores(Sequence_Scores(:,1)>=Minimum_Step_Number & Sequence_Scores(:,2)>=Start_To_End_Distance,:);
if ~isempty(Good_Sequences)
    Best_Sequence_End=find(Decoded_Sequence(:,4)==Good_Sequences(1,1) & Decoded_Sequence(:,5)==Good_Sequences(1,2),1,'first');
    Best_Sequence_Start=find(Decoded_Sequence(:,4)==1);
    Best_Sequence_Start=Best_Sequence_Start(find(Best_Sequence_Start<Best_Sequence_End,1,'last'));
    Best_Sequence=Decoded_Sequence(Best_Sequence_Start:Best_Sequence_End,:);
    Best_Sequence_Slope=polyfit((1:size(Best_Sequence,1))',Best_Sequence(:,1),1);
    Best_Sequence_Slope=(Best_Sequence_Slope(1)*Initial_Variables.Bin_Size)/Initial_Variables.Decoding_Time_Advance; %Slope in cm/s
    Best_Sequence_Data=[Best_Sequence_Start,Best_Sequence_End,Best_Sequence(end,4),Best_Sequence(end,5)*Initial_Variables.Bin_Size,Best_Sequence_Slope];
else
    Best_Sequence_Data=zeros(1,5);
    Best_Sequence=zeros(1,size(Decoded_Sequence,2));
end

% This calculates the score for the best sequence and the overall sequence


end