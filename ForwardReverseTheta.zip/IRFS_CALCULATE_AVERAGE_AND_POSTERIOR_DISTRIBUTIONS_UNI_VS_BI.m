% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script is similar to IRFS_CALCULATE_AVERAGE_AND_POSTERIOR_DISTRIBUTIONS
% but only for the comparison between Unimodal and Bimodal decoding.
% 
% -------------------------------------------------------------------
% -------------------------------------------------------------------------

if exist('Average_Theta_Sequence_And_Posterior_Dists_Uni_Vs_Bi.mat','file')==2
    load Average_Theta_Sequence_And_Posterior_Dists_Uni_Vs_Bi
    
else
    Number_Of_Theta_Bins=ceil(360/Phase_Bin);
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
    Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
    
    %This calculates the average theta sequence
    Average_Decoded_Theta_Sequence_Unimodal=zeros(size(Unimodal_Vs_Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Average_Decoded_Theta_Sequence_Bimodal=zeros(size(Unimodal_Vs_Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:Number_Of_Theta_Bins
        Average_Decoded_Theta_Sequence_Unimodal(:,N)=mean(Unimodal_Vs_Bimodal_Decoded_Data(:,Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin),1),2);
        Average_Decoded_Theta_Sequence_Bimodal(:,N)=mean(Unimodal_Vs_Bimodal_Decoded_Data(:,Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin),2),2);
    end
    clear N;
    
    %This calculates the distribution of peak posterior probabilities across the entire session
    Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
    
    Dist_Of_Peak_Post_Unimodal=zeros(size(Unimodal_Vs_Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Dist_Of_Peak_Post_Bimodal=zeros(size(Unimodal_Vs_Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Unimodal_Vs_Bimodal_Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==N,:);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                for M=1:size(Unimodal_Vs_Bimodal_Decoded_Data,1)
                    Maxes=max([Current_Oscillation_Decoded_Data(M,:,1),Current_Oscillation_Decoded_Data(M,:,2)]);
                    if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data(M,:,1),Current_Oscillation_Decoded_Data(M,:,2)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data(M,:,1),Current_Oscillation_Decoded_Data(M,:,2)]==Maxes)==1
                        if sum(Current_Oscillation_Decoded_Data(M,:,1)==Maxes)>0
                            Dist_Of_Peak_Post_Unimodal(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:,1)==Maxes,6)/Phase_Bin))=Dist_Of_Peak_Post_Unimodal(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:,1)==Maxes,6)/Phase_Bin))+1;
                        end
                        if sum(Current_Oscillation_Decoded_Data(M,:,2)==Maxes)>0
                            Dist_Of_Peak_Post_Bimodal(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:,2)==Maxes,6)/Phase_Bin))=Dist_Of_Peak_Post_Bimodal(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:,2)==Maxes,6)/Phase_Bin))+1;
                        end
                    end
                    clear Max_Phases;
                    clear Maxes;
                end
            end
            clear Current_Oscillation_Decoding_Time_Info;
            clear Current_Oscillation_Decoded_Data;
            clear M;
        end
    end
    clear N;
    Norm_Dist_Of_Peak_Post_Unimodal=zeros(size(Unimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Norm_Dist_Of_Peak_Post_Bimodal=zeros(size(Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:size(Dist_Of_Peak_Post_Unimodal,2)
        Norm_Dist_Of_Peak_Post_Unimodal(:,N)=Dist_Of_Peak_Post_Unimodal(:,N)/sum(Dist_Of_Peak_Post_Unimodal(:,N));
    end
    for N=1:size(Dist_Of_Peak_Post_Bimodal,2)
        Norm_Dist_Of_Peak_Post_Bimodal(:,N)=Dist_Of_Peak_Post_Bimodal(:,N)/sum(Dist_Of_Peak_Post_Bimodal(:,N));
    end
    clear N;
    % figure;hold on;
    % subplot('Position',[0 0 1/2 1/2]);
    % imagesc([Dist_Of_Peak_Post_Unimodal,Dist_Of_Peak_Post_Unimodal]);colormap('hot');hold on;set(gca,'XTick',[]);set(gca,'YTick',[]);
    % subplot('Position',[0 1/2 1/2 1/2]);
    % imagesc([Dist_Of_Peak_Post_Bimodal,Dist_Of_Peak_Post_Bimodal]);colormap('hot');hold on;set(gca,'XTick',[]);set(gca,'YTick',[]);
    % subplot('Position',[1/2 0 1/2 1/2]);
    % imagesc([Norm_Dist_Of_Peak_Post_Unimodal,Norm_Dist_Of_Peak_Post_Unimodal]);colormap('hot');hold on;set(gca,'XTick',[]);set(gca,'YTick',[]);
    % subplot('Position',[1/2 1/2 1/2 1/2]);
    % imagesc([Norm_Dist_Of_Peak_Post_Bimodal,Norm_Dist_Of_Peak_Post_Bimodal]);colormap('hot');hold on;set(gca,'XTick',[]);set(gca,'YTick',[]);
    
    save('Average_Theta_Sequence_And_Posterior_Dists_Uni_Vs_Bi','Average_Decoded_Theta_Sequence_Unimodal','Average_Decoded_Theta_Sequence_Bimodal','Dist_Of_Peak_Post_Unimodal','Dist_Of_Peak_Post_Bimodal','Norm_Dist_Of_Peak_Post_Unimodal','Norm_Dist_Of_Peak_Post_Bimodal','-v7.3');

end