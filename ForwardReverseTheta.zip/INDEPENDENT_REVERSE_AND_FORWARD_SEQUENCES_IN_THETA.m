function INDEPENDENT_REVERSE_AND_FORWARD_SEQUENCES_IN_THETA

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function is the main function that does all of the analysis for this
% paper.  It requires four files to already be in existence:
% Spike_Data.mat, L_Ratios.mat, Position_Data.mat, and
% Experiment_Information.mat.  It further requires the raw local field
% potential data to be available for processing (this is typically stored
% in a separate location due to its size).
% 
% This function uses the following data sets:
% 
% Rat-SessionType-Day (Recording Day)
% 
% Janni-Open-1 (Recorded on 20100407)
% Janni-Open-2 (Recorded on 20100407)
% Harpy-Open-1 (Recorded on 20100110)
% Harpy-Open-2 (Recorded on 20100112)
% Imp-Open-1 (Recorded on 20100217)
% Imp-Open-2 (Recorded on 20100218)
%
% Janni-Linear-1 (Recorded on 20100408)
% Janni-Linear-2 (Recorded on 20100410)
% Janni-Linear-3 (Recorded on 20100411)
% Janni-Linear-4 (Recorded on 20100412)
% Janni-Linear-5 (Recorded on 20100413)
% Harpy-Linear-1 (Recorded on 20100108)
% Harpy-Linear-2 (Recorded on 20100115)
% Harpy-Linear-3 (Recorded on 20100119)
% Imp-Linear-1 (Recorded on 20100222)
% Imp-Linear-2 (Recorded on 20100227)
%
% For analyses using a single, global theta reference, I used to use the following
% Rat Tetrode (Channel)
% Janni 3 (CSC9) is in the left hemisphere
% Harpy 35 (CSC139) is in the right hemisphere
% Imp 16 (CSC61) is in the left hemisphere
% (Alternate theta reference options are: Janni 20 (CSC77), Harpy 18
% (CSC70) and Imp 4 (CSC13).)
% 
% For some experiments, there are brief sections with extremely high noise
% that needed to be removed to properly analyze the data.  Here are the
% sections that were removed (and sometimes, why):
% 
% For Janni Open 2, one chip came unplugged in the middle of the experiment
% and those timepoints need to be removed from the analysis
% Open 2: 33756-34007
%
% For Harpy, there was an issue with the ground wire that very rarely
% caused the LFP to be super noisy.  Here are the time points that need to
% be eliminated from analysis to remove those noisy epochs
% Linear 1: 12850-12956, 17880-17929 (many more short bursts of noise -- likely when he was at the well)
% Linear 2: 19307-19322, 19476-19489
% Linear 3: 27025-27035
% Open 1: 27332-27639
% Open 2: 19528-19539, 19582-19592, 19701-19722, 20802-20815, 21607-21621, 21690-21696, 21701-21702, 22141-22180, 22258-22265
%
% For Imp, there were a few noisy sections that need to be removed as well.
% Linear 1: 33920-33962 (many more short bursts of noise -- likely when he was at the well)
% Open 1: 25160-25275 (and maybe 23450-23569 although it's not that bad)
% Open 2: 20122-20126, 20147-20164
% 
% This function assumes that the only pre-processed data is Spike_Data, L_Ratios, and
% Position_Data.  Spike_Data comes with additional information, including
% Excitatory_Neurons (cell ID list of all putative excitatory neurons),
% Inhibitory_Neurons (cell ID list of all putative inhibitory neurons), and
% Tetrode_Cell_ID (list of which tetrode each cell was recorded on.
% 
% Spike_Data (a chronological list of all spikes)
% |         1         |    2    |
% | Time (in seconds) | Cell ID |
% 
% Position_Data (a chronological list of the rat's behavior from the overhead camera)
% |         1         |           2        |           3        |        4       | 
% | Time (in seconds) | X Position (in cm) | Y Position (in cm) | Head Direction | 
% 
% L_Ratios is the L-ratio (a measure of cluster quality) calculated for
% each neuron from the clustered data (using the CALCULATE_L_RATIO
% function).
% 
% Finally, there is one additional file, Experiment_Information.mat, which
% contains useful info regarding the experimental conditions, most
% importantly for this analysis, the Track_Type (1 = linear track, 2 = open
% field).
% 
% For each step, the data is saved so that future runs don't need to run
% that step.  To start from scratch, just copy Spike_Data.mat, L_Ratios.mat,
% Position_Data.mat, and Experiment_Information.mat into a new folder and
% start over from there.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% First, I define a few variables that can be changed
Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference=inf;   %If there is not position information found within this timeframe (in seconds) from a given spike, that spike is removed from analysis
Initial_Variables.Bin_Size=2;                                               %Size of spatial bins (in cm) used to make place fields
Initial_Variables.Place_Field_Velocity_Cutoff=5;                            %The rat must be moving this fast (in cm/s) or faster for those spikes and position information to be used in calculating place fields
Initial_Variables.Place_Field_Firing_Rate_Cutoff=1;                         %Neurons that don't fire at least this must (in Hz) in at least one bin are excluded from analysis.
Initial_Variables.Raw_LFP_Root_Directory='G:\BiModalThetaAnalysis\_CleanDataSet\Raw_LFP';                              %The root directory where the raw LFP files can be found
Initial_Variables.Limit_Analysis_By_Theta_Length=1;                         %If set to 1, theta oscillations greater or less than a maximum (defined by Theta_Length_Min_Max) will be excluded from analysis; if set to 0, all theta oscillations will be included (although a velocity limit will still be applied)
Initial_Variables.Theta_Length_Min_Max=[0.08,0.16];                         %The minimum and maximum duration (in seconds) that a theta oscillation can be (measured trough-to-trough) and still be included in the analysis
Initial_Variables.Number_Of_Shuffles=500;                                   %The number of shuffles to run for position sequences from Bayesian decoding
Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship=1000;  %The number of shuffles to run for quantification of phase-position relationships
Initial_Variables.Phase_Bin=10;                                             %The size of each theta phase bin (in degrees)
Initial_Variables.Gaussian_Smoothing_Sigma=12;                              %Sigma of the Gaussian smoothing filter (in degrees) that turns the spike histogram into a smoothed line (which is what is actually used for quantification)
Initial_Variables.Rayleigh_Test_P_Value_Cutoff=0.05;                        %The Rayleigh test to reject circular uniformity must have a p-value of this value or lower for the cell to be considered uni-/bi-/multi-modal
Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction=0.2;             %A spatial bin must have a firing rate of the maximum firing rate times this fraction to be considered part of a true place field.
Initial_Variables.Minimum_Contiguous_Place_Field_Bins=20;                   %A place field must have this number of contiguous bin at or above Minimum_Place_Field_Firing_Rate_Fraction x the max firing rate to be considered a true place field.
Initial_Variables.Velocity_Cutoff=10;                                       %The minimum speed (in cm/s) that the rat must be moving to analyze theta locking
Initial_Variables.Minimum_Spike_Count=100;                                  %A neuron has to fire at least this many spikes during running to be included in the analysis
Initial_Variables.Decoding_Time_Window=0.02;                                %Size (in seconds) of the Bayesian decoding time window
Initial_Variables.Decoding_Time_Advance=0.005;                              %Size (in seconds) of the advancement between adjacent Bayesian decoding window frames
Initial_Variables.Sequence_Score_Distance=10;                               %Distance (in cm) from best fit line to calculate the Sequence Score
Initial_Variables.Use_Maximum_Posterior_Probability=1;                      %If set to 1, use the maximum posterior probability for identifying the single point for each frame (a value of 0 means use the weighted mean)
Initial_Variables.Maximum_Step_Size=10;                                     %The maximum distance (cm) the posterior probability can move between consecutive decoding windows and still be considered part of the same spatial trajectory
Initial_Variables.Minimum_Step_Size=2;                                      %The minimum distance (cm) the posterior probability can move between consecutive decoding windows and still be considered part of a real spatial trajectory
Initial_Variables.Minimum_Posterior_Probability=0.05;                       %The value of the max posterior probability that is necessary to be considered a "good" decoding window for trajectory score analysis
Initial_Variables.Minimum_Step_Number=5;                                    %The minimum number of consecutive decoding bins with Maximum_Step_Size between each consecutive bin necessary to be considered for a meaningful virtual trajectory sequence
Initial_Variables.Start_To_End_Distance=10;                                 %The total distance (cm) that a virtual spatial path needs to traverse to be considered a meaningful spatial trajectory

% These are the noisy sections that need to be removed from analysis
% (Another way to do this would be to remove all data within +/- 5 seconds 
% any time the raw LFP value is maxed out)
% This also removes periods in linear track sessions between consecutive
% runs
Timepoints_To_Remove.Janni_Open2_To_Remove=[33756,34007];
Timepoints_To_Remove.Janni_Linear2_To_Remove=[[18721,22773];[23511,29423]];
Timepoints_To_Remove.Janni_Linear3_To_Remove=[[11650,15498];[16390,20184]];
Timepoints_To_Remove.Harpy_Linear1_To_Remove=[[12850,12956];[17880,17929]];
Timepoints_To_Remove.Harpy_Linear2_To_Remove=[[19307,19322];[19476,19489]];
Timepoints_To_Remove.Harpy_Linear3_To_Remove=[27025,27035];
Timepoints_To_Remove.Harpy_Open1_To_Remove=[27332,27639];
Timepoints_To_Remove.Harpy_Open2_To_Remove=[[19528,19539];[19582,19592];[19701,19722];[20802,20815];[21607,21621];[21690,21696];[21701,21702];[22141,22180];[22258,22265]];
Timepoints_To_Remove.Imp_Linear1_To_Remove=[[25880,29735];[30570,33885];[33920,33962]];
Timepoints_To_Remove.Imp_Open1_To_Remove=[25160,25275];
Timepoints_To_Remove.Imp_Open2_To_Remove=[[20122,20126];[20147,20164]];

% Here, I define the phases of theta for the Forward Window, the Reverse
% Window, the Major Peak Window and the Minor Peak Window.  I quantify
% them later from the actual data, but many of the analyses use them before
% I get to that point, so I pre-define them here.
Forward_Window=[250,60];
Reverse_Window=[80,230];
Major_Peak_Window=[200,70];
Minor_Peak_Window=[80,190];
save('Bimodal_Analysis_Windows','Forward_Window','Reverse_Window','Major_Peak_Window','Minor_Peak_Window');

IRFS_PROCESS_RAW_DATA(Initial_Variables,Timepoints_To_Remove);

IRFS_PROCESS_UNIMODAL_VS_BIMODAL_FIRING(Initial_Variables,Timepoints_To_Remove);

IRFS_PROCESS_THETA_SEQUENCE_DECODED_CONTENT(Initial_Variables,Timepoints_To_Remove);

IRFS_PROCESS_REPLAY_THETA_SEQUENCE_CORRELATION(Initial_Variables,Timepoints_To_Remove);

IRFS_PROCESS_PHASE_PRECESSION_VS_PROCESSION(Initial_Variables,Timepoints_To_Remove);

IRFS_PROCESS_FIRING_RATE_TO_THETA_BETA_POWER_CORRELATION(Initial_Variables,Timepoints_To_Remove);

end

