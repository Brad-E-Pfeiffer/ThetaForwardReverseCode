
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function decodes every theta oscillation as with
% IRFS_DECODE_THETA_SEQUENCES, but here it uses only Unimodal cells
% or only Bimodal cells to do the decoding. It performs the decoding
% similar to "IN" and "OUT" fields for a linear track, where the Bayesian
% product is calculated only for Unimodal cells and only for Bimodal
% cells, and the final probabilty is based on the sum of both of these
% products.  This provides a more accurate measure of how much
% representation each cell population is contributing to the decoding.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%tic;

% The converts the Decoding_Spike_Index into an index for either Unimodal
% or Bimodal cells.
Unimodal_Decoding_Spike_Index=Decoding_Spike_Index;
Temp_Index=zeros(size(Decoding_Spike_Index));
for N=1:size(Modality,1)
    if Modality(N,1)==1
        Temp_Index(Decoding_Spike_Index==Modality(N,2))=1;
    end
end
Unimodal_Decoding_Spike_Index(Temp_Index==0)=0;
%Unimodal_Decoding_Spike_Index=Unimodal_Decoding_Spike_Index(:,max(Unimodal_Decoding_Spike_Index)>0);
clear N;
clear Temp_Index;

Bimodal_Decoding_Spike_Index=Decoding_Spike_Index;
Temp_Index=zeros(size(Decoding_Spike_Index));
for N=1:size(Modality,1)
    if Modality(N,1)==2
        Temp_Index(Decoding_Spike_Index==Modality(N,2))=1;
    end
end
Bimodal_Decoding_Spike_Index(Temp_Index==0)=0;
%Bimodal_Decoding_Spike_Index=Bimodal_Decoding_Spike_Index(:,max(Bimodal_Decoding_Spike_Index)>0);
clear N;
clear Temp_Index;

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data2=Field_Data;
for N=1:size(Field_Data2,3)
    Field=Field_Data2(:,:,N);
    Minimum=min(min(Field(Field>0)));
    if ~isempty(Minimum)
        if Minimum/10>0
            Field(Field<=0)=Minimum/10;
        else
            Field(Field<=0)=Minimum;
        end
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data2(:,:,N)=Field;
    clear Minimum;
    clear Field;
end
clear N;
Unimodal_Field_Data=Field_Data;
for N=1:size(Modality,1)
    if Modality(N,1)~=1
        Unimodal_Field_Data(:,:,N)=0;
    end
end
Bimodal_Field_Data=Field_Data;
for N=1:size(Modality,1)
    if Modality(N,1)~=2
        Bimodal_Field_Data(:,:,N)=0;
    end
end

Mid_X=round(size(Field_Data,2)/2);   %This defines the size of the canvas for translation and rotation analysis
Mid_Y=round(size(Field_Data,1)/2);   %This defines the size of the canvas for translation and rotation analysis


Unimodal_Vs_Bimodal_Decoded_Data=zeros((max([Mid_X,Mid_Y])*2)+1,length(Decoding_Spike_Index),2);
Decoded_Data_Size=size(Unimodal_Vs_Bimodal_Decoded_Data,1);
%Unimodal_Decoded_Data is the full posterior probabilities, collapsed across one dimension so it is encoding just the rat's current movement direction

parfor Current_Decoding_Window=1:length(Decoding_Window_Index)
    
    %Pulls up relevant spikes for this decoding window
    Subset_Unimodal_Spike_Data=Unimodal_Decoding_Spike_Index(:,Current_Decoding_Window);
    Subset_Unimodal_Spike_Data=Subset_Unimodal_Spike_Data(Subset_Unimodal_Spike_Data>0);
    Subset_Bimodal_Spike_Data=Bimodal_Decoding_Spike_Index(:,Current_Decoding_Window);
    Subset_Bimodal_Spike_Data=Subset_Bimodal_Spike_Data(Subset_Bimodal_Spike_Data>0);
        
    %This does the actual decoding for this window
    Unimodal_Decoded_Matrix=prod(Field_Data2(:,:,Subset_Unimodal_Spike_Data),3).*exp(-Decoding_Time_Window*sum(Unimodal_Field_Data,3));
    Bimodal_Decoded_Matrix=prod(Field_Data2(:,:,Subset_Bimodal_Spike_Data),3).*exp(-Decoding_Time_Window*sum(Bimodal_Field_Data,3));
    if isinf(max(max(Unimodal_Decoded_Matrix))) || isinf(max(max(Bimodal_Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
        Divider=1;
        while isinf(max(max(Unimodal_Decoded_Matrix))) || isinf(max(max(Bimodal_Decoded_Matrix)))
            Unimodal_Decoded_Matrix=prod((Field_Data2(:,:,Subset_Unimodal_Spike_Data)/(2^Divider)),3).*exp(-Decoding_Time_Window*sum((Unimodal_Field_Data/(2^Divider)),3));
            Bimodal_Decoded_Matrix=prod((Field_Data2(:,:,Subset_Bimodal_Spike_Data)/(2^Divider)),3).*exp(-Decoding_Time_Window*sum((Unimodal_Field_Data/(2^Divider)),3));
            Divider=Divider+1;
        end
    end
    Unimodal_Decoded_Matrix(Unimodal_Decoded_Matrix<0)=0;
    Bimodal_Decoded_Matrix(Bimodal_Decoded_Matrix<0)=0;
    if max(max(Unimodal_Decoded_Matrix))>0 && max(max(Bimodal_Decoded_Matrix))>0
        Sum=sum(sum(Unimodal_Decoded_Matrix+Bimodal_Decoded_Matrix));
        Unimodal_Decoded_Matrix=Unimodal_Decoded_Matrix/Sum;
        Bimodal_Decoded_Matrix=Bimodal_Decoded_Matrix/Sum;
    end
    
    %Here is where the decoded data gets relocated to rat's current location
    X=Decoding_Time_Info(Decoding_Window_Index(Current_Decoding_Window),1)/Bin_Size;
    Y=Decoding_Time_Info(Decoding_Window_Index(Current_Decoding_Window),2)/Bin_Size;
    Unimodal_Translated_Image=imtranslate(Unimodal_Decoded_Matrix,[Mid_X-X,Mid_Y-Y],'FillValues',0);
    Bimodal_Translated_Image=imtranslate(Bimodal_Decoded_Matrix,[Mid_X-X,Mid_Y-Y],'FillValues',0);
        
    %Here is where the translated data is rotated to the rat's current movement direction (pull the data from column 3 instead of 5 for the rat's head direction)
    Angle_Movement=Decoding_Time_Info(Decoding_Window_Index(Current_Decoding_Window),5);
    Unimodal_Rotated_Image=imrotate(Unimodal_Translated_Image,-(Angle_Movement+180),'bilinear');
    Bimodal_Rotated_Image=imrotate(Bimodal_Translated_Image,-(Angle_Movement+180),'bilinear');
    if size(Unimodal_Rotated_Image,1)<Decoded_Data_Size
        Size_Difference=Decoded_Data_Size-size(Unimodal_Rotated_Image,1);
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Unimodal_Rotated_Image=padarray(Unimodal_Rotated_Image,[Size_Difference/2,0],0,'both');
            Bimodal_Rotated_Image=padarray(Bimodal_Rotated_Image,[Size_Difference/2,0],0,'both');
        else
            Unimodal_Rotated_Image=padarray(Unimodal_Rotated_Image,[ceil(Size_Difference/2),0],0,'pre');
            Unimodal_Rotated_Image=padarray(Unimodal_Rotated_Image,[floor(Size_Difference/2),0],0,'post');
            Bimodal_Rotated_Image=padarray(Bimodal_Rotated_Image,[ceil(Size_Difference/2),0],0,'pre');
            Bimodal_Rotated_Image=padarray(Bimodal_Rotated_Image,[floor(Size_Difference/2),0],0,'post');
        end
    end
    if size(Unimodal_Rotated_Image,1)>Decoded_Data_Size
        Size_Difference=size(Unimodal_Rotated_Image,1)-Decoded_Data_Size;
        if mod(Size_Difference,2)==0 %if Size_Difference is even
            Unimodal_Rotated_Image=Unimodal_Rotated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
            Bimodal_Rotated_Image=Bimodal_Rotated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
        elseif Size_Difference==1
            Unimodal_Rotated_Image=Unimodal_Rotated_Image(1:(end-1),:);
            Bimodal_Rotated_Image=Bimodal_Rotated_Image(1:(end-1),:);
        else
            Unimodal_Rotated_Image=Unimodal_Rotated_Image(ceil(Size_Difference/2):(end-ceil(Size_Difference/2)),:);
            Bimodal_Rotated_Image=Bimodal_Rotated_Image(ceil(Size_Difference/2):(end-ceil(Size_Difference/2)),:);
        end
    end
    
    %Here it sums across the direction perpendicular to the rat's movement direction
    Unimodal_Rotated_Image=sum(Unimodal_Rotated_Image,2);
    Bimodal_Rotated_Image=sum(Bimodal_Rotated_Image,2);
    
    %Add to the rest of the decoded frames
    To_Add=zeros(size(Unimodal_Rotated_Image,1),size(Unimodal_Rotated_Image,2),2);
    To_Add(:,:,1)=Unimodal_Rotated_Image;
    To_Add(:,:,2)=Bimodal_Rotated_Image;
    Unimodal_Vs_Bimodal_Decoded_Data(:,Current_Decoding_Window,:)=To_Add;
            
end
clear Subset_Unimodal_Spike_Data;
clear Subset_Bimodal_Spike_Data;
clear Divider;
clear X;
clear Y;
clear To_Add
clear Angle_Movement;
clear Unimodal_Translated_Image;
clear Unimodal_Rotated_Image;
clear Bimodal_Translated_Image;
clear Bimodal_Rotated_Image;
clear Size_Difference;
clear Max_Position;
clear Position_Matrx;
clear Size_Difference;
clear X_Image;
clear Y_Image;
clear Max_X_Position;
clear Max_Y_Position;
clear X_Position_Matrix;
clear Y_Position_Matrix;
clear Unimodal_Decoded_Matrix;
clear Bimodal_Decoded_Matrix;
clear Mid;
clear Pos;
clear Field_Data2;
clear Decoded_Data_Size;
clear Current_Decoding_Window;
save('Comparison_Between_Unimodal_And_Bimodal_Decoding','Unimodal_Vs_Bimodal_Decoded_Data','Decoding_Time_Window','Decoding_Time_Advance','-v7.3');

%T=toc;
%eval(sprintf('disp(''Took %d minutes.'');',T/60));
%clear T;


