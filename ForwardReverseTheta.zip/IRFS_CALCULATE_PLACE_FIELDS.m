function IRFS_CALCULATE_PLACE_FIELDS(Bin_Size,Velocity_Cutoff,Firing_Rate_Cutoff,Analyze_Linear)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function calculates the locations within the behavioral arena or
% track where the neurons fire.  It will first calculate 2-dimensional
% place fields.  If the track is linear (Track_Type==1), the program will
% also calculate linear (uni-directional and bi-directional) place fields.
% 
% Bin_Size is the size (in cm) of the bins that are used to make the place
% fields.  Velocity_Cutoff is the velocity (in cm/sec) that the rat must be
% moving in order for the spikes to count toward place fields.
% Firing_Rate_Cutoff is the minimum peak firing rate (in Hz) that a cell
% must have to be considered to have a place field.  Otherwise, its place
% field is eliminated from future analysis.  Analyze_Linear (1 or 0) tells
% the program whether or not to calculate linear place fields (1=yes,0=no).
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Experiment_Information;

% If the user did not fully define the input variables, the most likely
% values are either searched for or automatically provided.
if nargin<1,
    Bin_Size=2;
    Velocity_Cutoff=5;
    Firing_Rate_Cutoff=1;
    if Track_Type==1,
        Analyze_Linear=1;
    else
        Analyze_Linear=0;
    end
elseif nargin<2,
    Velocity_Cutoff=5;
    Firing_Rate_Cutoff=1;
    if Track_Type==1,
        Analyze_Linear=1;
    else
        Analyze_Linear=0;
    end
elseif nargin<3,
    Firing_Rate_Cutoff=1;
    if Track_Type==1,
        Analyze_Linear=1;
    else
        Analyze_Linear=0;
    end
elseif nargin<4,
    if Track_Type==1,
        Analyze_Linear=1;
    else
        Analyze_Linear=0;
    end
end

% This section calculates the 2-dimensional place fields
load Spike_Data
load Spike_Information
load Position_Data
Position_Data(:,2)=Position_Data(:,2)-min(Position_Data(:,2))+0.001;
Position_Data(:,3)=Position_Data(:,3)-min(Position_Data(:,3))+0.001;

% Here, the time spent in each position bin is calculated.  I use the
% position data rather than the spike data for this purpose because the
% position data is acquired on a regular frequency, whereas the spike occur
% irregularly.  Therefore, if you didn't record from a large number of
% cells, the rat's apparent position occupancy could be skewed if you used
% the spike data for this calculation.  This uses the same calculations as
% in the function SPIKE_POSITION_INTEGRATION.
Time_Change=diff(Position_Data(:,1));
Time_Change(end+1)=Time_Change(end);
Time_Change(Time_Change>(10*median(Time_Change)))=median(Time_Change); %This removes large time jumps (from sleep sessions)
%[FilterA,FilterB]=butter(2,0.02);
%Time_Change=filtfilt(FilterA,FilterB,Time_Change);
Time_Change(Time_Change<=0)=min(Time_Change(Time_Change>0))/10;
X_Movement=diff(Position_Data(:,2));
X_Movement(end+1)=X_Movement(end);
Y_Movement=diff(Position_Data(:,3));
Y_Movement(end+1)=Y_Movement(end);
Position_Change=[X_Movement,Y_Movement];
Distance_Moved=sqrt((X_Movement.^2)+(Y_Movement.^2));
Velocity=CALCULATE_VELOCITY(Position_Data(:,1:3));

% This finds the X- and Y-movement at the time of each spike.  This is only
% useful if linear place fields are going to be calculated, but it needs to
% be done before I apply the velocity filter.
if 1
    Spike_Movement=zeros(size(Spike_Data,1),2);
    parfor N=1:size(Spike_Data,1)
        Index=abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1)));
        if sum(Index)>1
            Index=find(abs(Position_Data(:,1)-Spike_Data(N,1))==min(abs(Position_Data(:,1)-Spike_Data(N,1))),1,'first');
        end
        Spike_Movement(N,:)=[X_Movement(Index),Y_Movement(Index)];
    end
else
    Histogram=histc(Position_Data(:,1),Spike_Data(:,1));
    Temp_Spike_Times_In_Position_Time=cumsum(Histogram(1:end),1);
    Temp_Spike_Times_In_Position_Time(find(Temp_Spike_Times_In_Position_Time==0))=1;
    First_Index=Temp_Spike_Times_In_Position_Time;
    Spike_Movement=[X_Movement(First_Index,1),Y_Movement(First_Index,1)];
end

% This eliminates all position and spike data where the rat was moving
% slower than the Velocity_Cutoff. I then bin the position information.
Index=find(Velocity>=Velocity_Cutoff);
Position_Data=Position_Data(Index,:);
Time_Change=Time_Change(Index,:);
Position_Change=Position_Change(Index,:);
Position_Data(:,2)=ceil(Position_Data(:,2)/Bin_Size);
Position_Data(:,3)=ceil(Position_Data(:,3)/Bin_Size);
Index=Spike_Information(:,4)>=Velocity_Cutoff;
Spike_Data=Spike_Data(Index,:);
Spike_Information=Spike_Information(Index,:);
Spike_Information(:,1)=ceil(Spike_Information(:,1)/Bin_Size);
Spike_Information(:,2)=ceil(Spike_Information(:,2)/Bin_Size);
Spike_Movement=Spike_Movement(Index,:);
clear Index;

% Here, the total time spent moving in each position bin is calculated
Time_In_Position=zeros(max([max(Position_Data(:,3)),max(Spike_Information(:,2))]),max([max(Position_Data(:,2)),max(Spike_Information(:,1))]));
for N=1:size(Position_Data,1)
    Time_In_Position(Position_Data(N,3),Position_Data(N,2))=Time_In_Position(Position_Data(N,3),Position_Data(N,2))+Time_Change(N,1);
end

% Here, the number of spikes in each position bin is calculated for each cell
Spikes_In_Position=zeros(max([max(Position_Data(:,3)),max(Spike_Information(:,2))]),max([max(Position_Data(:,2)),max(Spike_Information(:,1))]),max(Spike_Data(:,2)));
for N=1:size(Spike_Data,1)
    Spikes_In_Position(Spike_Information(N,2),Spike_Information(N,1),Spike_Data(N,2))=Spikes_In_Position(Spike_Information(N,2),Spike_Information(N,1),Spike_Data(N,2))+1;
end

% Here, I calculate the actual firing rate (spikes/time) and save it as Field_Data
Firing_Rate_In_Position=zeros(size(Spikes_In_Position,1),size(Spikes_In_Position,2),size(Spikes_In_Position,3));
for N=1:size(Spikes_In_Position,3)
    Firing_Rate_In_Position(:,:,N)=Spikes_In_Position(:,:,N)./Time_In_Position;
end
Firing_Rate_In_Position(isnan(Firing_Rate_In_Position))=0;
Firing_Rate_In_Position(isinf(Firing_Rate_In_Position))=0;
Smoothed_Firing_Rate=Firing_Rate_In_Position;
Two_D_Filter=fspecial('gaussian',[20 20],2);  %This is a gaussian filter with a kernel St. Dev. of 2 bins (4 cm) that filters out to 10 bins in all directions (20 cm)
for N=1:size(Firing_Rate_In_Position,3)
    Smoothed_Firing_Rate(:,:,N)=filter2(Two_D_Filter,Firing_Rate_In_Position(:,:,N));
end
Smoothed_Firing_Rate(isnan(Smoothed_Firing_Rate))=0;
Smoothed_Firing_Rate(Smoothed_Firing_Rate<0)=0;
for Z=1:size(Smoothed_Firing_Rate,3)
    % This eliminates fields with a peak firing rate beneath the cutoff defined above.
    if max(max(max(Smoothed_Firing_Rate(:,:,Z))))<Firing_Rate_Cutoff
        Smoothed_Firing_Rate(:,:,Z)=0;
    end
end
Field_Data=Smoothed_Firing_Rate;
save('Field_Data','Field_Data')

%In the next section, I calculate linear place fields.  For now, the place
%fields are assumed to be in either the X- or Y-axis.  If there is a
%diagonal track, this will need to be re-written to account for that.

% First, I analyze bi-direction fields for the primary axis (the one with
% the largest movement).
if Analyze_Linear
    if (max(Position_Data(:,2))-min(Position_Data(:,2)))>=(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is horizontal
        Linear_Spikes_In_Position=sum(Spikes_In_Position,1);
        Linear_Spikes_In_Position=permute(Linear_Spikes_In_Position,[2,3,1]);
        Linear_Time_In_Position=sum(Time_In_Position,1);
        Linear_Time_In_Position=permute(Linear_Time_In_Position,[2,1]);
    elseif (max(Position_Data(:,2))-min(Position_Data(:,2)))<(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is vertical
        Linear_Spikes_In_Position=sum(Spikes_In_Position,2);
        Linear_Spikes_In_Position=permute(Linear_Spikes_In_Position,[1,3,2]);
        Linear_Time_In_Position=sum(Time_In_Position,2);
    end
    Linear_Rate_In_Position=zeros(size(Linear_Spikes_In_Position,1),size(Linear_Spikes_In_Position,2));
    for N=1:size(Linear_Spikes_In_Position,2)
        Linear_Rate_In_Position(:,N)=Linear_Spikes_In_Position(:,N)./Linear_Time_In_Position;
    end
    Linear_Rate_In_Position(isnan(Linear_Rate_In_Position))=0;
    Linear_Rate_In_Position(isinf(Linear_Rate_In_Position))=0;
    Smoothed_Linear_Firing_Rate=Linear_Rate_In_Position;
    Filter=fspecial('gaussian',[20 1],2); %This filter smooths the firing rates with a gaussian kernel with a St.Dev. of 2 bins (4cm), out to 10 bins on either side (20cm)
    %Filter=fspecial('gaussian',[10 1],2); %For smaller environments %This filter smooths the firing rates with a gaussian kernel with a St.Dev. of 2 bins (4cm), out to 5 bins on either side (20cm)
    for N=1:size(Linear_Rate_In_Position,2)
        Smoothed_Linear_Firing_Rate(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position(:,N));
    end
    Smoothed_Linear_Firing_Rate(isnan(Smoothed_Linear_Firing_Rate))=0;
    Smoothed_Linear_Firing_Rate(Smoothed_Linear_Firing_Rate<0)=0;
    for Z=1:size(Smoothed_Linear_Firing_Rate,2)
        if max(max(max(Smoothed_Linear_Firing_Rate(:,Z))))<Firing_Rate_Cutoff
            Smoothed_Linear_Firing_Rate(:,Z)=0;
        end
    end
    Field_Data_Linear=Smoothed_Linear_Firing_Rate;
    
% Here, I calculate uni-directional fields.
    if (max(Position_Data(:,2))-min(Position_Data(:,2)))>=(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is horizontal
        Position_Index=2;
    elseif (max(Position_Data(:,2))-min(Position_Data(:,2)))<(max(Position_Data(:,3))-min(Position_Data(:,3))) %if the track is vertical
        Position_Index=3;
    end
    Linear_Time_In_Position_Out=zeros(max([max(Position_Data(:,Position_Index)),max(Spike_Information(:,(Position_Index-1)))]),1);
    Linear_Time_In_Position_In=Linear_Time_In_Position_Out;
    for N=2:size(Position_Data,1)
        if Position_Change(N,(Position_Index-1))>0
            Linear_Time_In_Position_Out(Position_Data(N,Position_Index),1)=Linear_Time_In_Position_Out(Position_Data(N,Position_Index),1)+Time_Change(N,1);
        elseif Position_Change(N,(Position_Index-1))<0
            Linear_Time_In_Position_In(Position_Data(N,Position_Index),1)=Linear_Time_In_Position_In(Position_Data(N,Position_Index),1)+Time_Change(N,1);
        end
    end
    Linear_Spikes_In_Position_Out=zeros(max([max(Position_Data(:,Position_Index)),max(Spike_Information(:,(Position_Index-1)))]),max(Spike_Data(:,2)));
    Linear_Spikes_In_Position_In=Linear_Spikes_In_Position_Out;
    for N=1:size(Spike_Data,1)
        if Spike_Movement(N,(Position_Index-1))>0
            Linear_Spikes_In_Position_Out(Spike_Information(N,(Position_Index-1)),Spike_Data(N,2))=Linear_Spikes_In_Position_Out(Spike_Information(N,(Position_Index-1)),Spike_Data(N,2))+1;
        elseif Spike_Movement(N,(Position_Index-1))<0
            Linear_Spikes_In_Position_In(Spike_Information(N,(Position_Index-1)),Spike_Data(N,2))=Linear_Spikes_In_Position_In(Spike_Information(N,(Position_Index-1)),Spike_Data(N,2))+1;
        end
    end
    for N=1:size(Linear_Spikes_In_Position_Out,2)
        Linear_Rate_In_Position_Out(:,N)=Linear_Spikes_In_Position_Out(:,N)./Linear_Time_In_Position_Out;
        Linear_Rate_In_Position_In(:,N)=Linear_Spikes_In_Position_In(:,N)./Linear_Time_In_Position_In;
    end
    Linear_Rate_In_Position_Out(isnan(Linear_Rate_In_Position_Out))=0;
    Linear_Rate_In_Position_Out(isinf(Linear_Rate_In_Position_Out))=0;
    Linear_Rate_In_Position_In(isnan(Linear_Rate_In_Position_In))=0;
    Linear_Rate_In_Position_In(isinf(Linear_Rate_In_Position_In))=0;
    Smoothed_Linear_Firing_Rate_Out=Linear_Rate_In_Position_Out;
    Smoothed_Linear_Firing_Rate_In=Linear_Rate_In_Position_In;
    for N=1:size(Linear_Rate_In_Position_Out,2)
        Smoothed_Linear_Firing_Rate_Out(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position_Out(:,N));
        Smoothed_Linear_Firing_Rate_In(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position_In(:,N));
    end
    Smoothed_Linear_Firing_Rate_Out(isnan(Smoothed_Linear_Firing_Rate_Out))=0;
    Smoothed_Linear_Firing_Rate_Out(Smoothed_Linear_Firing_Rate_Out<0)=0;
    Smoothed_Linear_Firing_Rate_In(isnan(Smoothed_Linear_Firing_Rate_In))=0;
    Smoothed_Linear_Firing_Rate_In(Smoothed_Linear_Firing_Rate_In<0)=0;
    for Z=1:size(Smoothed_Linear_Firing_Rate_Out,2)
        if max(max(max(Smoothed_Linear_Firing_Rate_Out(:,Z))))<Firing_Rate_Cutoff
            Smoothed_Linear_Firing_Rate_Out(:,Z)=0;
        end
        if max(max(max(Smoothed_Linear_Firing_Rate_In(:,Z))))<Firing_Rate_Cutoff
            Smoothed_Linear_Firing_Rate_In(:,Z)=0;
        end
    end
    Field_Data_Linear_Out=Smoothed_Linear_Firing_Rate_Out;
    Field_Data_Linear_In=Smoothed_Linear_Firing_Rate_In;
    
% I now find the bins that contain the maximum firing rates and create a
% variable that allows the spike data to be plotted according to place
% field peak. The first column is the cell number, the second column is the
% peak bin for bi-directional fields, the third column is the peak bin for
% the out direction, and the fourth column is the peak bin for the in
% direction.
    Firing_Rate_Peaks=zeros(max(Spike_Data(:,2)),4);
    Firing_Rate_Peaks(:,1)=1:max(Spike_Data(:,2));
    for N=1:size(Firing_Rate_Peaks)
        Firing_Rate_Peaks(N,2)=find(Field_Data_Linear(:,N)==max(Field_Data_Linear(:,N)),1,'first');
        Firing_Rate_Peaks(N,3)=find(Field_Data_Linear_Out(:,N)==max(Field_Data_Linear_Out(:,N)),1,'first');
        Firing_Rate_Peaks(N,4)=find(Field_Data_Linear_In(:,N)==max(Field_Data_Linear_In(:,N)),1,'first');
    end
    
    save('Field_Data','Field_Data','Field_Data_Linear','Field_Data_Linear_Out','Field_Data_Linear_In','Firing_Rate_Peaks')
end

end