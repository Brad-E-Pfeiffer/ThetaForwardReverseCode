function IRFS_PLOT_SUPPLEMENTAL_FIGURE_FOUR(Initial_Variables,Forward_Window,Reverse_Window)

Forward_Window=round(Forward_Window/Initial_Variables.Phase_Bin);
Reverse_Window=round(Reverse_Window/Initial_Variables.Phase_Bin);

cd AllRatsCombined

load Combined_Peak_Posterior_Distributions_Minor_Peak_Third

cd _Figures_For_Paper

if exist('SupplementalFigure4','dir')==7
    cd('SupplementalFigure4')
else
    mkdir('SupplementalFigure4')
    cd('SupplementalFigure4')
end

%This plots the weighted correlations for each session for the Forward
%Window and the phase shuffles for all Linear Track sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/9:256),:);

Actual_Weighted_Correlations=zeros(10,1);
P_Values=zeros(10,1);
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
X=0;
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
            %Phase_Shuffle_Weighted_Correlations(Shuffle,2)=WEIGHTED_CORRELATION(Phase_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:10
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.2 0.3]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Linear_Track_Foward_Window_Phase_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close


%This plots the weighted correlations for each session for the Forward
%Window and the cell ID shuffles for all Linear Track sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/9:256),:);

Actual_Weighted_Correlations=zeros(10,1);
P_Values=zeros(10,1);
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
X=0;
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:10
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.2 0.3]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Linear_Track_Foward_Window_Cell_ID_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close


%This plots the weighted correlations for each session for the Reverse
%Window and the phase shuffles for all Linear Track sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/9:256),:);

Actual_Weighted_Correlations=zeros(10,1);
P_Values=zeros(10,1);
X=0;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:10
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.3 0.2]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Linear_Track_Reverse_Window_Phase_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close




%This plots the weighted correlations for each session for the Reverse
%Window and the phase shuffles for all Linear Track sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/9:256),:);

Actual_Weighted_Correlations=zeros(10,1);
P_Values=zeros(10,1);
X=0;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:10
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.3 0.2]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Linear_Track_Reverse_Window_Cell_ID_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close




%This plots the weighted correlations for each session for the Forward
%Window and the phase shuffles for all Open Field sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/5:256),:);

Actual_Weighted_Correlations=zeros(6,1);
P_Values=zeros(6,1);
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
X=0;
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
            %Phase_Shuffle_Weighted_Correlations(Shuffle,2)=WEIGHTED_CORRELATION(Phase_Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:6
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.2 0.3]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Open_Field_Foward_Window_Phase_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close



%This plots the weighted correlations for each session for the Forward
%Window and the cell ID shuffles for all Open Field sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/5:256),:);

Actual_Weighted_Correlations=zeros(6,1);
P_Values=zeros(6,1);
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
X=0;
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,[Forward_Window(1):end,1:Forward_Window(2)],Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,[Forward_Window(1):end,1:Forward_Window(2)]));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:6
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.2 0.3]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Open_Field_Foward_Window_Cell_ID_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close



%This plots the weighted correlations for each session for the Reverse
%Window and the phase shuffles for all Open Field sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/5:256),:);

Actual_Weighted_Correlations=zeros(6,1);
P_Values=zeros(6,1);
X=0;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Phase_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:6
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.3 0.2]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Open_Field_Reverse_Window_Phase_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close



%This plots the weighted correlations for each session for the Reverse
%Window and the phase shuffles for all Open Field sessions
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/5:256),:);

Actual_Weighted_Correlations=zeros(6,1);
P_Values=zeros(6,1);
X=0;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    if Rat==1 %Janni
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==2 %Harpy
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    elseif Rat==3 %Imp
        Directory(1).name='Open1';
        Directory(2).name='Open2';
    end
    for Experiment=1:length(Directory)
        
        X=X+1;
        Directory_Name=Directory(Experiment).name;
        
        eval(sprintf('Raw_Data=%s_%s_Norm_Dist;',Rat_Name,Directory_Name));
        eval(sprintf('Shuffles=%s_%s_Norm_Cell_ID_Shuffle_Dist;',Rat_Name,Directory_Name));
        
        Shuffle_Weighted_Correlations=zeros(Initial_Variables.Number_Of_Shuffles,1);
        for Shuffle=1:Initial_Variables.Number_Of_Shuffles
            Shuffle_Weighted_Correlations(Shuffle,1)=WEIGHTED_CORRELATION(Shuffles(:,Reverse_Window(1):Reverse_Window(2),Shuffle));
        end
        
        Actual_Weighted_Correlations(X,1)=WEIGHTED_CORRELATION(Raw_Data(:,Reverse_Window(1):Reverse_Window(2)));
        P_Values(X,1)=(sum(abs(Shuffle_Weighted_Correlations)>=abs(Actual_Weighted_Correlations(X,1)))+1)/(length(Shuffle_Weighted_Correlations)+1);
        
        plot(-1:0.01:1,hist(Shuffle_Weighted_Correlations,-1:0.01:1)/length(Shuffle_Weighted_Correlations),'Color',Color_Values(X,:),'LineWidth',4);

    end
    clear Directory
    
end
Y_Lim=ylim;
for X=1:6
    if P_Values(X,1)<=0.05
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'Color',Color_Values(X,:),'LineWidth',4);
    else
        plot([Actual_Weighted_Correlations(X,1),Actual_Weighted_Correlations(X,1)],[0 Y_Lim(2)],'--','Color',Color_Values(X,:),'LineWidth',4);
    end
end
set(gca,'YTick',[]);
set(gca,'XLim',[-0.3 0.2]);
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Open_Field_Reverse_Window_Cell_ID_Shuffle(Y=0to%d)(X=%dto%d).jpg'');',Y_Lim(2),X_Lim(1),X_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/5:256),:);
for X=1:6
    plot([1 2],[X X],'Color',Color_Values(X,:),'LineWidth',4);
end
set(gca,'XLim',[0.8 2.2]);
set(gca,'YLim',[0 7]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Open_Field_Legend_Bars.jpg');
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Color_Values=jet;
Color_Values=Color_Values(round(1:255/9:256),:);
for X=1:10
    plot([1 2],[X X],'Color',Color_Values(X,:),'LineWidth',4);
end
set(gca,'XLim',[0.8 2.2]);
set(gca,'YLim',[0 11]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Linear_Track_Legend_Bars.jpg');
close



cd ..
cd ..
cd ..

end