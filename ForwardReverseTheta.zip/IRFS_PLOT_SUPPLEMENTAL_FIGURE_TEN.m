function IRFS_PLOT_SUPPLEMENTAL_FIGURE_TEN

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function plots the data for Supplemental Figure S10
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

cd AllRatsCombined

load Combined_Unimodal_Bimodal_Probability_Sums

figure;
hold on;
boxplot([All_Uni_Prob_Sums_Forward_Window,All_Bi_Prob_Sums_Forward_Window,zeros(length(All_Bi_Prob_Sums_Forward_Window),2)]);
boxplot([zeros(length(All_Bi_Prob_Sums_Reverse_Window),2),All_Uni_Prob_Sums_Reverse_Window,All_Bi_Prob_Sums_Reverse_Window])
plot([0.5 1.5],[mean(All_Uni_Prob_Sums_Forward_Window),mean(All_Uni_Prob_Sums_Forward_Window)],'k--')
plot([1.5 2.5],[mean(All_Bi_Prob_Sums_Forward_Window),mean(All_Bi_Prob_Sums_Forward_Window)],'k--')
plot([3.5 4.5],[mean(All_Bi_Prob_Sums_Reverse_Window),mean(All_Bi_Prob_Sums_Reverse_Window)],'k--')
plot([2.5 3.5],[mean(All_Uni_Prob_Sums_Reverse_Window),mean(All_Uni_Prob_Sums_Reverse_Window)],'k--')
for N=1:16
    plot([1,2],[All_Uni_Prob_Sums_Mean_Forward_Window(N),All_Bi_Prob_Sums_Mean_Forward_Window(N)],'k');
    plot([3,4],[All_Uni_Prob_Sums_Mean_Reverse_Window(N),All_Bi_Prob_Sums_Mean_Reverse_Window(N)],'k');
end
for N=[7,8,11,12,15,16]
    plot([1,2],[All_Uni_Prob_Sums_Mean_Forward_Window(N),All_Bi_Prob_Sums_Mean_Forward_Window(N)],'r');
    plot([3,4],[All_Uni_Prob_Sums_Mean_Reverse_Window(N),All_Bi_Prob_Sums_Mean_Reverse_Window(N)],'r');
end

cd _Figures_For_Paper
mkdir SupplementalFigure10
cd SupplementalFigure10

print('-djpeg','Supplemental_Figure_10.jpg');
close

cd ..
cd ..
cd ..

end