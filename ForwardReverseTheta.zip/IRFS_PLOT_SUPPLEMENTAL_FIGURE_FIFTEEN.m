function IRFS_PLOT_SUPPLEMENTAL_FIGURE_FIFTEEN


cd AllRatsCombined
load Combined_Single_Cell_Phase_Position_Significances
cd _Figures_For_Paper
if exist('SupplementalFigure15','dir')==7
    cd SupplementalFigure15
else
    mkdir SupplementalFigure15
    cd SupplementalFigure15
end

Significance_Level=0.05;

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_S15_Distribution_Of_Major_Peak_Significant_Rs_Restricted_Positions_(Y=0to%d)(Red=Uni;Blue=Bi).jpg'');',Y_Lim(2)));
close

Significance_Level=0.05;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_S15_Distribution_Of_Minor_Peak_Significant_Rs_Restricted_Positions_(Y=0to%d)(Red=Uni;Blue=Bi).jpg'');',Y_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level,1),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_S15_Distribution_Of_Major_Peak_Significant_Rs_All_Positions_(Y=0to%d)(Red=Uni;Blue=Bi).jpg'');',Y_Lim(2)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Histogram=hist(All_Sig_Restricted(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-3:0.3:3,Histogram/sum(Histogram),1/3,'r')
Histogram=hist(All_Sig_Restricted(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level,3),-1:0.1:1);
bar(-2.9:0.3:3.1,Histogram/sum(Histogram),1/3,'b')
set(gca,'XLim',[-3.1 3.2]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure_S15_Distribution_Of_Minor_Peak_Significant_Rs_All_Positions_(Y=0to%d)(Red=Uni;Blue=Bi).jpg'');',Y_Lim(2)));
close


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,2)>Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Unimodal_Major_Significant(%d,%d).jpg'');',sum(All_Sig(:,5)==1 & All_Sig(:,2)<=Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,2)>Significance_Level)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,2)>Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Bimodal_Major_Significant(%d,%d).jpg'');',sum(All_Sig(:,5)==2 & All_Sig(:,2)<=Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,2)>Significance_Level)));
close


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==1 & All_Sig(:,4)>Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Unimodal_Minor_Significant(%d,%d).jpg'');',sum(All_Sig(:,5)==1 & All_Sig(:,4)<=Significance_Level),sum(All_Sig(:,5)==1 & All_Sig(:,4)>Significance_Level)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig(:,5)==2 & All_Sig(:,4)>Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Bimodal_Minor_Significant(%d,%d).jpg'');',sum(All_Sig(:,5)==2 & All_Sig(:,4)<=Significance_Level),sum(All_Sig(:,5)==2 & All_Sig(:,4)>Significance_Level)));
close


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)>Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Unimodal_Major_Significant_Restricted_Positions(%d,%d).jpg'');',sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)<=Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,2)>Significance_Level)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)>Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Bimodal_Major_Significant_Restricted_Positions(%d,%d).jpg'');',sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)<=Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,2)>Significance_Level)));
close


figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)>Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Unimodal_Minor_Significant_Restricted_Positions(%d,%d).jpg'');',sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)<=Significance_Level),sum(All_Sig_Restricted(:,5)==1 & All_Sig_Restricted(:,4)>Significance_Level)));
close

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Labels=repmat({' '},[2 1]);
pie([sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)>Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level)],Labels);
set(gca,'XLim',[-1 1]);
set(gca,'YLim',[-1 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
colormap('hot')
eval(sprintf('print(''-djpeg'',''Figure_S15_Number_Of_Bimodal_Minor_Significant_Restricted_Positions(%d,%d).jpg'');',sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)<=Significance_Level),sum(All_Sig_Restricted(:,5)==2 & All_Sig_Restricted(:,4)>Significance_Level)));
close




cd ..
cd ..
cd ..




end

