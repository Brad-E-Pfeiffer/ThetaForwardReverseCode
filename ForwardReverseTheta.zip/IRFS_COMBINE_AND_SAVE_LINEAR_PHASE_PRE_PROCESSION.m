function IRFS_COMBINE_AND_SAVE_LINEAR_PHASE_PRE_PROCESSION(Initial_Variables,Major_Peak_Window,Minor_Peak_Window)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up all of the linear phase vs. position data for each
% linear track session and combines the data as well as calculates p-values
% for each session and for all linear track sessions combined.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Number_Of_Shuffles=Initial_Variables.Number_Of_Shuffles_For_Phase_Position_Relationship;

All_Unimodal_Phase_Position_Histogram=zeros(round(720/Initial_Variables.Phase_Bin),20);
All_Bimodal_Phase_Position_Histogram=zeros(round(720/Initial_Variables.Phase_Bin),20);

All_Unimodal_Phase_Position_Histogram_Phase_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
All_Bimodal_Phase_Position_Histogram_Phase_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
All_Unimodal_Phase_Position_Histogram_Position_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
All_Bimodal_Phase_Position_Histogram_Position_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Imp';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
        Directory(5).name='Linear5';
        Directory(6).name='Linear6';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    elseif Rat==3 %Imp
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load('Spike_Data_With_Linear_Position','Out_Position_Phase_Histograms','In_Position_Phase_Histograms','Out_Position_Phase_Histograms_Phase_Shuffles','In_Position_Phase_Histograms_Phase_Shuffles','Out_Position_Phase_Histograms_Position_Shuffles','In_Position_Phase_Histograms_Position_Shuffles');
        load('Modality','Modality');
        
        Session_Unimodal=zeros(round(720/Initial_Variables.Phase_Bin),20);
        Session_Bimodal=zeros(round(720/Initial_Variables.Phase_Bin),20);
        Session_Unimodal_Phase_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
        Session_Bimodal_Phase_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
        Session_Unimodal_Position_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
        Session_Bimodal_Position_Shuffles=zeros(round(720/Initial_Variables.Phase_Bin),20,1000);
        
        for Current_Cell=1:size(Modality,1)
            Current_Cell_Modality=Modality(Current_Cell,1);
            if Current_Cell_Modality==1 || Current_Cell_Modality==2  %Only look at Unimodal or Bimodal cells
                Out=Out_Position_Phase_Histograms(:,:,Current_Cell);
                In=In_Position_Phase_Histograms(:,:,Current_Cell);
                Out_Phase_Shuffles=permute(Out_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,:),[1,2,4,3]);
                In_Phase_Shuffles=permute(In_Position_Phase_Histograms_Phase_Shuffles(:,:,Current_Cell,:),[1,2,4,3]);
                Out_Position_Shuffles=permute(Out_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,:),[1,2,4,3]);
                In_Position_Shuffles=permute(In_Position_Phase_Histograms_Position_Shuffles(:,:,Current_Cell,:),[1,2,4,3]);
                
                if sum(sum(Out))>0 || sum(sum(In))>0 %If either the In or Out direction had sufficient spikes/coverage/etc to meet the criteria for analysis
                    if sum(sum(Out))>0 && sum(sum(In))>0  %If both In and Out directions met the criteria
                        Cell_Histogram=Out+In;
                        Phase_Shuffles=[Out_Phase_Shuffles+In_Phase_Shuffles;Out_Phase_Shuffles+In_Phase_Shuffles];
                        Position_Shuffles=[Out_Position_Shuffles+In_Position_Shuffles;Out_Position_Shuffles+In_Position_Shuffles];
                    elseif sum(sum(Out))>0  %If only Out directions met the criteria
                        Cell_Histogram=Out;
                        Phase_Shuffles=[Out_Phase_Shuffles;Out_Phase_Shuffles];
                        Position_Shuffles=[Out_Position_Shuffles;Out_Position_Shuffles];
                    elseif sum(sum(In))>0  %If only In directions met the criteria
                        Cell_Histogram=In;
                        Phase_Shuffles=[In_Phase_Shuffles;In_Phase_Shuffles];
                        Position_Shuffles=[In_Position_Shuffles;In_Position_Shuffles];
                    end
                    Cell_Histogram=Cell_Histogram/sum(sum(Cell_Histogram));
                    for Shuffle=1:Number_Of_Shuffles
                        Phase_Shuffles(:,:,Shuffle)=Phase_Shuffles(:,:,Shuffle)/sum(sum(Phase_Shuffles(:,:,Shuffle)));
                        Position_Shuffles(:,:,Shuffle)=Position_Shuffles(:,:,Shuffle)/sum(sum(Position_Shuffles(:,:,Shuffle)));
                    end
                    
                    %This combines the histogram with the session and overall summary
                    if Current_Cell_Modality==1
                        Session_Unimodal=Session_Unimodal+Cell_Histogram;
                        All_Unimodal_Phase_Position_Histogram=All_Unimodal_Phase_Position_Histogram+Cell_Histogram;
                        Session_Unimodal_Phase_Shuffles=Session_Unimodal_Phase_Shuffles+Phase_Shuffles;
                        Session_Unimodal_Position_Shuffles=Session_Unimodal_Position_Shuffles+Position_Shuffles;
                        All_Unimodal_Phase_Position_Histogram_Phase_Shuffles=All_Unimodal_Phase_Position_Histogram_Phase_Shuffles+Phase_Shuffles;
                        All_Unimodal_Phase_Position_Histogram_Position_Shuffles=All_Unimodal_Phase_Position_Histogram_Position_Shuffles+Position_Shuffles;
                    elseif Current_Cell_Modality==2
                        Session_Bimodal=Session_Bimodal+Cell_Histogram;
                        All_Bimodal_Phase_Position_Histogram=All_Bimodal_Phase_Position_Histogram+Cell_Histogram;
                        Session_Bimodal_Phase_Shuffles=Session_Bimodal_Phase_Shuffles+Phase_Shuffles;
                        Session_Bimodal_Position_Shuffles=Session_Bimodal_Position_Shuffles+Position_Shuffles;
                        All_Bimodal_Phase_Position_Histogram_Phase_Shuffles=All_Bimodal_Phase_Position_Histogram_Phase_Shuffles+Phase_Shuffles;
                        All_Bimodal_Phase_Position_Histogram_Position_Shuffles=All_Bimodal_Phase_Position_Histogram_Position_Shuffles+Position_Shuffles;
                    end
                end
            end
        end
        
        clear Modality;
        clear Out_Position_Phase_Histograms;
        clear In_Position_Phase_Histograms;
        clear Out_Smoothed_Position_Phase_Histograms;
        clear In_Smoothed_Position_Phase_Histograms;
        clear Cell_Histogram;
        clear Smoothed_Cell_Histogram;
        clear Phase_Shuffles;
        clear Position_Shuffles;
        
        Unimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Session_Unimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
        Bimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Session_Bimodal(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
        Unimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Session_Unimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
        Bimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(Session_Bimodal(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
        Unimodal_Phase_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
        Unimodal_Position_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
        Bimodal_Phase_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
        Bimodal_Position_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
        for Shuffle=1:Number_Of_Shuffles
            Unimodal_Phase_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Session_Unimodal_Phase_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
            Unimodal_Phase_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Session_Unimodal_Phase_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
            Unimodal_Position_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Session_Unimodal_Position_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
            Unimodal_Position_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Session_Unimodal_Position_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
            Bimodal_Phase_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Session_Bimodal_Phase_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
            Bimodal_Phase_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Session_Bimodal_Phase_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
            Bimodal_Position_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(Session_Bimodal_Position_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
            Bimodal_Position_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(Session_Bimodal_Position_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
        end
        Unimodal_P_Values=[max([(sum(abs(Unimodal_Phase_Shuffle_Correlations(:,1))>=abs(Unimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(Unimodal_Position_Shuffle_Correlations(:,1))>=abs(Unimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1)]),max([(sum(abs(Unimodal_Phase_Shuffle_Correlations(:,2))>=abs(Unimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(Unimodal_Position_Shuffle_Correlations(:,2))>=abs(Unimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1)])]; %Major Window, Minor Window
        Bimodal_P_Values=[max([(sum(abs(Bimodal_Phase_Shuffle_Correlations(:,1))>=abs(Bimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(Bimodal_Position_Shuffle_Correlations(:,1))>=abs(Bimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1)]),max([(sum(abs(Bimodal_Phase_Shuffle_Correlations(:,2))>=abs(Bimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(Bimodal_Position_Shuffle_Correlations(:,2))>=abs(Bimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1)])]; %Major Window, Minor Window
        
        eval(sprintf('%s_%s_Unimodal_Phase_Position_Histogram=Session_Unimodal/sum(sum(Session_Unimodal));',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Bimodal_Phase_Position_Histogram=Session_Bimodal/sum(sum(Session_Bimodal));',Rat_Name,Directory_Name));
        eval(sprintf('%s_%s_Unimodal_Major_Peak_Correlation=[Unimodal_Major_Peak_Correlation,Unimodal_Minor_Peak_Correlation];',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_Bimodal_Major_Peak_Correlation=[Bimodal_Major_Peak_Correlation,Bimodal_Minor_Peak_Correlation];',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_Unimodal_Phase_Shuffle_Correlations=Unimodal_Phase_Shuffle_Correlations;',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_Unimodal_Position_Shuffle_Correlations=Unimodal_Position_Shuffle_Correlations;',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_Bimodal_Phase_Shuffle_Correlations=Bimodal_Phase_Shuffle_Correlations;',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_Bimodal_Position_Shuffle_Correlations=Bimodal_Position_Shuffle_Correlations;',Rat_Name,Directory_Name)); %Major Window, Minor Window
        eval(sprintf('%s_%s_P_Values=[Unimodal_P_Values,Bimodal_P_Values];',Rat_Name,Directory_Name)); %Unimodal_Major Window, Unimodal_Minor_Window, Bimodal_Major_Window, Bimodal_Minor_Window
        
        clear Session_Unimodal;
        clear Session_Bimodal;
        clear Session_Out_Unimodal;
        clear Session_Out_Bimodal;
        clear Session_In_Unimodal;
        clear Session_In_Bimodal;
        clear Session_Out_Smoothed_Unimodal;
        clear Session_Out_Smoothed_Bimodal;
        clear Session_In_Smoothed_Unimodal;
        clear Session_In_Smoothed_Bimodal;
        clear Current_Cell;
        clear Current_Cell_Modality;
        clear In;
        clear Out;
        clear In_Smoothed;
        clear Out_Smoothed;
        
        cd ..
        
    end
    clear Directory
    clear Directory_Name
    cd ..
    
end

All_Unimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
All_Bimodal_Major_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:));
All_Unimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
All_Bimodal_Minor_Peak_Correlation=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:));
All_Unimodal_Phase_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
All_Unimodal_Position_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
All_Bimodal_Phase_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
All_Bimodal_Position_Shuffle_Correlations=zeros(Number_Of_Shuffles,2); %Major Window, Minor Window
for Shuffle=1:Number_Of_Shuffles
    All_Unimodal_Phase_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram_Phase_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Unimodal_Phase_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram_Phase_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Unimodal_Position_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram_Position_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Unimodal_Position_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(All_Unimodal_Phase_Position_Histogram_Position_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Bimodal_Phase_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram_Phase_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Bimodal_Phase_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram_Phase_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Bimodal_Position_Shuffle_Correlations(Shuffle,1)=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram_Position_Shuffles(round(Major_Peak_Window(1)/Initial_Variables.Phase_Bin):round((Major_Peak_Window(2)+360)/Initial_Variables.Phase_Bin),:,Shuffle));
    All_Bimodal_Position_Shuffle_Correlations(Shuffle,2)=IRFS_WEIGHTED_CORRELATION(All_Bimodal_Phase_Position_Histogram_Position_Shuffles(round(Minor_Peak_Window(1)/Initial_Variables.Phase_Bin):round(Minor_Peak_Window(2)/Initial_Variables.Phase_Bin),:,Shuffle));
end
All_Unimodal_P_Values=[max([(sum(abs(All_Unimodal_Phase_Shuffle_Correlations(:,1))>=abs(All_Unimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(All_Unimodal_Position_Shuffle_Correlations(:,1))>=abs(All_Unimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1)]),max([(sum(abs(All_Unimodal_Phase_Shuffle_Correlations(:,2))>=abs(All_Unimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(All_Unimodal_Position_Shuffle_Correlations(:,2))>=abs(All_Unimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1)])]; %Major Window, Minor Window
All_Bimodal_P_Values=[max([(sum(abs(All_Bimodal_Phase_Shuffle_Correlations(:,1))>=abs(All_Bimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(All_Bimodal_Position_Shuffle_Correlations(:,1))>=abs(All_Bimodal_Major_Peak_Correlation))+1)/(Number_Of_Shuffles+1)]),max([(sum(abs(All_Bimodal_Phase_Shuffle_Correlations(:,2))>=abs(All_Bimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1),(sum(abs(All_Bimodal_Position_Shuffle_Correlations(:,2))>=abs(All_Bimodal_Minor_Peak_Correlation))+1)/(Number_Of_Shuffles+1)])]; %Major Window, Minor Window

cd AllRatsCombined
save('Combined_Linear_Phase_Position_Histograms','Janni*','Harpy*','Imp*','All*')
clear Rat
clear Rat_Name
clear Experiment
clear Rats
cd ..




figure;hold on;
imagesc(All_Unimodal_Phase_Position_Histogram);colormap('jet');

figure;hold on;
imagesc(All_Bimodal_Phase_Position_Histogram);colormap('jet');


AU=All_Unimodal_Phase_Position_Histogram;
for N=1:size(AU,2)
    AU(:,N)=AU(:,N)/sum(AU(:,N));
end
Filter=fspecial('gaussian',[10 5],2); %This is the filter used to smooth the position-phase histograms
Smoothed_Position_Phase_Histogram=filter2(Filter,All_Unimodal_Phase_Position_Histogram);
Smoothed_Position_Phase_Histogram=filter2(Filter,AU);
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
figure;hold on;
subplot(2,1,1);hold on;
imagesc(Interpolated_Position_Phase_Histogram);colormap('jet');
subplot(2,1,2);hold on;
contour(Interpolated_Position_Phase_Histogram,15,'k');

AB=All_Bimodal_Phase_Position_Histogram;
for N=1:size(AB,2)
    AB(:,N)=AB(:,N)/sum(AB(:,N));
end
Smoothed_Position_Phase_Histogram=filter2(Filter,All_Bimodal_Phase_Position_Histogram);
Smoothed_Position_Phase_Histogram=filter2(Filter,AB);
Smoothed_Position_Phase_Histogram=Smoothed_Position_Phase_Histogram([ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin),ceil(361/Initial_Variables.Phase_Bin):round(540/Initial_Variables.Phase_Bin),ceil(181/Initial_Variables.Phase_Bin):round(360/Initial_Variables.Phase_Bin)],:);
Interpolated_Position_Phase_Histogram=interp2(permute(ones(20,round(720/Initial_Variables.Phase_Bin)).*(-0.95:0.1:0.95)',[2,1]),ones(round(720/Initial_Variables.Phase_Bin),20).*(Initial_Variables.Phase_Bin:Initial_Variables.Phase_Bin:720)',Smoothed_Position_Phase_Histogram,permute(ones(200,720).*(-0.995:0.01:0.995)',[2,1]),ones(720,200).*(1:1:720)');
Interpolated_Position_Phase_Histogram=Interpolated_Position_Phase_Histogram([361:540,181:360,361:540,181:360],:);
figure;hold on;
subplot(2,1,1);hold on;
imagesc(Interpolated_Position_Phase_Histogram);colormap('jet');
subplot(2,1,2);hold on;
contour(Interpolated_Position_Phase_Histogram,15,'k');





end


