cd AllRatsCombined

load Unimodal_Bimodal_Ripple_Replay_Participation

cd _Figures_For_Paper
cd Figure2

Unimodal_Ripple_Ratios=All_Ripple_Spike_Ratios(All_Ripple_Spike_Ratios(:,1)==1,2);
Bimodal_Ripple_Ratios=All_Ripple_Spike_Ratios(All_Ripple_Spike_Ratios(:,1)==2,2);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1 2],[mean(Unimodal_Ripple_Ratios) 0],'r');
bar([1,2],[0 mean(Bimodal_Ripple_Ratios)],'b');
errorbar([1,2],[mean(Unimodal_Ripple_Ratios) mean(Bimodal_Ripple_Ratios)],[std(Unimodal_Ripple_Ratios)/sqrt(length(Unimodal_Ripple_Ratios)) std(Bimodal_Ripple_Ratios)/sqrt(length(Bimodal_Ripple_Ratios))],'k','LineWidth',4,'CapSize',0)
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2C_(Red=Unimodal(N=%d);Blue=Bimodal(N=%d)_(Y=0to%d).jpg'');',length(Unimodal_Ripple_Ratios),length(Bimodal_Ripple_Ratios),Y_Lim(2)));
close

Unimodal_Replay_Ratios=All_Replay_Spike_Ratios(All_Replay_Spike_Ratios(:,1)==1,2);
Bimodal_Replay_Ratios=All_Replay_Spike_Ratios(All_Replay_Spike_Ratios(:,1)==2,2);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1 2],[mean(Unimodal_Replay_Ratios) 0],'r');
bar([1,2],[0 mean(Bimodal_Replay_Ratios)],'b');
errorbar([1,2],[mean(Unimodal_Replay_Ratios) mean(Bimodal_Replay_Ratios)],[std(Unimodal_Replay_Ratios)/sqrt(length(Unimodal_Replay_Ratios)) std(Bimodal_Replay_Ratios)/sqrt(length(Bimodal_Replay_Ratios))],'k','LineWidth',4,'CapSize',0)
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2DLeft_(Red=Unimodal(N=%d);Blue=Bimodal(N=%d)_(Y=0to%d).jpg'');',length(Unimodal_Replay_Ratios),length(Bimodal_Replay_Ratios),Y_Lim(2)));
close

Bimodal_Forward_Replay_Ratios=All_Forward_Replay_Spike_Ratios(All_Forward_Replay_Spike_Ratios(:,1)==2,2);
Bimodal_Reverse_Replay_Ratios=All_Reverse_Replay_Spike_Ratios(All_Reverse_Replay_Spike_Ratios(:,1)==2,2);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1 2],[mean(Bimodal_Forward_Replay_Ratios) 0],'b');
bar([1,2],[0 mean(Bimodal_Reverse_Replay_Ratios)],'w');
errorbar([1,2],[mean(Bimodal_Forward_Replay_Ratios) mean(Bimodal_Reverse_Replay_Ratios)],[std(Bimodal_Forward_Replay_Ratios)/sqrt(length(Bimodal_Forward_Replay_Ratios)) std(Bimodal_Reverse_Replay_Ratios)/sqrt(length(Bimodal_Reverse_Replay_Ratios))],'k','LineWidth',4,'CapSize',0)
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'YLim',[0 Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Figure2DRight_(Blue=Forward(N=%d);White=Reverse(N=%d)_(Y=0to%d).jpg'');',length(Bimodal_Forward_Replay_Ratios),length(Bimodal_Reverse_Replay_Ratios),Y_Lim(2)));
close

cd ..
cd ..
cd ..