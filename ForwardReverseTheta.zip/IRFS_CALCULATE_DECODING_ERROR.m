function [Position_Error,Cumulative_Position_Error]=IRFS_CALCULATE_DECODING_ERROR(Position_Data,Spike_Data,Inhibitory_Neurons,Field_Data,Bin_Size,Velocity_Threshold,Run_Times,Position_Estimation_Time_Bin_Size,Position_Estimation_Step,Rat_Name)


% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% The purpose of this program is to decode the rat's position throughout
% the entire run portion of the experiment and determine the error between
% the peak posterior probability of this decoded position and the rat's 
% actual position.  It does this only for running periods (velocity greater
% than 5 cm/sec) and only for time bins with at least one spike.
% 
% Position_Data is a two-dimensional variable where the first column is
% time, and the second and third columns are, respectively, the rat's
% actual X- and Y-position at each timepoint.
% 
% Field_Data is a three-dimensional variable containing the place field
% information in two dimensions for each cell (the third dimension).
% 
% Bin_Size is the size (in cm) of each bin.  Run_Times lists the start and
% end of each run session.  Velocity_Threshold is the speed (cm/s) that the
% rat must be moving in order for the decoding algorithm to decode the
% error.
% 
% Position_Estimation_Time_Bin_Size and Position_Estimation_Step are single
% values that respectively determine (in seconds) how large each window of
% decoding is and how large of a step each subsequent frame of decoding
% should be.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if ~exist('Field_Data','var')
    load Field_Data;
end
if ~exist('Position_Data','var')
    load Position_Data;
end
if ~exist('Spike_Data','var')
    load('Spike_Data','Spike_Data');
end
if ~exist('Inhibitory_Neurons','var')
    load('Spike_Data','Inhibitory_Neurons');
end
if ~exist('Run_Times','var')
    load('Experiment_Information','Run_Times');
end
if ~exist('Bin_Size','var')
    Bin_Size=2;
end
if ~exist('Velocity_Threshold','var')
    Velocity_Threshold=5;
end
if ~exist('Position_Estimation_Time_Bin_Size','var')
    Position_Estimation_Time_Bin_Size=0.25;
end
if ~exist('Position_Estimation_Step','var')
    Position_Estimation_Step=0.25;
end
if ~exist('Rat_Name','var')
    load('Experiment_Information','Rat_Name');
end

% This sets up the start and end times and pre-allocates the space for the
% position error measurement
Start_Time=Run_Times(1,1);
End_Time=Run_Times(end,end);
Number_Of_Bins=ceil((End_Time-Start_Time)/Position_Estimation_Step);
Position_Error=zeros(Number_Of_Bins,2);

% First, because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data2=Field_Data;
for N=1:size(Field_Data2,3)
    Field=Field_Data2(:,:,N);
    Minimum=min(min(Field(Field>0)));
    if ~isempty(Minimum)
        if Minimum/10>0
            Field(Field<=0)=Minimum/10;
        else
            Field(Field<=0)=Minimum;
        end
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data2(:,:,N)=Field;
    clear Minimum;
    clear Field;
end

% This calculates the velocity for the position data
Velocity=IRFS_CALCULATE_VELOCITY(Position_Data);
Position_Data(:,4)=Velocity;
clear Velocity;

% This restricts the decoding only to excitatory neurons
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end

% This finds the occupancy throughout the experiment
True_Cumulative_Position_Occupancy=zeros(size(Field_Data,1),size(Field_Data,2));
New_Position_Data=Position_Data;
New_Position_Data=New_Position_Data(New_Position_Data(:,4)>=Velocity_Threshold,:);
New_Position_Data(:,2)=round(New_Position_Data(:,2)/Bin_Size);
New_Position_Data(:,3)=round(New_Position_Data(:,3)/Bin_Size);
New_Position_Data(New_Position_Data(:,2)<1,2)=1;
New_Position_Data(New_Position_Data(:,2)>size(Field_Data,2),2)=size(Field_Data,2);
New_Position_Data(New_Position_Data(:,3)<1,3)=1;
New_Position_Data(New_Position_Data(:,3)>size(Field_Data,1),3)=size(Field_Data,1);
for N=1:size(New_Position_Data,1)
    True_Cumulative_Position_Occupancy(New_Position_Data(N,3),New_Position_Data(N,2))=True_Cumulative_Position_Occupancy(New_Position_Data(N,3),New_Position_Data(N,2))+mean(diff(New_Position_Data(:,1)));
end
clear New_Position_Data;
clear N;

% Here, the program decodes the data.
Cumulative_Position_Occupancy=zeros(size(Field_Data,1),size(Field_Data,2));
Line=0;
while Start_Time<End_Time
    Subset_Position_Data=Position_Data(Position_Data(:,1)>=Start_Time & Position_Data(:,1)<(Start_Time+Position_Estimation_Time_Bin_Size),:);
    if ~isempty(Subset_Position_Data) && mean(Subset_Position_Data(:,4))>=Velocity_Threshold
        Subset_Spike_Data=Spike_Data(Spike_Data(:,1)>=Start_Time & Spike_Data(:,1)<(Start_Time+Position_Estimation_Time_Bin_Size),:);
        if ~isempty(Subset_Spike_Data)
            Line=Line+1;
            Actual_X_Position=mean(Subset_Position_Data(:,2))/Bin_Size;
            Actual_Y_Position=mean(Subset_Position_Data(:,3))/Bin_Size;
            Decoded_Matrix=prod(Field_Data2(:,:,Subset_Spike_Data(:,2)),3).*exp(-Position_Estimation_Time_Bin_Size*sum(Field_Data,3));
            if isinf(max(max(Decoded_Matrix)))
                Divider=1;
                while isinf(max(max(Decoded_Matrix)))
                    Decoded_Matrix=prod((Field_Data2(:,:,Subset_Spike_Data(:,2))/(2^Divider)),3).*exp(-Position_Estimation_Time_Bin_Size*sum((Field_Data/(2^Divider)),3));
                    Divider=Divider+1;
                end
                clear Divider;
            end
            Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
            if max(max(Decoded_Matrix))>0
                [Max_Y_Position,Max_X_Position]=find(Decoded_Matrix==max(max(Decoded_Matrix)),1,'first');
            else
                Max_Y_Position=0;
                Max_X_Position=0;
            end
            Error=sqrt((abs(Max_X_Position-Actual_X_Position)^2)+(abs(Max_Y_Position-Actual_Y_Position)^2))*Bin_Size;
            Position_Error(Line,:)=[Start_Time,Error];
            if exist('Cumulative_Posterior_Probabilities','var')
                Cumulative_Posterior_Probabilities=Cumulative_Posterior_Probabilities+Decoded_Matrix;
            else
                Cumulative_Posterior_Probabilities=Decoded_Matrix;
            end
            Actual_Y_Position=max([1,min([size(Field_Data,1),round(Actual_Y_Position)])]);
            Actual_X_Position=max([1,min([size(Field_Data,2),round(Actual_X_Position)])]);
            Cumulative_Position_Occupancy(Actual_Y_Position,Actual_X_Position)=Cumulative_Position_Occupancy(Actual_Y_Position,Actual_X_Position)+Position_Estimation_Time_Bin_Size;
        end
    end
    Start_Time=Start_Time+Position_Estimation_Step;
end
Position_Error=Position_Error(1:Line,:);
Mean_Decoding_Error=mean(Position_Error(:,2));

Cumulative_Position_Error=Position_Error(:,2);
Cumulative_Position_Error=sort(Cumulative_Position_Error);
Cumulative_Position_Error(:,2)=0:1/(size(Cumulative_Position_Error,1)-1):1;
save('Position_Decoding_Error','Cumulative_Position_Error','Position_Error','Cumulative_Position_Occupancy','True_Cumulative_Position_Occupancy','Cumulative_Posterior_Probabilities','Mean_Decoding_Error')

if 0, %This plots the data, if necessary
    figure;subplot('Position',[0 0 1 1]);
    plot(Cumulative_Position_Error(:,1),Cumulative_Position_Error(:,2),'k','LineWidth',3);
    set(gca,'YLim',[0 1.02])
    set(gca,'XLim',[0 ceil(max(Position_Error(:,2)))]);
    set(gca,'XTick',[]);set(gca,'YTick',[]);
    if exist('Figures','dir')
        cd Figures
    else
        mkdir('Figures')
        cd Figures
    end
    print('-djpeg',sprintf('%s_Cumulative_Position_Error_XLim(%d)_YLim(1)_TimeBin(%dms).jpg',Rat_Name,round(max([200 max(Position_Error(:,2))])),round(Position_Estimation_Time_Bin_Size*1000)));
    close
    figure;subplot('Position',[0 0 1 1]);
    imagesc(True_Cumulative_Position_Occupancy,[0 max(max(True_Cumulative_Position_Occupancy))]);
    colormap('hot');
    set(gca,'XTick',[]);set(gca,'YTick',[]);
    print('-djpeg',sprintf('%s_Cumulative_True_Position_Occupancy_(Max=%s).jpg',Rat_Name,num2str(max(max(True_Cumulative_Position_Occupancy)),'%10.2f')));
    close;
    figure;subplot('Position',[0 0 1 1]);
    imagesc(Cumulative_Posterior_Probabilities,[0 max(max(Cumulative_Posterior_Probabilities))]);
    colormap('hot');
    set(gca,'XTick',[]);set(gca,'YTick',[]);
    print('-djpeg',sprintf('%s_Cumulative_Decoded_Posterior_Probabilities_During_Behavior_(Max=%s).jpg',Rat_Name,num2str(max(max(Cumulative_Posterior_Probabilities)),'%10.2f')));
    close;
    cd ..
end

end