% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This scripts finds the troughs in the decoded posterior probabilities and
% uses those as analysis windows to separate the forward theta sequence
% from the reverse theta sequence.
%
% This script looks at the decoded theta sequence data as well as the
% histograms of firing rate vs. theta phase and identifies the windows for
% analyzing forward vs. reverse components of theta oscillations.
% 
% Spiking_Major_Peak is the start and end (in degrees) of the theta oscillation based on the trough of the unimodal Firing Rate Index 
% Mean_Decoding_Major_Peak is the start and end (in degrees) of the theta oscillation based on the trough of the decoding posterior probabilities
% 
% Spiking_Bimodal_Primary_Window is the start and end (in degrees) of the Primary window based on the troughs of the bimodal Firing Rate Index
% Spiking_Bimodal_Secondary_Window is the start and end (in degrees) of the Secondary window based on the troughs of the bimodal Firing Rate Index 
% Mean_Decoding_Bimodal_Primary_Window is the start and end (in degrees) of the Primary window based on the troughs of the decoding posterior probabilities 
% Mean_Decoding_Bimodal_Secondary_Window is the start and end (in degrees) of the Secondary window based on the troughs of the decoding posterior probabilities 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if exist('Average_Theta_Sequence_And_Posterior_Dists.mat','file')==2
    load Average_Theta_Sequence_And_Posterior_Dists
    
else
    
    Number_Of_Theta_Bins=ceil(360/Phase_Bin);
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
    Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
    Trimmed_Unimodal_Decoding_Time_Info=Decoding_Time_Info(Unimodal_Decoding_Window_Index,:);
    Trimmed_Unimodal_Decoding_Time_Info(Trimmed_Unimodal_Decoding_Time_Info(:,6)==0,6)=360;
    Trimmed_Bimodal_Decoding_Time_Info=Decoding_Time_Info(Bimodal_Decoding_Window_Index,:);
    Trimmed_Bimodal_Decoding_Time_Info(Trimmed_Bimodal_Decoding_Time_Info(:,6)==0,6)=360;
    
    %This calculates the average theta sequence
    Average_Decoded_Theta_Sequence=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins);
    Average_Decoded_Theta_Sequence_Unimodal_Only=zeros(size(Unimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Average_Decoded_Theta_Sequence_Bimodal_Only=zeros(size(Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:Number_Of_Theta_Bins
        Average_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data(:,Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
        Average_Decoded_Theta_Sequence_Unimodal_Only(:,N)=mean(Unimodal_Decoded_Data(:,Trimmed_Unimodal_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Unimodal_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
        Average_Decoded_Theta_Sequence_Bimodal_Only(:,N)=mean(Bimodal_Decoded_Data(:,Trimmed_Bimodal_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Bimodal_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
    end
    clear N;
    
    %This calculates the distribution of peak posterior probabilities across the entire session
    Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
    
    Dist_Of_Peak_Post=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins);
    Dist_Of_Peak_Post_Unimodal_Only=zeros(size(Unimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Dist_Of_Peak_Post_Bimodal_Only=zeros(size(Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==N);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                for M=1:size(Decoded_Data,1)
                    Maxes=max(Current_Oscillation_Decoded_Data(M,:));
                    if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                        Dist_Of_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                    end
                    clear Max_Phases;
                    clear Maxes;
                end
            end
            clear Current_Oscillation_Decoding_Time_Info;
            clear Current_Oscillation_Decoded_Data;
            clear M;
        end
    end
    clear N;
    for N=1:max(Trimmed_Unimodal_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Unimodal_Decoded_Data(:,Trimmed_Unimodal_Decoding_Time_Info(:,14)==N);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Unimodal_Decoding_Time_Info(Trimmed_Unimodal_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                for M=1:size(Unimodal_Decoded_Data,1)
                    [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                    if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                        Dist_Of_Peak_Post_Unimodal_Only(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Peak_Post_Unimodal_Only(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                    end
                    clear Max_Phases;
                    clear Maxes;
                end
                clear Current_Oscillation_Decoding_Time_Info;
                clear Current_Oscillation_Decoded_Data;
                clear M;
            end
        end
    end
    clear N;
    for N=1:max(Trimmed_Bimodal_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Bimodal_Decoded_Data(:,Trimmed_Bimodal_Decoding_Time_Info(:,14)==N);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Bimodal_Decoding_Time_Info(Trimmed_Bimodal_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                for M=1:size(Bimodal_Decoded_Data,1)
                    [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                    if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                        Dist_Of_Peak_Post_Bimodal_Only(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Peak_Post_Bimodal_Only(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                    end
                    clear Max_Phases;
                    clear Maxes;
                end
                clear Current_Oscillation_Decoding_Time_Info;
                clear Current_Oscillation_Decoded_Data;
                clear M;
            end
        end
    end
    clear N;
    Norm_Dist_Of_Peak_Post=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins);
    Norm_Dist_Of_Peak_Post_Unimodal_Only=zeros(size(Unimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    Norm_Dist_Of_Peak_Post_Bimodal_Only=zeros(size(Bimodal_Decoded_Data,1),Number_Of_Theta_Bins);
    for N=1:size(Dist_Of_Peak_Post,2)
        Norm_Dist_Of_Peak_Post(:,N)=Dist_Of_Peak_Post(:,N)/sum(Dist_Of_Peak_Post(:,N));
    end
    for N=1:size(Dist_Of_Peak_Post_Unimodal_Only,2)
        Norm_Dist_Of_Peak_Post_Unimodal_Only(:,N)=Dist_Of_Peak_Post_Unimodal_Only(:,N)/sum(Dist_Of_Peak_Post_Unimodal_Only(:,N));
    end
    for N=1:size(Dist_Of_Peak_Post_Bimodal_Only,2)
        Norm_Dist_Of_Peak_Post_Bimodal_Only(:,N)=Dist_Of_Peak_Post_Bimodal_Only(:,N)/sum(Dist_Of_Peak_Post_Bimodal_Only(:,N));
    end
    
    %This calculates the distribution of peak posterior probabilities based on
    %firing in the Forward or Reverse windows
    
    Dist_Of_Spike_Counts_In_Major_Peak=zeros(max(Trimmed_Decoding_Time_Info(:,14)),1);
    Major_Peak_Order_By_Thirds=zeros(ceil(max(Trimmed_Decoding_Time_Info(:,14))/3),3);
    Major_Peak_Order_By_Tenths=zeros(ceil(max(Trimmed_Decoding_Time_Info(:,14))/10),10);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
        if ~isempty(Current_Oscillation_Decoding_Time_Info) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,9)==0,1)) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,10)==0,1))
            Dist_Of_Spike_Counts_In_Major_Peak(N,1)=mode(Current_Oscillation_Decoding_Time_Info(:,12));
        else
            Dist_Of_Spike_Counts_In_Major_Peak(N,1)=-1;
        end
    end
    clear N;
    clear Current_Oscillation_Decoding_Time_Info
    [Ordered_Data,Rank_Order_Index]=sortrows(Dist_Of_Spike_Counts_In_Major_Peak(:,1));
    Rank_Order_Index=Rank_Order_Index(Ordered_Data>=0);
    clear Ordered_Data;
    for N=1:3
        Current_Third_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/3)+1):round((N*length(Rank_Order_Index))/3));
        Major_Peak_Order_By_Thirds(1:length(Current_Third_Index),N)=Current_Third_Index;
        clear Current_Third_Index;
    end
    clear N;
    Current_Line=1;
    while max(Major_Peak_Order_By_Thirds(Current_Line,:))>0 && Current_Line<=length(Major_Peak_Order_By_Thirds)
        Current_Line=Current_Line+1;
    end
    Major_Peak_Order_By_Thirds=Major_Peak_Order_By_Thirds(1:(Current_Line-1),:);
    clear Current_Line;
    for N=1:10
        Current_Tenth_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/10)+1):round((N*length(Rank_Order_Index))/10));
        Major_Peak_Order_By_Tenths(1:length(Current_Tenth_Index),N)=Current_Tenth_Index;
        clear Current_Tenth_Index;
    end
    clear N;
    Current_Line=1;
    while max(Major_Peak_Order_By_Tenths(Current_Line,:))>0 && Current_Line<=length(Major_Peak_Order_By_Tenths)
        Current_Line=Current_Line+1;
    end
    Major_Peak_Order_By_Tenths=Major_Peak_Order_By_Tenths(1:(Current_Line-1),:);
    clear Current_Line;
    clear Rank_Order_Index;
    
    Dist_Of_Spike_Counts_In_Minor_Peak=zeros(max(Trimmed_Decoding_Time_Info(:,14)),1);
    Dist_Of_Spike_Counts_In_Minor_Peak_Uni=zeros(max(Trimmed_Unimodal_Decoding_Time_Info(:,14)),1);
    Dist_Of_Spike_Counts_In_Minor_Peak_Bi=zeros(max(Trimmed_Bimodal_Decoding_Time_Info(:,14)),1);
    Minor_Peak_Order_By_Thirds=zeros(ceil(max(Trimmed_Decoding_Time_Info(:,14))/3),3);
    Minor_Peak_Order_By_Tenths=zeros(ceil(max(Trimmed_Decoding_Time_Info(:,14))/10),10);
    Minor_Peak_Order_By_Thirds_Uni=zeros(ceil(max(Trimmed_Unimodal_Decoding_Time_Info(:,14))/3),3);
    Minor_Peak_Order_By_Thirds_Bi=zeros(ceil(max(Trimmed_Bimodal_Decoding_Time_Info(:,14))/3),3);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
        if ~isempty(Current_Oscillation_Decoding_Time_Info) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,9)==0,1)) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,10)==0,1))
            Dist_Of_Spike_Counts_In_Minor_Peak(N,1)=mode(Current_Oscillation_Decoding_Time_Info(:,13));
        else
            Dist_Of_Spike_Counts_In_Minor_Peak(N,1)=-1;
        end
    end
    clear N;
    clear Current_Oscillation_Decoding_Time_Info
    for N=1:max(Trimmed_Unimodal_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoding_Time_Info=Trimmed_Unimodal_Decoding_Time_Info(Trimmed_Unimodal_Decoding_Time_Info(:,14)==N,:);
        if ~isempty(Current_Oscillation_Decoding_Time_Info) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,9)==0,1)) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,10)==0,1))
            Dist_Of_Spike_Counts_In_Minor_Peak_Uni(N,1)=mode(Current_Oscillation_Decoding_Time_Info(:,13));
        else
            Dist_Of_Spike_Counts_In_Minor_Peak_Uni(N,1)=-1;
        end
    end
    clear N;
    clear Current_Oscillation_Decoding_Time_Info
    for N=1:max(Trimmed_Bimodal_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoding_Time_Info=Trimmed_Bimodal_Decoding_Time_Info(Trimmed_Bimodal_Decoding_Time_Info(:,14)==N,:);
        if ~isempty(Current_Oscillation_Decoding_Time_Info) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,9)==0,1)) && isempty(find(Current_Oscillation_Decoding_Time_Info(:,10)==0,1))
            Dist_Of_Spike_Counts_In_Minor_Peak_Bi(N,1)=mode(Current_Oscillation_Decoding_Time_Info(:,13));
        else
            Dist_Of_Spike_Counts_In_Minor_Peak_Bi(N,1)=-1;
        end
    end
    clear N;
    clear Current_Oscillation_Decoding_Time_Info
    [Ordered_Data,Rank_Order_Index]=sortrows(Dist_Of_Spike_Counts_In_Minor_Peak(:,1));
    Rank_Order_Index=Rank_Order_Index(Ordered_Data>=0);
    clear Ordered_Data;
    for N=1:3
        Current_Third_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/3)+1):round((N*length(Rank_Order_Index))/3));
        Minor_Peak_Order_By_Thirds(1:length(Current_Third_Index),N)=Current_Third_Index;
        clear Current_Third_Index;
    end
    clear N;
    Current_Line=1;
    while max(Minor_Peak_Order_By_Thirds(Current_Line,:))>0 && Current_Line<=length(Minor_Peak_Order_By_Thirds)
        Current_Line=Current_Line+1;
    end
    Minor_Peak_Order_By_Thirds=Minor_Peak_Order_By_Thirds(1:(Current_Line-1),:);
    clear Current_Line;
    for N=1:10
        Current_Tenth_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/10)+1):round((N*length(Rank_Order_Index))/10));
        Minor_Peak_Order_By_Tenths(1:length(Current_Tenth_Index),N)=Current_Tenth_Index;
        clear Current_Tenth_Index;
    end
    clear N;
    Current_Line=1;
    while max(Minor_Peak_Order_By_Tenths(Current_Line,:))>0 && Current_Line<=length(Minor_Peak_Order_By_Tenths)
        Current_Line=Current_Line+1;
    end
    Minor_Peak_Order_By_Tenths=Minor_Peak_Order_By_Tenths(1:(Current_Line-1),:);
    clear Current_Line;
    clear Rank_Order_Index;
    
    [Ordered_Data,Rank_Order_Index]=sortrows(Dist_Of_Spike_Counts_In_Minor_Peak_Uni(:,1));
    Rank_Order_Index=Rank_Order_Index(Ordered_Data>=0);
    clear Ordered_Data;
    for N=1:3
        Current_Third_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/3)+1):round((N*length(Rank_Order_Index))/3));
        Minor_Peak_Order_By_Thirds_Uni(1:length(Current_Third_Index),N)=Current_Third_Index;
        clear Current_Third_Index;
    end
    clear N;
    Current_Line=1;
    while max(Minor_Peak_Order_By_Thirds_Uni(Current_Line,:))>0 && Current_Line<=length(Minor_Peak_Order_By_Thirds_Uni)
        Current_Line=Current_Line+1;
    end
    Minor_Peak_Order_By_Thirds_Uni=Minor_Peak_Order_By_Thirds_Uni(1:(Current_Line-1),:);
    clear Current_Line;
    clear Rank_Order_Index;
    
    [Ordered_Data,Rank_Order_Index]=sortrows(Dist_Of_Spike_Counts_In_Minor_Peak_Bi(:,1));
    Rank_Order_Index=Rank_Order_Index(Ordered_Data>=0);
    clear Ordered_Data;
    for N=1:3
        Current_Third_Index=Rank_Order_Index((round(((N-1)*length(Rank_Order_Index))/3)+1):round((N*length(Rank_Order_Index))/3));
        Minor_Peak_Order_By_Thirds_Bi(1:length(Current_Third_Index),N)=Current_Third_Index;
        clear Current_Third_Index;
    end
    clear N;
    Current_Line=1;
    while max(Minor_Peak_Order_By_Thirds_Bi(Current_Line,:))>0 && Current_Line<=length(Minor_Peak_Order_By_Thirds_Bi)
        Current_Line=Current_Line+1;
    end
    Minor_Peak_Order_By_Thirds_Bi=Minor_Peak_Order_By_Thirds_Bi(1:(Current_Line-1),:);
    clear Current_Line;
    clear Rank_Order_Index;
    
    save('Spike_Count_Distributions_In_Major_And_Minor_Peak_Windows','Dist_Of_Spike_Counts_In_Major_Peak','Dist_Of_Spike_Counts_In_Minor_Peak','Dist_Of_Spike_Counts_In_Minor_Peak_Uni','Dist_Of_Spike_Counts_In_Minor_Peak_Bi','Major_Peak_Order_By_Thirds','Major_Peak_Order_By_Tenths','Minor_Peak_Order_By_Thirds','Minor_Peak_Order_By_Thirds_Uni','Minor_Peak_Order_By_Thirds_Bi','Minor_Peak_Order_By_Tenths');
    clear Dist_Of_Spike_Counts_In_Major_Peak;
    clear Dist_Of_Spike_Counts_In_Minor_Peak;
    
    Dist_Of_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Dist_Of_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,10);
    Dist_Of_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Dist_Of_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,10);
    Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    for Z=1:3
        for N=1:size(Major_Peak_Order_By_Thirds,1)
            if Major_Peak_Order_By_Thirds(N,Z)>0
                Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    for Z=1:10
        for N=1:size(Major_Peak_Order_By_Tenths,1)
            if Major_Peak_Order_By_Tenths(N,Z)>0
                Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    for Z=1:3
        for N=1:size(Minor_Peak_Order_By_Thirds,1)
            if Minor_Peak_Order_By_Thirds(N,Z)>0
                Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    for Z=1:10
        for N=1:size(Minor_Peak_Order_By_Tenths,1)
            if Minor_Peak_Order_By_Tenths(N,Z)>0
                Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    for Z=1:3
        for N=1:size(Minor_Peak_Order_By_Thirds_Uni,1)
            if Minor_Peak_Order_By_Thirds_Uni(N,Z)>0
                Current_Oscillation_Decoded_Data=Unimodal_Decoded_Data(:,Trimmed_Unimodal_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds_Uni(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Unimodal_Decoding_Time_Info(Trimmed_Unimodal_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds_Uni(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Unimodal_Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    for Z=1:3
        for N=1:size(Minor_Peak_Order_By_Thirds_Bi,1)
            if Minor_Peak_Order_By_Thirds_Bi(N,Z)>0
                Current_Oscillation_Decoded_Data=Bimodal_Decoded_Data(:,Trimmed_Bimodal_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds_Bi(N,Z));
                if ~isempty(Current_Oscillation_Decoded_Data)
                    Current_Oscillation_Decoding_Time_Info=Trimmed_Bimodal_Decoding_Time_Info(Trimmed_Bimodal_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds_Bi(N,Z),:);
                    if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                        for M=1:size(Bimodal_Decoded_Data,1)
                            [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                            if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                            end
                            clear Max_Phases;
                            clear Maxes;
                        end
                    end
                    clear Current_Oscillation_Decoding_Time_Info;
                    clear Current_Oscillation_Decoded_Data;
                    clear M;
                end
            end
        end
        clear N;
    end
    clear Z;
    
    Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,10);
    Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,3);
    Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,10);
    for Z=1:3
        for N=1:size(Dist_Of_Peak_Post_By_Major_Peak_Thirds,2)
            Norm_Dist_Of_Peak_Post_By_Major_Peak_Thirds(:,N,Z)=Dist_Of_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum(Dist_Of_Peak_Post_By_Major_Peak_Thirds(:,N,Z));
        end
        for N=1:size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds,2)
            Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum(Dist_Of_Peak_Post_By_Minor_Peak_Thirds(:,N,Z));
        end
        for N=1:size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni,2)
            Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni(:,N,Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni(:,N,Z)/sum(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Uni(:,N,Z));
        end
        for N=1:size(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi,2)
            Norm_Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi(:,N,Z)=Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi(:,N,Z)/sum(Dist_Of_Peak_Post_By_Minor_Peak_Thirds_Bi(:,N,Z));
        end
        clear N;
    end
    clear Z;
    for Z=1:10
        for N=1:size(Dist_Of_Peak_Post_By_Major_Peak_Tenths,2)
            Norm_Dist_Of_Peak_Post_By_Major_Peak_Tenths(:,N,Z)=Dist_Of_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum(Dist_Of_Peak_Post_By_Major_Peak_Tenths(:,N,Z));
        end
        for N=1:size(Dist_Of_Peak_Post_By_Minor_Peak_Tenths,2)
            Norm_Dist_Of_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum(Dist_Of_Peak_Post_By_Minor_Peak_Tenths(:,N,Z));
        end
        clear N;
    end
    clear Z;
    
    save('Average_Theta_Sequence_And_Posterior_Dists','Average_Decoded_*','*Dist_Of_*','-v7.3');
    
    if strcmp(Directory_Name(1),'L')
        
        load('Decoded_Linear_Data_And_Sequences','Movement_Direction')
        Trimmed_Movement_Direction=Movement_Direction(Decoding_Window_Index,:);
        
        %This calculates the average linear theta sequence
        Average_Linear_Decoded_Theta_Sequence=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins);
        Average_Linear_In_Up_Decoded_Theta_Sequence=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Average_Linear_In_Down_Decoded_Theta_Sequence=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Average_Linear_Out_Up_Decoded_Theta_Sequence=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        Average_Linear_Out_Down_Decoded_Theta_Sequence=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        for N=1:Number_Of_Theta_Bins
            Average_Linear_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
            Average_Linear_In_Up_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data_Linear_In(:,Trimmed_Movement_Direction(:,1)==1 & Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
            Average_Linear_In_Down_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data_Linear_In(:,Trimmed_Movement_Direction(:,1)==-1 & Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
            Average_Linear_Out_Up_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data_Linear_Out(:,Trimmed_Movement_Direction(:,1)==1 & Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
            Average_Linear_Out_Down_Decoded_Theta_Sequence(:,N)=mean(Decoded_Data_Linear_Out(:,Trimmed_Movement_Direction(:,1)==-1 & Trimmed_Decoding_Time_Info(:,6)>((N*Phase_Bin)-Phase_Bin) & Trimmed_Decoding_Time_Info(:,6)<=(N*Phase_Bin)),2);
        end
        clear N;
        
        %This calculates the distribution of peak posterior probabilities across the entire session for linear decoded data
        Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
        
        Dist_Of_Linear_Peak_Post=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins);
        Dist_Of_Linear_In_Up_Peak_Post=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Dist_Of_Linear_In_Down_Peak_Post=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Dist_Of_Linear_Out_Up_Peak_Post=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        Dist_Of_Linear_Out_Down_Peak_Post=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        for N=1:max(Trimmed_Decoding_Time_Info(:,14))
            Current_Oscillation_Decoded_Data=Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,14)==N);
            if ~isempty(Current_Oscillation_Decoded_Data)
                Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
                if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                    for M=1:size(Decoded_Data_Linear,1)
                        Maxes=max(Current_Oscillation_Decoded_Data(M,:));
                        if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                            Dist_Of_Linear_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Linear_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                        end
                        clear Max_Phases;
                        clear Maxes;
                    end
                end
                clear Current_Oscillation_Decoding_Time_Info;
                clear Current_Oscillation_Decoded_Data;
                clear M;
            end
        end
        clear N;
        
        for N=1:max(Trimmed_Decoding_Time_Info(:,14))
            Current_Oscillation_Decoded_Data_In=Decoded_Data_Linear_In(:,Trimmed_Decoding_Time_Info(:,14)==N);
            Current_Oscillation_Decoded_Data_Out=Decoded_Data_Linear_Out(:,Trimmed_Decoding_Time_Info(:,14)==N);
            if ~isempty(Current_Oscillation_Decoded_Data_In) && ~isempty(Current_Oscillation_Decoded_Data_Out)
                Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
                Current_Movement_Direction=mode(Trimmed_Movement_Direction(Trimmed_Decoding_Time_Info(:,14)==N,1));
                if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                    for M=1:size(Decoded_Data_Linear_In,1)
                        Maxes=max([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]);
                        if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]==Maxes)==1
                            if Current_Movement_Direction==1
                                if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                    Dist_Of_Linear_In_Up_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Linear_In_Up_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin))+1;
                                end
                                if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                    Dist_Of_Linear_Out_Up_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Linear_Out_Up_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin))+1;
                                end
                            else
                                if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                    Dist_Of_Linear_In_Down_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Linear_In_Down_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin))+1;
                                end
                                if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                    Dist_Of_Linear_Out_Down_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin))=Dist_Of_Linear_Out_Down_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin))+1;
                                end
                            end
                        end
                        clear Max_Phases;
                        clear Maxes;
                    end
                end
                clear Current_Oscillation_Decoding_Time_Info;
                clear Current_Oscillation_Decoded_Data_In;
                clear Current_Oscillation_Decoded_Data_Out;
                clear Current_Movement_Direction;
                clear M;
            end
        end
        clear N;
        Norm_Dist_Of_Linear_Peak_Post=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins);
        Norm_Dist_Of_Linear_In_Up_Peak_Post=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Norm_Dist_Of_Linear_In_Down_Peak_Post=zeros(size(Decoded_Data_Linear_In,1),Number_Of_Theta_Bins);
        Norm_Dist_Of_Linear_Out_Up_Peak_Post=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        Norm_Dist_Of_Linear_Out_Down_Peak_Post=zeros(size(Decoded_Data_Linear_Out,1),Number_Of_Theta_Bins);
        for N=1:size(Dist_Of_Linear_Peak_Post,2)
            Norm_Dist_Of_Linear_Peak_Post(:,N)=Dist_Of_Linear_Peak_Post(:,N)/sum(Dist_Of_Linear_Peak_Post(:,N));
        end
        for N=1:size(Dist_Of_Linear_In_Up_Peak_Post,2)
            Norm_Dist_Of_Linear_In_Up_Peak_Post(:,N)=Dist_Of_Linear_In_Up_Peak_Post(:,N)/sum([Dist_Of_Linear_In_Up_Peak_Post(:,N);Dist_Of_Linear_Out_Up_Peak_Post(:,N)]);
        end
        for N=1:size(Dist_Of_Linear_In_Down_Peak_Post,2)
            Norm_Dist_Of_Linear_In_Down_Peak_Post(:,N)=Dist_Of_Linear_In_Down_Peak_Post(:,N)/sum([Dist_Of_Linear_In_Down_Peak_Post(:,N);Dist_Of_Linear_Out_Down_Peak_Post(:,N)]);
        end
        for N=1:size(Dist_Of_Linear_Out_Up_Peak_Post,2)
            Norm_Dist_Of_Linear_Out_Up_Peak_Post(:,N)=Dist_Of_Linear_Out_Up_Peak_Post(:,N)/sum([Dist_Of_Linear_Out_Up_Peak_Post(:,N);Dist_Of_Linear_In_Up_Peak_Post(:,N)]);
        end
        for N=1:size(Dist_Of_Linear_Out_Down_Peak_Post,2)
            Norm_Dist_Of_Linear_Out_Down_Peak_Post(:,N)=Dist_Of_Linear_Out_Down_Peak_Post(:,N)/sum([Dist_Of_Linear_Out_Down_Peak_Post(:,N);Dist_Of_Linear_In_Down_Peak_Post(:,N)]);
        end
        
        Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        
        Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        
        for Z=1:3
            for N=1:size(Major_Peak_Order_By_Thirds,1)
                if Major_Peak_Order_By_Thirds(N,Z)>0
                    Current_Oscillation_Decoded_Data=Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z),:);
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear,1)
                                [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                                if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                    Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:10
            for N=1:size(Major_Peak_Order_By_Tenths,1)
                if Major_Peak_Order_By_Tenths(N,Z)>0
                    Current_Oscillation_Decoded_Data=Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z),:);
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear,1)
                                [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                                if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                    Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:3
            for N=1:size(Minor_Peak_Order_By_Thirds,1)
                if Minor_Peak_Order_By_Thirds(N,Z)>0
                    Current_Oscillation_Decoded_Data=Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z),:);
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear,1)
                                [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                                if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                    Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:10
            for N=1:size(Minor_Peak_Order_By_Tenths,1)
                if Minor_Peak_Order_By_Tenths(N,Z)>0
                    Current_Oscillation_Decoded_Data=Decoded_Data_Linear(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z),:);
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear,1)
                                [Maxes,Max_Phases]=max(Current_Oscillation_Decoded_Data(M,:));
                                if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                                    Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        
        for Z=1:3
            for N=1:size(Major_Peak_Order_By_Thirds,1)
                if Major_Peak_Order_By_Thirds(N,Z)>0
                    Current_Oscillation_Decoded_Data_In=Decoded_Data_Linear_In(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z));
                    Current_Oscillation_Decoded_Data_Out=Decoded_Data_Linear_Out(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data_In) && ~isempty(Current_Oscillation_Decoded_Data_Out)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z),:);
                        Current_Movement_Direction=mode(Trimmed_Movement_Direction(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Thirds(N,Z),1));
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear_In,1)
                                Maxes=max([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]);
                                if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]==Maxes)==1
                                    if Current_Movement_Direction==1
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    else
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    end
                                end
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data_Out;
                        clear Current_Oscillation_Decoded_Data_In;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:10
            for N=1:size(Major_Peak_Order_By_Tenths,1)
                if Major_Peak_Order_By_Tenths(N,Z)>0
                    Current_Oscillation_Decoded_Data_In=Decoded_Data_Linear_In(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z));
                    Current_Oscillation_Decoded_Data_Out=Decoded_Data_Linear_Out(:,Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data_In) && ~isempty(Current_Oscillation_Decoded_Data_Out)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z),:);
                        Current_Movement_Direction=mode(Trimmed_Movement_Direction(Trimmed_Decoding_Time_Info(:,14)==Major_Peak_Order_By_Tenths(N,Z),1));
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear_In,1)
                                [Maxes,Max_Phases]=max([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]);
                                if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]==Maxes)==1
                                    if Current_Movement_Direction==1
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    else
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    end
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data_In;
                        clear Current_Oscillation_Decoded_Data_Out;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:3
            for N=1:size(Minor_Peak_Order_By_Thirds,1)
                if Minor_Peak_Order_By_Thirds(N,Z)>0
                    Current_Oscillation_Decoded_Data_In=Decoded_Data_Linear_In(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z));
                    Current_Oscillation_Decoded_Data_Out=Decoded_Data_Linear_Out(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data_In) && ~isempty(Current_Oscillation_Decoded_Data_Out)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z),:);
                        Current_Movement_Direction=mode(Trimmed_Movement_Direction(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Thirds(N,Z),1));
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear_In,1)
                                [Maxes,Max_Phases]=max([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]);
                                if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]==Maxes)==1
                                    if Current_Movement_Direction==1
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    else
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    end
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data_In;
                        clear Current_Oscillation_Decoded_Data_Out;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        for Z=1:10
            for N=1:size(Minor_Peak_Order_By_Tenths,1)
                if Minor_Peak_Order_By_Tenths(N,Z)>0
                    Current_Oscillation_Decoded_Data_In=Decoded_Data_Linear_In(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z));
                    Current_Oscillation_Decoded_Data_Out=Decoded_Data_Linear_Out(:,Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z));
                    if ~isempty(Current_Oscillation_Decoded_Data_In) && ~isempty(Current_Oscillation_Decoded_Data_Out)
                        Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z),:);
                        Current_Movement_Direction=mode(Trimmed_Movement_Direction(Trimmed_Decoding_Time_Info(:,14)==Minor_Peak_Order_By_Tenths(N,Z),1));
                        if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                            for M=1:size(Decoded_Data_Linear_In,1)
                                [Maxes,Max_Phases]=max([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]);
                                if Maxes(1)>=Minimum_Max && sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]~=Maxes(1))>0 %&& sum([Current_Oscillation_Decoded_Data_In(M,:),Current_Oscillation_Decoded_Data_Out(M,:)]==Maxes)==1
                                    if Current_Movement_Direction==1
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    else
                                        if sum(Current_Oscillation_Decoded_Data_In(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_In(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                        if sum(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes(1)>0)
                                            Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data_Out(M,:)==Maxes,6)/Phase_Bin),Z)+1;
                                        end
                                    end
                                end
                                clear Max_Phases;
                                clear Maxes;
                            end
                        end
                        clear Current_Oscillation_Decoding_Time_Info;
                        clear Current_Oscillation_Decoded_Data_In;
                        clear Current_Oscillation_Decoded_Data_Out;
                        clear M;
                    end
                end
            end
            clear N;
        end
        clear Z;
        
        Norm_Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        
        Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Third=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenth=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,3);
        Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths=zeros(size(Decoded_Data_Linear,1),Number_Of_Theta_Bins,10);
        
        for Z=1:3
            for N=1:size(Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds(:,N,Z)=Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum(Dist_Of_Linear_Peak_Post_By_Major_Peak_Thirds(:,N,Z));
            end
            for N=1:size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Thirds(:,N,Z));
            end
            for N=1:size(Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds,2)
                Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z);Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds,2)
                Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z);Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds,2)
                Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z);Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds,2)
                Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z);Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z);Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z);Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Third(:,N,Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z);Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Thirds(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds,2)
                Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)/sum([Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z);Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Thirds(:,N,Z)]);
            end
            clear N;
        end
        clear Z;
        for Z=1:10
            for N=1:size(Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths(:,N,Z)=Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum(Dist_Of_Linear_Peak_Post_By_Major_Peak_Tenths(:,N,Z));
            end
            for N=1:size(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum(Dist_Of_Linear_Peak_Post_By_Minor_Peak_Tenths(:,N,Z));
            end
            for N=1:size(Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths,2)
                Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z);Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths,2)
                Norm_Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z);Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths,2)
                Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z);Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths,2)
                Norm_Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z);Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_Out_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z);Dist_Of_Linear_In_Up_Peak_Post_By_Major_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_Out_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z);Dist_Of_Linear_In_Up_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenth(:,N,Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_Out_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z);Dist_Of_Linear_In_Down_Peak_Post_By_Major_Peak_Tenths(:,N,Z)]);
            end
            for N=1:size(Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths,2)
                Norm_Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)=Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)/sum([Dist_Of_Linear_Out_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z);Dist_Of_Linear_In_Down_Peak_Post_By_Minor_Peak_Tenths(:,N,Z)]);
            end
            clear N;
        end
        clear Z;
        
        save('Average_Theta_Sequence_And_Posterior_Dists','Average_Decoded_*','Average_Linear*','*Dist_Of_*','-v7.3');
        
    end
end
    
    
    
