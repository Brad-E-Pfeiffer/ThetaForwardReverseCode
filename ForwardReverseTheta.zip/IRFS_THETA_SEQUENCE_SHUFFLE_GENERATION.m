% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function generates two different sets of shuffles for the theta
% sequences to quantify their statistical significance.  One is shuffling
% the theta phase associated with each decoded window.  The second is
% shuffling the cell ID.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%This seeds the random number generator so that we don't get the same shuffles if we have to reboot mid-run.
Current_Time=clock;
eval(sprintf('rng(round(sqrt(%d%d%d%d%d%d)));',round(Current_Time(6)*1000),Current_Time(5),Current_Time(4),Current_Time(3),Current_Time(2),Current_Time(1)-2000));
clear Current_Time;

if exist('Shuffles','dir')==7
    cd Shuffles
else
    mkdir Shuffles
    cd Shuffles
end

%Theta phase shuffle for averages
if exist('Theta_Phase_Shuffles.mat','file')~=2
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index>0,:);
    Shuffle_Decoding_Window_Theta_Phases=zeros(size(Trimmed_Decoding_Time_Info,1),Number_Of_Shuffles);
    for Current_Shuffle=1:Number_Of_Shuffles
        Shuffle_Decoding_Window_Theta_Phases(:,Current_Shuffle)=Trimmed_Decoding_Time_Info(randperm(size(Trimmed_Decoding_Time_Info,1)),6);
    end
    clear Current_Shuffle;
    clear Trimmed_Decoding_Time_Info;
    save('Theta_Phase_Shuffles','Shuffle_Decoding_Window_Theta_Phases','-v7.3');
    clear Shuffle_Decoding_Window_Theta_Phases
end

%Theta phase shuffle for probability histograms
if exist('Theta_Histogram_Phase_Shuffles.mat','file')~=2
    cd ..
    load Spike_Count_Distributions_In_Major_And_Minor_Peak_Windows;
    cd Shuffles
    Number_Of_Theta_Bins=ceil(360/Phase_Bin);
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
    Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
    
    %This calculates the distribution of peak posterior probabilities across the entire session
    Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
    
    Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==N);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                Peak_Position_Phase_Bins=zeros(size(Decoded_Data,1),2);
                for M=1:size(Decoded_Data,1)
                    Maxes=max(Current_Oscillation_Decoded_Data(M,:));
                    if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 && sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                        Peak_Position_Phase_Bins(M,:)=[M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin)];
                    end
                    clear Maxes;
                end
                clear M;
                Peak_Position_Phase_Bins=Peak_Position_Phase_Bins(Peak_Position_Phase_Bins(:,1)>0,:);
                for Current_Shuffle=1:Number_Of_Shuffles
                    New_Peak_Position_Phase_Bins=Peak_Position_Phase_Bins(randperm(size(Peak_Position_Phase_Bins,1)),2);
                    for M=1:size(Peak_Position_Phase_Bins,1)
                        Phase_Shuffle_Dist_Of_Peak_Post(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                    end
                    if sum(Major_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Major Window
                        for M=1:size(Peak_Position_Phase_Bins,1)
                            Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                        end
                    end
                    if sum(Minor_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Minor Window
                        for M=1:size(Peak_Position_Phase_Bins,1)
                            Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                        end
                    end
                    clear M;
                    clear New_Peak_Position_Phase_Bins;
                end
                clear Current_Shuffle;
                clear Peak_Position_Phase_Bins;
            end
            clear Current_Oscillation_Decoding_Time_Info;
            clear Current_Oscillation_Decoded_Data;
            clear M;
        end
    end
    clear N;
    Norm_Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post));
    for Z=1:size(Phase_Shuffle_Dist_Of_Peak_Post,3)
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z));
        end
        clear N;
        Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third));
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z));
        end
        clear N;
        Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third));
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z));
        end
        clear N;
    end
    clear Z;
    save('Theta_Histogram_Phase_Shuffles','Phase_Shuffle_Dist_Of_Peak_Post','Norm_Phase_Shuffle_Dist_Of_Peak_Post','Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third','Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third','Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third','Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third','-v7.3');
end

%Cell ID shuffle
if exist('Shuffles_Finished.mat','file')~=2
    cd ..
    load Spike_Count_Distributions_In_Major_And_Minor_Peak_Windows;
    cd Shuffles
    if exist('Current_Shuffle.mat','file')==2
        load Current_Shuffle;
        Next_Shuffle_To_Do=Current_Shuffle+1;
        clear Current_Shuffle;
    else
        Next_Shuffle_To_Do=1;
    end
    
    Theta_Phases_Per_Decoding_Window=Decoding_Time_Info(Decoding_Window_Index>0,6);
    
    % Because the decoding algorithm multiplies fields together for a
    % part of the calculation, any field with a value of 0 prevents the
    % algorithm from ever representing that location.  Therefore, I need to go
    % through and replace all values of 0 with a very low, non-zero number.
    Field_Data2=Field_Data;
    for N=1:size(Field_Data2,3)
        Field=Field_Data2(:,:,N);
        Minimum=min(min(Field(Field>0)));
        if ~isempty(Minimum)
            if Minimum/10>0
                Field(Field<=0)=Minimum/10;
            else
                Field(Field<=0)=Minimum;
            end
        else
            Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        Field_Data2(:,:,N)=Field;
        clear Minimum;
        clear Field;
    end
    clear N;
    
    Mid_X=round(size(Field_Data,2)/2);   %This defines the size of the canvas for translation and rotation analysis
    Mid_Y=round(size(Field_Data,1)/2);   %This defines the size of the canvas for translation and rotation analysis
    
    for Current_Shuffle=Next_Shuffle_To_Do:Number_Of_Shuffles
        
        tic;
        
        %This shuffles the cell IDs in the Decoded_Spike_Index
        Shuffled_Spike_Index=zeros(size(Decoding_Spike_Index));
        Shuffled_Spike_IDs=Excitatory_Neurons(randperm(length(Excitatory_Neurons)));
        for Current_Shuffled_Cell=1:length(Excitatory_Neurons)
            Shuffled_Spike_Index(Decoding_Spike_Index==Excitatory_Neurons(Current_Shuffled_Cell))=Shuffled_Spike_IDs(Current_Shuffled_Cell);
        end
        clear Shuffled_Spike_IDs;
        clear Current_Shuffled_Cell;
        
        Decoded_Shuffle_Sequence=zeros(3,length(Decoding_Window_Index));
        %Decoded_Sequence
        %|                           1                         |                 2                  |                 3                  ||
        %|            Bin of Max Posterior Probability         |  Bin of Max Posterior Probability  |  Bin of Max Posterior Probability  ||
        %| Relative to Current Location and Movement Direction |           of X location            |           of Y location            ||
        
        Decoded_Shuffle_Data=zeros((max([Mid_X,Mid_Y])*2)+1,length(Decoding_Window_Index));
        Decoded_Data_Size=size(Decoded_Shuffle_Data,1);
        %Decoded_Data is the full posterior probabilities, collapsed across one dimension so it is encoding just the rat's current movement direction
      
        parfor Current_Decoding_Window=1:size(Shuffled_Spike_Index,2)
            
            %Pulls up relevant shuffled spikes for this decoding window
            Subset_Spike_Data=Shuffled_Spike_Index(:,Current_Decoding_Window);
            Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
            
            %This does the actual decoding for this window
            Decoded_Matrix=prod(Field_Data2(:,:,Subset_Spike_Data),3).*exp(-Decoding_Time_Window*sum(Field_Data,3));
            if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix)))
                    Decoded_Matrix=prod((Field_Data2(:,:,Subset_Spike_Data)/(2^Divider)),3).*exp(-Decoding_Time_Window*sum((Field_Data/(2^Divider)),3));
                    Divider=Divider+1;
                end
            end
            Decoded_Matrix(Decoded_Matrix<0)=0;
            if max(max(Decoded_Matrix))>0
                Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
            end
            
            %Here is where it gets relocated to rat's current location
            X=Position_Data_For_Shuffles(Current_Decoding_Window,1)/Bin_Size;
            Y=Position_Data_For_Shuffles(Current_Decoding_Window,2)/Bin_Size;
            Translated_Image=imtranslate(Decoded_Matrix,[Mid_X-X,Mid_Y-Y],'FillValues',0);
            
            %Here is where it gets rotated according to rat's current movement direction 
            Angle_Movement=Position_Data_For_Shuffles(Current_Decoding_Window,3);
            Rotated_Image=imrotate(Translated_Image,-(Angle_Movement+180),'bilinear');
            if size(Rotated_Image,1)<Decoded_Data_Size
                Size_Difference=Decoded_Data_Size-size(Rotated_Image,1);
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Rotated_Image=padarray(Rotated_Image,[Size_Difference/2,0],0,'both');
                else
                    Rotated_Image=padarray(Rotated_Image,[ceil(Size_Difference/2),0],0,'pre');
                    Rotated_Image=padarray(Rotated_Image,[floor(Size_Difference/2),0],0,'post');
                end
            end
            if size(Rotated_Image,1)>Decoded_Data_Size
                Size_Difference=size(Rotated_Image,1)-Decoded_Data_Size;
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Rotated_Image=Rotated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
                elseif Size_Difference==1
                    Rotated_Image=Rotated_Image(1:(end-1),:);
                else
                    Rotated_Image=Rotated_Image(ceil(Size_Difference/2):(end-ceil(Size_Difference/2)),:);
                end
            end
            
            %Here it sums across the direction perpendicular to the rat's movement direction
            Rotated_Image=sum(Rotated_Image,2);
            
            %Add to the rest of the decoded frames
            Decoded_Shuffle_Data(:,Current_Decoding_Window)=Rotated_Image;
            
            %Quantify the single point likely represented by this decoded frame 
            if Use_Maximum_Posterior_Probability %(This uses the max posterior probability as the single point)
                if max(max(Rotated_Image))>0
                    Max_Position=find(Rotated_Image==max(Rotated_Image),1,'first');
                else
                    Max_Position=0;
                end
            else %(This uses the weighted mean as the single point)
                if max(max(Rotated_Image))>0
                    Position_Matrix=zeros(length(Rotated_Image),2);
                    Position_Matrix(:,1)=(1:length(Rotated_Image))';
                    Position_Matrix(:,2)=Rotated_Image;
                    Max_Position=sum(Position_Matrix(:,1).*Position_Matrix(:,2))/sum(Position_Matrix(:,2));
                else
                    Max_Position=0;
                end
            end
            
            %Here it collapses across X and Y decoded locations for open field experiments (rather than the movement direction, in case this is valuable for later analyses)
            if size(Translated_Image,1)<Decoded_Data_Size
                Size_Difference=Decoded_Data_Size-size(Translated_Image,1);
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Translated_Image=padarray(Translated_Image,[Size_Difference/2,0],0,'both');
                else
                    Translated_Image=padarray(Translated_Image,[ceil(Size_Difference/2),0],0,'pre');
                    Translated_Image=padarray(Translated_Image,[floor(Size_Difference/2),0],0,'post');
                end
            end
            if size(Translated_Image,1)>Decoded_Data_Size
                Size_Difference=size(Translated_Image,1)-Decoded_Data_Size;
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Translated_Image=Translated_Image(((Size_Difference/2)+1):(end-(Size_Difference/2)),:);
                elseif Size_Difference==1
                    Translated_Image=Translated_Image(1:(end-1),:);
                else
                    Translated_Image=Translated_Image((ceil(Size_Difference/2)+1):(end-ceil(Size_Difference/2)),:);
                end
            end
            if size(Translated_Image,2)<Decoded_Data_Size
                Size_Difference=Decoded_Data_Size-size(Translated_Image,2);
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Translated_Image=padarray(Translated_Image,[0,Size_Difference/2],0,'both');
                else
                    Translated_Image=padarray(Translated_Image,[0,ceil(Size_Difference/2)],0,'pre');
                    Translated_Image=padarray(Translated_Image,[0,floor(Size_Difference/2)],0,'post');
                end
            end
            if size(Translated_Image,2)>Decoded_Data_Size
                Size_Difference=size(Translated_Image,2)-Decoded_Data_Size;
                if mod(Size_Difference,2)==0 %if Size_Difference is even
                    Translated_Image=Translated_Image(:,((Size_Difference/2)+1):(end-(Size_Difference/2)));
                elseif Size_Difference==1
                    Translated_Image=Translated_Image(1:(end-1),:);
                else
                    Translated_Image=Translated_Image(:,(ceil(Size_Difference/2)+1):(end-ceil(Size_Difference/2)));
                end
            end
            X_Image=(sum(Translated_Image,1))';
            Y_Image=sum(Translated_Image,2);
            if Use_Maximum_Posterior_Probability %This uses the max posterior probability as the single point
                if max(max(Translated_Image))>0
                    Max_X_Position=find(X_Image==max(X_Image),1,'first');
                    Max_Y_Position=find(Y_Image==max(Y_Image),1,'first');
                else
                    Max_X_Position=0;
                    Max_Y_Position=0;
                end
            else %This uses the weighted mean as the single point
                if max(max(Translated_Image))>0
                    X_Position_Matrix=zeros(length(Max_X_Position),2);
                    X_Position_Matrix(:,1)=(1:length(Max_X_Position))';
                    X_Position_Matrix(:,2)=Max_X_Position;
                    Max_X_Position=sum(X_Position_Matrix(:,1).*X_Position_Matrix(:,2))/sum(X_Position_Matrix(:,2));
                    Y_Position_Matrix=zeros(length(Max_Y_Position),2);
                    Y_Position_Matrix(:,1)=(1:length(Max_Y_Position))';
                    Y_Position_Matrix(:,2)=Max_Y_Position;
                    Max_Y_Position=sum(Y_Position_Matrix(:,1).*Y_Position_Matrix(:,2))/sum(Y_Position_Matrix(:,2));
                else
                    Max_X_Position=0;
                    Max_Y_Position=0;
                end
            end
            Decoded_Shuffle_Sequence(:,Current_Decoding_Window)=[Max_Position;Max_X_Position;Max_Y_Position];
                
        end
        
        %Find the mean theta sequence for this shuffle
        Mean_Decoded_Shuffle_Theta_Sequence=zeros(size(Decoded_Shuffle_Data,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Theta_Sequence,2)
            Mean_Decoded_Shuffle_Theta_Sequence(:,Current_Phase)=mean(Decoded_Shuffle_Data(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin)),2);
        end
        
        %Find the probability histogram for this shuffle
        Number_Of_Theta_Bins=ceil(360/Phase_Bin);
        Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
        Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
        
        %This calculates the distribution of peak posterior probabilities across the entire session
        Cell_ID_Shuffle_Dist_Of_Peak_Post=zeros(size(Decoded_Shuffle_Data,1),Number_Of_Theta_Bins);
        Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Decoded_Shuffle_Data,1),Number_Of_Theta_Bins);
        Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Decoded_Shuffle_Data,1),Number_Of_Theta_Bins);
        for N=1:max(Trimmed_Decoding_Time_Info(:,14))
            Current_Oscillation_Decoded_Data=Decoded_Shuffle_Data(:,Trimmed_Decoding_Time_Info(:,14)==N);
            if ~isempty(Current_Oscillation_Decoded_Data)
                Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
                if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                    for M=1:size(Decoded_Shuffle_Data,1)
                        Maxes=max(Current_Oscillation_Decoded_Data(M,:));
                        if Maxes(1)>0 && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 %&& sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                            Cell_ID_Shuffle_Dist_Of_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Cell_ID_Shuffle_Dist_Of_Peak_Post(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                            if sum(Major_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Major Window
                                Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                            end
                            if sum(Minor_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Minor Window
                                Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))=Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin))+1;
                            end
                        end
                        clear Max_Phases;
                        clear Maxes;
                    end
                end
                clear Current_Oscillation_Decoding_Time_Info;
                clear Current_Oscillation_Decoded_Data;
                clear M;
            end
        end
        clear N;
        Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post=zeros(size(Cell_ID_Shuffle_Dist_Of_Peak_Post));
        for N=1:size(Cell_ID_Shuffle_Dist_Of_Peak_Post,2)
            Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N)=Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N)/sum(Cell_ID_Shuffle_Dist_Of_Peak_Post(:,N));
        end
        clear N;
        Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third));
        for N=1:size(Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third,2)
            Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N)=Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N)/sum(Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N));
        end
        clear N;
        Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third));
        for N=1:size(Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third,2)
            Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N)=Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N)/sum(Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N));
        end
        clear N;
        
        eval(sprintf('save(''Shuffle_Data_%d'',''Mean_Decoded_Shuffle_Theta_Sequence'',''Cell_ID_Shuffle_Dist_Of_Peak_Post'',''Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post'',''Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third'',''Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Major_Top_Third'',''Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third'',''Norm_Cell_ID_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third'',''Shuffled_Spike_Index'',''Decoded_Shuffle_Data'',''Decoded_Shuffle_Sequence'',''Use_Maximum_Posterior_Probability'',''Current_Shuffle'',''-v7.3'');',Current_Shuffle))
        save('Current_Shuffle','Current_Shuffle');
        
        clear Decoded_Shuffle_Data;
        clear Decoded_Shuffle_Sequence;
        clear Shuffled_Spike_Index;
        clear Mean_Decoded_Shuffle_Theta_Sequence;
        clear Decoded_Data_Shuffles;
        clear Decoded_Sequence_Shuffles;
        clear Subset_Spike_Data;
        clear Divider;
        clear X;
        clear Y;
        clear Angle_Movement;
        clear Translated_Image;
        clear Rotated_Image;
        clear Size_Difference;
        clear Max_Position;
        clear Position_Matrx;
        clear Size_Difference;
        clear X_Image;
        clear Y_Image;
        clear Max_X_Position;
        clear Max_Y_Position;
        clear X_Position_Matrix;
        clear Y_Position_Matrix;
        clear In_Translated_Image;
        clear Out_Translated_Image;
        clear Decoded_Matrix;
        clear In_Decoded_Matrix;
        clear Out_Decoded_Matrix;
        clear Mid;
        clear Pos;
        clear Max_In_Position;
        clear Max_Out_Position;
        clear Decoded_Data_Size;
        clear Current_Phase;
        T=toc;
        eval(sprintf('disp(''Shuffle %d (of %d) took %d minutes.'');',Current_Shuffle,Number_Of_Shuffles,T/60));
        clear T;
    end
    save('Shuffles_Finished','Current_Shuffle');
    clear Current_Shuffle;
    clear Position_Data_For_Shuffles;
end
clear Mid_Y;
clear Mid_X;
clear Field_Data2;
clear Next_Shuffle_To_Do;
clear Theta_Phases_Per_Decoding_Window;

cd ..


