% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script removes sections of the experimental data that were
% determined to have high noise.  This is, unfortunately, a somewhat
% arbitrary definition, but is defined as periods of time when the raw LFP
% trace was above or below the recording threshold for a meaningful period
% of time (typically for more than a few seconds or so).  These timepoints
% are removed because if the LFP is above or below threshold, we cannot
% faithfully identify the theta phase associated with those sections of the
% recording.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if eval(sprintf('isfield(Timepoints_To_Remove,''%s_%s_To_Remove'')',Rat_Name,Directory_Name))
    eval(sprintf('Sections_To_Remove=%s_%s_To_Remove;',Rat_Name,Directory_Name));
    for Section=1:size(Sections_To_Remove,1)
        Spike_Information=Spike_Information(Spike_Data(:,1)<Sections_To_Remove(Section,1) | Spike_Data(:,1)>Sections_To_Remove(Section,2),:);
        Spike_Data=Spike_Data(Spike_Data(:,1)<Sections_To_Remove(Section,1) | Spike_Data(:,1)>Sections_To_Remove(Section,2),:);
        LFP_Theta=LFP_Theta(LFP_Theta(:,1)<Sections_To_Remove(Section,1) | LFP_Theta(:,1)>Sections_To_Remove(Section,2),:);
        Position_Data=Position_Data(Position_Data(:,1)<Sections_To_Remove(Section,1) | Position_Data(:,1)>Sections_To_Remove(Section,2),:);
    end
    clear Section
end
Total_Duration=sum(Position_Data(:,7)); %The total extent (in seconds) of this experimental session, not including sections that were removed above
clear Sections_To_Remove



