function [Sequence_Score,Sequence_Slope]=IRFS_SEQUENCE_SCORE(Matrix,Distance_Range)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This takes a two-dimensional Matrix of position probabilities across time
% and calculates the sequence score, as first described by Davidson et al,
% 2009 (Neuron).  Distance_Range is the range (in bins) for the function to
% use to calculate the Sequence Score.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

X_Locations=ones(size(Matrix,1),1)*(1:size(Matrix,2));
Y_Locations=(1:size(Matrix,1))'*ones(1,size(Matrix,2));
X_Locations=X_Locations(:);
Y_Locations=Y_Locations(:);
Weights=Matrix(:);
Weight_Matrix=[X_Locations.*Weights,Weights];
[Unitary_Matrix,Upper_Triangular_Matrix]=qr(Weight_Matrix,0);
Polynomial_Fit=Upper_Triangular_Matrix\(Unitary_Matrix'*(Weights.*Y_Locations));
Sequence_Slope=Polynomial_Fit(1);
%This calculates the Sequence Score
Sequence_Score=0;
for Step=1:size(Matrix,2)
    Location=round(polyval(Polynomial_Fit,Step));
    if Location>0 && Location<=size(Matrix,1)
        Sequence_Score=Sequence_Score+sum(Matrix(max([1,Location-Distance_Range]):min([size(Matrix,1),Location+Distance_Range]),Step)); %Within Distance_Range bins of weighted best fit line
    else
        Sequence_Score=Sequence_Score+median(Matrix(:,Step)); %If 'best' location is outside of track, the median decoded value is used
    end
end
Sequence_Score=Sequence_Score/Step;

end