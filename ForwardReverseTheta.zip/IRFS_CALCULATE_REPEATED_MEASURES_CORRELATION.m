function [P_Value,R_Value]=IRFS_CALCULATE_REPEATED_MEASURES_CORRELATION(Data)


% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% The purpose of this program is to calculate the repeated measures
% correlation statistics for a group of correlational data.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------








end