function IRFS_QUANTIFY_BETA_POWER_FOR_EVERY_DECODING_WINDOW

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the power of the beta frequency oscillation for
% each decoding window.  (The power of the theta frequency oscillation
% was already calculated in IRFS_CALCULATE_THETA_OSCILLATION_PROPERTIES.)
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if 1%exist('Beta_Power_Per_Decoding_Window.mat','file')~=2
    if exist('LFP_Left_Beta.mat','file')==2
        load LFP_Left_Beta
        Average_Beta_Power=LFP_Left_Beta(:,[1,3]);
    else
        load('LFP_Left','LFP_Left','LFP_Frequency');
        Beta_Stop_Low=12;
        Beta_Pass_Low=14;
        Beta_Pass_High=24;
        Beta_Stop_High=26;
        Stop_Band_Attenuation_One=60;    % This was the default, I think.
        Pass_Band=1;                     % This was the default, I think.
        Stop_Band_Attenuation_Two=80;    % This was the default, I think.
        Filter_Design_For_Beta=fdesign.bandpass(Beta_Stop_Low,Beta_Pass_Low,Beta_Pass_High,Beta_Stop_High,Stop_Band_Attenuation_One,Pass_Band,Stop_Band_Attenuation_Two,LFP_Frequency);
        Beta_Filter=design(Filter_Design_For_Beta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
        LFP_Data=LFP_Left;
        clear LFP_Left;
        Beta_Filtered_LFP_Data=zeros(size(LFP_Data,1),3);
        Beta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
        Beta_Filtered_LFP_Data(:,2)=filter(Beta_Filter,LFP_Data(:,2));
        clear LFP_Data;
        Beta_Filtered_LFP_Data(:,2)=Beta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
        Beta_Filtered_LFP_Data(:,2)=filter(Beta_Filter,Beta_Filtered_LFP_Data(:,2));
        Beta_Filtered_LFP_Data(:,2)=Beta_Filtered_LFP_Data(end:-1:1,2);
        Beta_Filtered_LFP_Data(:,3)=zscore(abs(hilbert(Beta_Filtered_LFP_Data(:,2))));
        Beta_Gaussian_Filter=fspecial('gaussian',[round(3*(150/((1/LFP_Frequency)*1000))),1],round(150/((1/LFP_Frequency)*1000)));
        Beta_Filtered_LFP_Data(:,3)=filtfilt(Beta_Gaussian_Filter,1,Beta_Filtered_LFP_Data(:,3));
        LFP_Left_Beta=Beta_Filtered_LFP_Data;
        Average_Beta_Power=LFP_Left_Beta(:,[1,3]);
        save('LFP_Left_Beta','LFP_Left_Beta','-v7.3');
        clear Beta_Filtered_LFP_Data;
        clear Beta_Gaussian_Filter;
    end
end

end

