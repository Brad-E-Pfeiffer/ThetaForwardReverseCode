% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function generates two different sets of shuffles for the theta
% sequences to quantify their statistical significance.  One is shuffling
% the theta phase associated with each decoded window.  The second is
% shuffling the cell ID.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if exist('Shuffles','dir')==7
    cd Shuffles
else
    mkdir Shuffles
    cd Shuffles
end

%Theta phase shuffle for averages
if exist('Theta_Phase_Shuffles.mat','file')~=2
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index>0,:);
    Shuffle_Decoding_Window_Theta_Phases=zeros(size(Trimmed_Decoding_Time_Info,1),Number_Of_Shuffles);
    for Current_Shuffle=1:Number_Of_Shuffles
        Shuffle_Decoding_Window_Theta_Phases(:,Current_Shuffle)=Trimmed_Decoding_Time_Info(randperm(size(Trimmed_Decoding_Time_Info,1)),6);
    end
    clear Current_Shuffle;
    clear Trimmed_Decoding_Time_Info;
    save('Theta_Phase_Shuffles','Shuffle_Decoding_Window_Theta_Phases','-v7.3');
    clear Shuffle_Decoding_Window_Theta_Phases
end

%Theta phase shuffle for probability histograms
if exist('Theta_Histogram_Phase_Shuffles.mat','file')~=2
    cd ..
    load Spike_Count_Distributions_In_Major_And_Minor_Peak_Windows;
    cd Shuffles
    Number_Of_Theta_Bins=ceil(360/Phase_Bin);
    Trimmed_Decoding_Time_Info=Decoding_Time_Info(Decoding_Window_Index,:);
    Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,6)==0,6)=360;
    
    %This calculates the distribution of peak posterior probabilities across the entire session
    Minimum_Max=0.01;  %This can set a limit on which values are included (Mengni set this to 0.01)
    
    Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Decoded_Data,1),Number_Of_Theta_Bins,Number_Of_Shuffles);
    for N=1:max(Trimmed_Decoding_Time_Info(:,14))
        Current_Oscillation_Decoded_Data=Decoded_Data(:,Trimmed_Decoding_Time_Info(:,14)==N);
        if ~isempty(Current_Oscillation_Decoded_Data)
            Current_Oscillation_Decoding_Time_Info=Trimmed_Decoding_Time_Info(Trimmed_Decoding_Time_Info(:,14)==N,:);
            if sum(Current_Oscillation_Decoding_Time_Info(:,9)==0)==0 && sum(Current_Oscillation_Decoding_Time_Info(:,10)==0)==0
                Peak_Position_Phase_Bins=zeros(size(Decoded_Data,1),2);
                for M=1:size(Decoded_Data,1)
                    Maxes=max(Current_Oscillation_Decoded_Data(M,:));
                    if Maxes(1)>=Minimum_Max && sum(Current_Oscillation_Decoded_Data(M,:)~=Maxes(1))>0 && sum(Current_Oscillation_Decoded_Data(M,:)==Maxes)==1
                        Peak_Position_Phase_Bins(M,:)=[M,ceil(Current_Oscillation_Decoding_Time_Info(Current_Oscillation_Decoded_Data(M,:)==Maxes,6)/Phase_Bin)];
                    end
                    clear Maxes;
                end
                clear M;
                Peak_Position_Phase_Bins=Peak_Position_Phase_Bins(Peak_Position_Phase_Bins(:,1)>0,:);
                for Current_Shuffle=1:Number_Of_Shuffles
                    New_Peak_Position_Phase_Bins=Peak_Position_Phase_Bins(randperm(size(Peak_Position_Phase_Bins,1)),2);
                    for M=1:size(Peak_Position_Phase_Bins,1)
                        Phase_Shuffle_Dist_Of_Peak_Post(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                    end
                    if sum(Major_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Major Window
                        for M=1:size(Peak_Position_Phase_Bins,1)
                            Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                        end
                    end
                    if sum(Minor_Peak_Order_By_Thirds(:,3)==N)==1  %If this theta oscillation was in the top third of firing rates in the Minor Window
                        for M=1:size(Peak_Position_Phase_Bins,1)
                            Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)=Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(Peak_Position_Phase_Bins(M,1),New_Peak_Position_Phase_Bins(M,1),Current_Shuffle)+1;
                        end
                    end
                    clear M;
                    clear New_Peak_Position_Phase_Bins;
                end
                clear Current_Shuffle;
                clear Peak_Position_Phase_Bins;
            end
            clear Current_Oscillation_Decoding_Time_Info;
            clear Current_Oscillation_Decoded_Data;
            clear M;
        end
    end
    clear N;
    Norm_Phase_Shuffle_Dist_Of_Peak_Post=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post));
    for Z=1:size(Phase_Shuffle_Dist_Of_Peak_Post,3)
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post(:,N,Z));
        end
        clear N;
        Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third));
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third(:,N,Z));
        end
        clear N;
        Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third=zeros(size(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third));
        for N=1:size(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third,2)
            Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z)=Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z)/sum(Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third(:,N,Z));
        end
        clear N;
    end
    clear Z;
    save('Theta_Histogram_Phase_Shuffles','Phase_Shuffle_Dist_Of_Peak_Post','Norm_Phase_Shuffle_Dist_Of_Peak_Post','Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third','Norm_Phase_Shuffle_Dist_Of_Peak_Post_Major_Top_Third','Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third','Norm_Phase_Shuffle_Dist_Of_Peak_Post_Minor_Top_Third','-v7.3');
end

%Cell ID shuffle
if exist('Linear_Shuffles_Finished.mat','file')~=2
    if exist('Current_Linear_Shuffle.mat','file')==2
        load Current_Linear_Shuffle;
        Next_Linear_Shuffle_To_Do=Current_Linear_Shuffle+1;
        clear Current_Linear_Shuffle;
    else
        Next_Linear_Shuffle_To_Do=1;
    end
    
    Theta_Phases_Per_Decoding_Window=Decoding_Time_Info(Decoding_Window_Index>0,6);
    
    % Because the decoding algorithm multiplies fields together for a
    % part of the calculation, any field with a value of 0 prevents the
    % algorithm from ever representing that location.  Therefore, I need to go
    % through and replace all values of 0 with a very low, non-zero number.
    Field_Data_Linear2=Field_Data_Linear;
    Field_Data_Linear_In2=Field_Data_Linear_In;
    Field_Data_Linear_Out2=Field_Data_Linear_Out;
    for N=1:size(Field_Data_Linear,2)
        Field=Field_Data_Linear2(:,N);
        Field_In=Field_Data_Linear_In2(:,N);
        Field_Out=Field_Data_Linear_Out2(:,N);
        Minimum=min(Field(Field>0));
        Minimum_In=min(Field_In(Field_In>0));
        Minimum_Out=min(Field_Out(Field_Out>0));
        if ~isempty(Minimum)
            Field(Field<=0)=Minimum/10;
        else
            Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_In)
            Field_In(Field_In<=0)=Minimum_In/10;
        else
            Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        if ~isempty(Minimum_Out)
            Field_Out(Field_Out<=0)=Minimum_Out/10;
        else
            Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
        end
        Field_Data_Linear2(:,N)=Field;
        Field_Data_Linear_In2(:,N)=Field_In;
        Field_Data_Linear_Out2(:,N)=Field_Out;
        clear Minimum;
        clear Minimum_In;
        clear Minimum_Out;
        clear Field;
        clear Field_In;
        clear Field_Out;
    end
    clear N;
    
    %This finds the long axis of the linear track and uses the appropriate position and movement direction data
    if max(Position_Data(:,2))-min(Position_Data(:,2))>max(Position_Data(:,3))-min(Position_Data(:,3))
        Position_Column=1;
    else
        Position_Column=2;
    end
    Movement_Direction=diff(Decoding_Time_Info(:,Position_Column));
    Movement_Direction(end+1,1)=Movement_Direction(end,1);
    if Movement_Direction(1,1)==0
        Movement_Direction(1,1)=Movement_Direction(find(Movement_Direction>0,1,'first'));
    end
    for N=2:length(Movement_Direction)
        if Movement_Direction(N,1)==0
            Movement_Direction(N,1)=Movement_Direction(N-1,1);
        end
    end
    Movement_Direction(Movement_Direction>=0)=1;
    Movement_Direction(Movement_Direction<0)=-1;


    Mid_Point=round(size(Field_Data_Linear2,1)/2);   %This defines the size of the canvas for translation analysis
    
    for Current_Linear_Shuffle=Next_Linear_Shuffle_To_Do:Number_Of_Shuffles
        
        tic;
        
        %This loads the shuffled cell IDs from the 2-dimensional shuffle (to allow for true comparison between those different shuffles)
        eval(sprintf('load(''Shuffle_Data_%d'',''Shuffled_Spike_Index'');',Current_Linear_Shuffle));
        
        Decoded_Shuffle_Data_Linear_Raw=zeros(size(Field_Data_Linear,1),size(Shuffled_Spike_Index,2),3);  %Page 1 is bi-directional fields, Page 2 is In fields, Page 3 is Out fields
        Decoded_Shuffle_Data_Linear=zeros(size(Field_Data_Linear,1),size(Shuffled_Spike_Index,2));
        Decoded_Shuffle_Data_Linear_In=zeros(size(Field_Data_Linear,1),size(Shuffled_Spike_Index,2));
        Decoded_Shuffle_Data_Linear_Out=zeros(size(Field_Data_Linear,1),size(Shuffled_Spike_Index,2));
        
        parfor Current_Decoding_Window=1:size(Shuffled_Spike_Index,2)
            
            %Pulls up relevant shuffled spikes for this decoding window
            Subset_Spike_Data=Shuffled_Spike_Index(:,Current_Decoding_Window);
            Subset_Spike_Data=Subset_Spike_Data(Subset_Spike_Data>0);
            
            %This does the actual decoding for this window
            Decoded_Matrix=prod(Field_Data_Linear2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear,2));
            if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix)))
                    Decoded_Matrix=prod((Field_Data_Linear2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                    Divider=Divider+1;
                end
            end
            Decoded_Matrix(Decoded_Matrix<0)=0;
            if max(max(Decoded_Matrix))>0
                Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
            end
            
            Decoded_Matrix_In=prod(Field_Data_Linear_In2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_In,2));
            Decoded_Matrix_Out=prod(Field_Data_Linear_Out2(:,Subset_Spike_Data),2).*exp(-Decoding_Time_Window*sum(Field_Data_Linear_Out,2));
            if isinf(max(max(Decoded_Matrix_In))) ||isinf(max(max(Decoded_Matrix_Out))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                Divider=1;
                while isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out)))
                    Decoded_Matrix_In=prod((Field_Data_Linear_In2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_In/(2^Divider)),2));
                    Decoded_Matrix_Out=prod((Field_Data_Linear_Out2(:,Subset_Spike_Data)/(2^Divider)),2).*exp(-Decoding_Time_Window*sum((Field_Data_Linear_Out/(2^Divider)),2));
                    Divider=Divider+1;
                end
            end
            Decoded_Matrix_In(Decoded_Matrix_In<0)=0;
            Decoded_Matrix_Out(Decoded_Matrix_Out<0)=0;
            if max(max(Decoded_Matrix_In))>0 && max(max(Decoded_Matrix_Out))>0
                Sum=sum(Decoded_Matrix_In+Decoded_Matrix_Out)
                Decoded_Matrix_In=Decoded_Matrix_In/Sum;
                Decoded_Matrix_Out=Decoded_Matrix_Out/Sum;
            end
            
            %Here is where the decoded data gets relocated to rat's current location
            Location=min([size(Field_Data_Linear,1),max([1,round(Decoding_Time_Info(Decoding_Window_Index(Current_Decoding_Window),Position_Column)/Bin_Size)])]);
            Direction=Movement_Direction(Decoding_Window_Index(Current_Decoding_Window),1);
            Translated_Image=imtranslate(Decoded_Matrix,[0,Mid_Point-Location],'FillValues',0);
            Translated_Image_In=imtranslate(Decoded_Matrix_In,[0,Mid_Point-Location],'FillValues',0);
            Translated_Image_Out=imtranslate(Decoded_Matrix_Out,[0,Mid_Point-Location],'FillValues',0);
            if Direction==-1
                Translated_Image=Translated_Image(end:-1:1,:);
                Translated_Image_In=Translated_Image_In(end:-1:1,:);
                Translated_Image_Out=Translated_Image_Out(end:-1:1,:);
            end
            
            %Add to the rest of the decoded frames
            Decoded_Shuffle_Data_Linear(:,Current_Decoding_Window)=Translated_Image;
            Decoded_Shuffle_Data_Linear_In(:,Current_Decoding_Window)=Translated_Image_In;
            Decoded_Shuffle_Data_Linear_Out(:,Current_Decoding_Window)=Translated_Image_Out;
            Decoded_Shuffle_Data_Linear_Raw(:,Current_Decoding_Window,:)=permute([Decoded_Matrix,Decoded_Matrix_In,Decoded_Matrix_Out],[1,3,2]);
        end
        
        %Find the mean theta sequence for this shuffle
        Mean_Decoded_Shuffle_Linear_Theta_Sequence=zeros(size(Decoded_Shuffle_Data_Linear,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Linear_Theta_Sequence,2)
            Mean_Decoded_Shuffle_Linear_Theta_Sequence(:,Current_Phase)=mean(Decoded_Shuffle_Data_Linear(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin)),2);
        end
        Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells=zeros(size(Decoded_Shuffle_Data_Linear,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells,2)
            Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells(:,Current_Phase)=mean(Decoded_Shuffle_Data_Linear_In(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin) & Movement_Direction(Decoding_Window_Index)==1),2);
        end
        Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells=zeros(size(Decoded_Shuffle_Data_Linear,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells,2)
            Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells(:,Current_Phase)=mean(Decoded_Shuffle_Data_Linear_Out(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin) & Movement_Direction(Decoding_Window_Index)==1),2);
        end
        Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells=zeros(size(Decoded_Shuffle_Data_Linear,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells,2)
            Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_In_Cells(:,Current_Phase)=mean(Decoded_Shuffle_Data_Linear_In(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin) & Movement_Direction(Decoding_Window_Index)==-1),2);
        end
        Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells=zeros(size(Decoded_Shuffle_Data_Linear,1),ceil(360/Phase_Bin));
        for Current_Phase=1:size(Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells,2)
            Mean_Decoded_Shuffle_Linear_Theta_Sequence_Out_With_Out_Cells(:,Current_Phase)=mean(Decoded_Shuffle_Data_Linear_Out(:,Theta_Phases_Per_Decoding_Window>((Current_Phase*Phase_Bin)-Phase_Bin) & Theta_Phases_Per_Decoding_Window<=(Current_Phase*Phase_Bin) & Movement_Direction(Decoding_Window_Index)==-1),2);
        end
            
        eval(sprintf('save(''Linear_Shuffle_Data_%d'',''Mean_Decoded_Shuffle_Lin*'',''Decoded_Shuffle_Data_Lin*'',''Shuffled_Spike_Index'',''Movement_Direction'',''Use_Maximum_Posterior_Probability'',''Current_Linear_Shuffle'',''-v7.3'');',Current_Linear_Shuffle));
        save('Current_Linear_Shuffle','Current_Linear_Shuffle');
        clear Decoded_Shuffle_Data_Linear_In;
        clear Decoded_Shuffle_Data_Linear_Out;
        clear Shuffled_Spike_Index;
        clear Mean_Decoded_Shuffle_Theta_Sequence;
        clear Mean_Decoded_Shuffle_Theta_Sequence_Linear_In;
        clear Mean_Decoded_Shuffle_Theta_Sequence_Linear_Out;
        clear Decoded_Data_Shuffles;
        clear Subset_Spike_Data;
        clear Divider;
        clear Location;
        clear Translated_Image;
        clear Translated_Image_In;
        clear Translated_Image_Out;
        clear Size_Difference;
        clear Max_Position;
        clear Position_Matrx;
        clear Decoded_Matrix;
        clear Decoded_Matrix_In;
        clear Decoded_Matrix_Out;
        clear Current_Phase;
        clear Current_Decoding_Window;
        clear Sum;
        T=toc;
        eval(sprintf('disp(''Linear shuffle %d (of %d) took %d minutes.'');',Current_Linear_Shuffle,Number_Of_Shuffles,T/60));
        clear T;
    end
    save('Linear_Shuffles_Finished','Current_Linear_Shuffle');
end
clear Current_Linear_Shuffle;
clear Movement_Direction;
clear Field_Data_Linear2;
clear Field_Data_Linear_In2;
clear Field_Data_Linear_Out2;
clear Next_Linear_Shuffle_To_Do;
clear Theta_Phases_Per_Decoding_Window;

cd ..


